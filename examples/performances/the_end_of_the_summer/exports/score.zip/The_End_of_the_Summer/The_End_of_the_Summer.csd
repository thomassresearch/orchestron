<!--
Performance: The End of the Summer
Description: 112 BPM | E minor | 168 bars | 6:00 including decay. Dark wave: a cold industrial pulse interrupted by warm strings and brass. 0:00 Clouds; 0:34 Machinery; 1:43 First sunlight; 2:00 Clouds return; 3:09 Open sky; 3:43 Warmth within the machine; 4:51 Unwinding; 5:26 A little warmth survives. Finite Pad Looper arrangement, Repeat off. Final four bars reserved for tails.
Created: 2026-09-16T19:03:34.281469+00:00

This CSD was created with Orchestron.
Design instruments visually and hear ideas take shape.
Build expressive performances with sequencers, arpeggiators, live controls, and flexible audio routing.
Export portable Csound projects for rendering, sharing, and further sound design.

GitHub: https://github.com/thomassresearch/orchestron
-->
<CsoundSynthesizer>
<CsOptions>
-d -W -f -o The_End_of_the_Summer.wav
</CsOptions>
<CsInstruments>
sr = 48000
ksmps = 1
nchnls = 2
0dbfs = 1.0
opcode vcs_mixer_ramp, a, ki
 setksmps 1
 kTarget, iInitial xin
 kValue init iInitial
 kPrevious init iInitial
 kRemaining init 0
 if kTarget != kPrevious then
  kRemaining = 0.02
  kPrevious = kTarget
 endif
 if kRemaining > 0 then
  kValue = kValue + (kTarget - kValue) / max(1, kRemaining * kr)
  kRemaining = max(0, kRemaining - 1 / kr)
 else
  kValue = kTarget
 endif
 aValue interp kValue
 if timeinstk() == 1 then
  aValue = iInitial
 endif
 xout aValue
endop
; Mixer routing: patch, strip and route instruments execute in signal-flow order.
chnset 0.28183829312644537, "__vcs_mixer_strip_7cc44eb19abccf91739a7239_gain"
chnset 1, "__vcs_mixer_strip_7cc44eb19abccf91739a7239_left"
chnset 1, "__vcs_mixer_strip_7cc44eb19abccf91739a7239_right"
chnset 1, "__vcs_mixer_strip_7cc44eb19abccf91739a7239_mute"
chnset 0.3981071705534972, "__vcs_mixer_strip_441349e1ec2f7fd0aa17267b_gain"
chnset 1, "__vcs_mixer_strip_441349e1ec2f7fd0aa17267b_left"
chnset 1, "__vcs_mixer_strip_441349e1ec2f7fd0aa17267b_right"
chnset 1, "__vcs_mixer_strip_441349e1ec2f7fd0aa17267b_mute"
chnset 0.19952623149688797, "__vcs_mixer_strip_69a5a5c217c582a0ca581019_gain"
chnset 1, "__vcs_mixer_strip_69a5a5c217c582a0ca581019_left"
chnset 0.88, "__vcs_mixer_strip_69a5a5c217c582a0ca581019_right"
chnset 1, "__vcs_mixer_strip_69a5a5c217c582a0ca581019_mute"
chnset 0.3981071705534972, "__vcs_mixer_strip_15fa97b5a488542761982797_gain"
chnset 1, "__vcs_mixer_strip_15fa97b5a488542761982797_left"
chnset 1, "__vcs_mixer_strip_15fa97b5a488542761982797_right"
chnset 1, "__vcs_mixer_strip_15fa97b5a488542761982797_mute"
chnset 1, "__vcs_mixer_strip_3cb8201e7ff1e7777446032e_gain"
chnset 1, "__vcs_mixer_strip_3cb8201e7ff1e7777446032e_left"
chnset 0.92000000000000004, "__vcs_mixer_strip_3cb8201e7ff1e7777446032e_right"
chnset 1, "__vcs_mixer_strip_3cb8201e7ff1e7777446032e_mute"
chnset 0.89125093813374556, "__vcs_mixer_strip_921a95e8b614f668981d9eee_gain"
chnset 1, "__vcs_mixer_strip_921a95e8b614f668981d9eee_left"
chnset 1, "__vcs_mixer_strip_921a95e8b614f668981d9eee_right"
chnset 1, "__vcs_mixer_strip_921a95e8b614f668981d9eee_mute"
chnset 1, "__vcs_mixer_strip_4357ddb2013f8c1bae14ef67_gain"
chnset 0.87, "__vcs_mixer_strip_4357ddb2013f8c1bae14ef67_left"
chnset 1, "__vcs_mixer_strip_4357ddb2013f8c1bae14ef67_right"
chnset 1, "__vcs_mixer_strip_4357ddb2013f8c1bae14ef67_mute"
chnset 0.25118864315095801, "__vcs_mixer_strip_5187e59d9b00ec8dfc6ace45_gain"
chnset 0.84999999999999998, "__vcs_mixer_strip_5187e59d9b00ec8dfc6ace45_left"
chnset 1, "__vcs_mixer_strip_5187e59d9b00ec8dfc6ace45_right"
chnset 1, "__vcs_mixer_strip_5187e59d9b00ec8dfc6ace45_mute"
chnset 0.15848931924611134, "__vcs_mixer_strip_e5e72beb4e3c6926d3dc9e3e_gain"
chnset 1, "__vcs_mixer_strip_e5e72beb4e3c6926d3dc9e3e_left"
chnset 1, "__vcs_mixer_strip_e5e72beb4e3c6926d3dc9e3e_right"
chnset 1, "__vcs_mixer_strip_e5e72beb4e3c6926d3dc9e3e_mute"
chnset 0.63095734448019325, "__vcs_mixer_strip_b5c7638620f2f38a657a5790_gain"
chnset 1, "__vcs_mixer_strip_b5c7638620f2f38a657a5790_left"
chnset 1, "__vcs_mixer_strip_b5c7638620f2f38a657a5790_right"
chnset 1, "__vcs_mixer_strip_b5c7638620f2f38a657a5790_mute"
chnset 1, "__vcs_mixer_route_83b8456f5a6ccf61bd09771f_gain"
chnset 1, "__vcs_mixer_route_83b8456f5a6ccf61bd09771f_post"
chnset 1, "__vcs_mixer_route_83b8456f5a6ccf61bd09771f_pan"
chnset 1, "__vcs_mixer_route_b5f389b4e240e65eb88e717c_gain"
chnset 1, "__vcs_mixer_route_b5f389b4e240e65eb88e717c_post"
chnset 1, "__vcs_mixer_route_b5f389b4e240e65eb88e717c_pan"
chnset 1, "__vcs_mixer_route_3e8014902b44dfaf5918f0cb_gain"
chnset 1, "__vcs_mixer_route_3e8014902b44dfaf5918f0cb_post"
chnset 1, "__vcs_mixer_route_3e8014902b44dfaf5918f0cb_pan"
chnset 1, "__vcs_mixer_route_c99934ba5158b7053b82b3c7_gain"
chnset 1, "__vcs_mixer_route_c99934ba5158b7053b82b3c7_post"
chnset 1, "__vcs_mixer_route_c99934ba5158b7053b82b3c7_pan"
chnset 1, "__vcs_mixer_route_1d60c1873f7c84bee9eada4e_gain"
chnset 1, "__vcs_mixer_route_1d60c1873f7c84bee9eada4e_post"
chnset 1, "__vcs_mixer_route_1d60c1873f7c84bee9eada4e_pan"
chnset 1, "__vcs_mixer_route_51517161fc68e6e3eeac9206_gain"
chnset 1, "__vcs_mixer_route_51517161fc68e6e3eeac9206_post"
chnset 1, "__vcs_mixer_route_51517161fc68e6e3eeac9206_pan"
chnset 1, "__vcs_mixer_route_5c765a9573cccf11ec260943_gain"
chnset 1, "__vcs_mixer_route_5c765a9573cccf11ec260943_post"
chnset 1, "__vcs_mixer_route_5c765a9573cccf11ec260943_pan"
chnset 1, "__vcs_mixer_route_aca770adf6d5aa1d37b31081_gain"
chnset 1, "__vcs_mixer_route_aca770adf6d5aa1d37b31081_post"
chnset 1, "__vcs_mixer_route_aca770adf6d5aa1d37b31081_pan"
chnset 1, "__vcs_mixer_route_6ef9be26494bffae34fdfd29_gain"
chnset 1, "__vcs_mixer_route_6ef9be26494bffae34fdfd29_post"
chnset 1, "__vcs_mixer_route_6ef9be26494bffae34fdfd29_pan"
chnset 1, "__vcs_mixer_route_43f837ee6d4c255b17854c22_gain"
chnset 1, "__vcs_mixer_route_43f837ee6d4c255b17854c22_post"
chnset 1, "__vcs_mixer_route_43f837ee6d4c255b17854c22_pan"
chnset 1, "__vcs_mixer_route_c01b8e240438f78a8824cfd3_gain"
chnset 1, "__vcs_mixer_route_c01b8e240438f78a8824cfd3_post"
chnset 1, "__vcs_mixer_route_c01b8e240438f78a8824cfd3_pan"
chnset 1, "__vcs_mixer_route_1a360e0bf12680fcccccf68a_gain"
chnset 1, "__vcs_mixer_route_1a360e0bf12680fcccccf68a_post"
chnset 1, "__vcs_mixer_route_1a360e0bf12680fcccccf68a_pan"
chnset 1, "__vcs_mixer_route_3bf52259f3a75a40898bd370_gain"
chnset 1, "__vcs_mixer_route_3bf52259f3a75a40898bd370_post"
chnset 1, "__vcs_mixer_route_3bf52259f3a75a40898bd370_pan"
chnset 1, "__vcs_mixer_route_95085945e8b7aaf31960266c_gain"
chnset 1, "__vcs_mixer_route_95085945e8b7aaf31960266c_post"
chnset 1, "__vcs_mixer_route_95085945e8b7aaf31960266c_pan"
chnset 1, "__vcs_mixer_route_7d9706dbf4b80041a7bac944_gain"
chnset 1, "__vcs_mixer_route_7d9706dbf4b80041a7bac944_post"
chnset 1, "__vcs_mixer_route_7d9706dbf4b80041a7bac944_pan"
chnset 1, "__vcs_mixer_route_5471588a628d780162691603_gain"
chnset 1, "__vcs_mixer_route_5471588a628d780162691603_post"
chnset 1, "__vcs_mixer_route_5471588a628d780162691603_pan"
chnset 1, "__vcs_mixer_route_215dfad6ea4278df9c5b5929_gain"
chnset 1, "__vcs_mixer_route_215dfad6ea4278df9c5b5929_post"
chnset 1, "__vcs_mixer_route_215dfad6ea4278df9c5b5929_pan"
chnset 1, "__vcs_mixer_route_7ccdeae3e4931ae57c24ee42_gain"
chnset 1, "__vcs_mixer_route_7ccdeae3e4931ae57c24ee42_post"
chnset 1, "__vcs_mixer_route_7ccdeae3e4931ae57c24ee42_pan"
chnset 1, "__vcs_mixer_route_ebe4d00ca1570557781dee01_gain"
chnset 1, "__vcs_mixer_route_ebe4d00ca1570557781dee01_post"
chnset 1, "__vcs_mixer_route_ebe4d00ca1570557781dee01_pan"
chnset 1, "__vcs_mixer_route_208ab40923d5bf707587f01b_gain"
chnset 1, "__vcs_mixer_route_208ab40923d5bf707587f01b_post"
chnset 1, "__vcs_mixer_route_208ab40923d5bf707587f01b_pan"
gk_vcs_score_cc[] init 2048
instr 9000
  iindex = int(p4)
  gk_vcs_score_cc[iindex] = p5
endin
chnset 1, "__vcs_perf_c47136601b6ea4e6370e270f9091838a70a71eaf9ef19a1000a71c57c70ca657"
chnset 1, "__vcs_perf_ad3c93d48fb5770da355be457ab89395386f05f9c5d130d292997b1e0d7d8c35"
chnset 0.5, "__vcs_perf_eab19a28d880be28fa5d086db1ac0c2039558b54d61d0c2c3b147dadb7c011cd"
chnset 2, "__vcs_perf_a647f3b1a6eef979fd4b84ef7e00100e16030190a47530e1e8b14be603e6a934"
connect "vcs_mix_4f507889dae17bb5de425c56", "left", "vcs_mix_233b9a10d13cb7345fe0ac51", "p_360f84035942243c6a36537a"
connect "vcs_mix_4f507889dae17bb5de425c56", "right", "vcs_mix_233b9a10d13cb7345fe0ac51", "p_27042f4e6eca7d0b2a7ee402"
chnset 0.65000000000000002, "__vcs_perf_3a3412564c51b46a1b2b5932e893c5377f697dde5eae688cc584ccdfcb58fea3"
chnset 0.0030000000000000001, "__vcs_perf_01cfe3facecca6f98f75a7d657f6b72de14cbcb96689449b53aa2ae1a2a7c2a4"
chnset 0.089999999999999997, "__vcs_perf_8aec72c06cb403170c8ac63a0d5a94d557081def0437f1a9d96c5b04d0361dfb"
chnset 1.7, "__vcs_perf_6333461785375abfa3e1e56d0c4e5251693489c7f876994084fb955d2e46bb7f"
chnset 0.044999999999999998, "__vcs_perf_efbeab3b8275658b2b792cc65c6d372a9e0d68e5688f983cd2727a48127bf431"
chnset 0.28000000000000003, "__vcs_perf_a1a8c8efcf62954b467a2b3f810241abdcb02d8b13aee6af47a82e95ddd85faa"
chnset 600, "__vcs_perf_176a9d6c90e45f3a5c879b4295e6221cb45d64776c1f57ce4ab80488b1189302"
connect "vcs_mix_33dc83ab9904e9526f7091d6", "left", "vcs_mix_d69e2b115c3aedc5f5e51463", "p_360f84035942243c6a36537a"
connect "vcs_mix_33dc83ab9904e9526f7091d6", "right", "vcs_mix_d69e2b115c3aedc5f5e51463", "p_27042f4e6eca7d0b2a7ee402"
chnset 0.0030000000000000001, "__vcs_perf_a175d18a9bfcdf60ae5c73352c3c40605b50ce1572548d8c5583537d7da998bf"
chnset 2.6000000000000001, "__vcs_perf_537c2b19d48f44e1e424e723788277a9281b9d43b761511324aca7e27c725a8f"
chnset 0.16, "__vcs_perf_41701256ec3711e8d169d6e04dc8984eebafdf6fec36817d76642ead9de79f94"
chnset 2.2000000000000002, "__vcs_perf_72ff4df4af243629f02ebf152735801f63433bb25c6eb1115e4f7c731c835bac"
chnset 0.20000000000000001, "__vcs_perf_af6123d7fa41370276ec9390d19919a421a3408261eddb7c22e2abdc0f7fac87"
chnset 0.14999999999999999, "__vcs_perf_300ce86c7a2a5bf21b93f4f78df99ae98603f3ab81a9e81f8b444dcae1cb7a8f"
chnset 0.080000000000000002, "__vcs_perf_78be482781265d240aa9c90b6cd369403569b19994d084ea9a9d84042e0029b3"
connect "vcs_mix_40643c4521cf1547a72d6c19", "left", "vcs_mix_d128d928004c9323f776f93a", "p_360f84035942243c6a36537a"
connect "vcs_mix_40643c4521cf1547a72d6c19", "right", "vcs_mix_d128d928004c9323f776f93a", "p_27042f4e6eca7d0b2a7ee402"
chnset 1.3999999999999999, "__vcs_perf_3c456691c46e0004e9f68642bf628b78230761b885805d730fdaba837aba84c6"
chnset 0.25, "__vcs_perf_c9b8a10bc7395e56c4f1e58b78ee975bc85395a8cfe4ee24559391e90b63d4ba"
chnset 0.13, "__vcs_perf_6972386ce10da486d8150798b5fd31dd6370b22fa8ca9f84aaa59c2622d09633"
chnset 0.55000000000000004, "__vcs_perf_135d781e2454b4e48599806b742e6e89762c5b1d5594a01c44baf7c3c5f7461f"
chnset 2.3999999999999999, "__vcs_perf_81eaa4a2bc2176bb0c4d870fa86fa96c4e691060bf41e4ce9778ffd6ad1a66ce"
chnset 0.28000000000000003, "__vcs_perf_e4492eb704bc9e3de2c33e65258c0cafca515039a9524b5e12d8010bd143066f"
chnset 750, "__vcs_perf_3352e2f8d65a84dfe6f573916ccef49d7f2c55e840e5aafac7d5a9046bafda8b"
connect "vcs_mix_2caaf50d4b3b53e2f4ee2efb", "left", "vcs_mix_96411e998269110c17432444", "p_360f84035942243c6a36537a"
connect "vcs_mix_2caaf50d4b3b53e2f4ee2efb", "right", "vcs_mix_96411e998269110c17432444", "p_27042f4e6eca7d0b2a7ee402"
chnset 0.01, "__vcs_perf_2693177ded5b3704bc870384173a72470fa3a13e6144717854f4ac738b76f410"
chnset 0.20000000000000001, "__vcs_perf_fa8a70d97431f3f6f5fce3a5432ef703e1b598ea68a3d5e09b6c1ecedf441a6e"
chnset 6, "__vcs_perf_789e61ba750aee5900aaa96e284eb96bdc9cb40bb441ce6d2fdb57b52575c586"
chnset 0.14999999999999999, "__vcs_perf_0294b3b47f66a9344cca1a5a51883b7e317cc1b65ecb77149d574ea73b0b5164"
chnset 0.22, "__vcs_perf_efd680873290a7110225cf770c00597f7560977a50b17fa760838a8cf73e0277"
chnset 1800, "__vcs_perf_b18357a98b0c231b8a2e7613ff04e4358d691722ebe869470e9a694fda744a9e"
chnset 4, "__vcs_perf_3dfb949bdf5981a798b597953f83889a8d82fded009fbb9ac6bc96de1f879192"
connect "vcs_mix_b9e4b05138bfb5ddfecff5e1", "left", "vcs_mix_8a252033ed35df6ff80fdae8", "p_360f84035942243c6a36537a"
connect "vcs_mix_b9e4b05138bfb5ddfecff5e1", "right", "vcs_mix_8a252033ed35df6ff80fdae8", "p_27042f4e6eca7d0b2a7ee402"
chnset 0.90000000000000002, "__vcs_perf_622518ee3862adc8b3f17f9f476cb2f2ffea4a9a674789344b4157b98214220f"
chnset 0.59999999999999998, "__vcs_perf_51f0147aa9651daa68390eeaf615c4143ee60381a2140a2072b442729ae89563"
chnset 8, "__vcs_perf_2d271b61eb8a76a4b00bfc63dca62a85d5e34c2f874d9217297884a5b9933dd4"
chnset 3, "__vcs_perf_14dbd30ed863c0239c6d1025f30671a2a5cabbd34ffe8b3938f26fe92b47035c"
chnset 0.22, "__vcs_perf_82b6576be193ba69f5e97deb72fe5b2c1c990f4a4058aec23336e3f002cc2dc7"
chnset 2300, "__vcs_perf_6095aa39c8df8873ec5f19f8b9ceb8601aeb7c970a46922ba5394f7ce22edf83"
connect "vcs_mix_b91f7fd7965b2dad388bba2b", "left", "vcs_mix_ac92f39f17c2687b02e604f4", "p_360f84035942243c6a36537a"
connect "vcs_mix_b91f7fd7965b2dad388bba2b", "right", "vcs_mix_ac92f39f17c2687b02e604f4", "p_27042f4e6eca7d0b2a7ee402"
chnset 0.089999999999999997, "__vcs_perf_86cc378af9041d5294c29fb180a2a447071c085191121fb86d925c5c920f83d4"
chnset 4, "__vcs_perf_7bfe3a3bce6abc89f529fe690548d1de6d37a6906f707c07a5732e196818788f"
chnset 0.65000000000000002, "__vcs_perf_82ba3acdefcc6460f500231c4626a68f7f1d91c9601a5cfddd7f510d6801f9bf"
chnset 1400, "__vcs_perf_99772fabed33c9193cc02a44d6d6f674521a18473e8e5a8cc3f5250477373958"
chnset 0.80000000000000004, "__vcs_perf_4fecc0c9b25b5fa647de6c824a65b6a7adb98a15406d418b5dd1c4ddcb954d76"
chnset 0.17999999999999999, "__vcs_perf_64c2b17f354e4038455ce71c6c7c49230ef5af9c620e4541d59a4cc898d10b48"
chnset 950, "__vcs_perf_d959aaca533b2b7656b57cacc21119939ad9308c4925af04cec1940da7079c69"
connect "vcs_mix_91d317b8f793206966758b36", "left", "vcs_mix_c5cc5b5de6f0d6ab45b331f7", "p_360f84035942243c6a36537a"
connect "vcs_mix_91d317b8f793206966758b36", "right", "vcs_mix_c5cc5b5de6f0d6ab45b331f7", "p_27042f4e6eca7d0b2a7ee402"
chnset 0.0030000000000000001, "__vcs_perf_7bed4733f2cf30ab8ececa1d061911d769efcf74c6a49d1363352814d8091472"
chnset 2, "__vcs_perf_4255b4799c2baaaf696d06577c5498543050bfad2e3c9df38feb483a5ce61527"
chnset 0.69999999999999996, "__vcs_perf_c9a8118403c5574b0b1d67f4efeae02fab27ff5b77321aa79b10229307175559"
chnset 2, "__vcs_perf_9d08305573089857d94b349a6d4a4d1065452491475f587164539f8b97c99b81"
chnset 1.5, "__vcs_perf_aad91d389043ff39f61e83a540ef1ff51ba1b339b9a30ff2cb86fbb90071bdfb"
chnset 0.29999999999999999, "__vcs_perf_bc7d83397c1478f832e5730a3fadc9b5b8f3ab7080c0f65681c43415706500a4"
chnset 4200, "__vcs_perf_b46a371f9eccb05e777dad1449cbe3ec085a046adde92c0acc50c8aee0494010"
connect "vcs_mix_c0bf79aa1787b85d72e90369", "left", "vcs_mix_3fb9b3909cb149df8c692155", "p_360f84035942243c6a36537a"
connect "vcs_mix_c0bf79aa1787b85d72e90369", "right", "vcs_mix_3fb9b3909cb149df8c692155", "p_27042f4e6eca7d0b2a7ee402"
chnset 0.80000000000000004, "__vcs_perf_cb7fe217f51092eabaf2b7e443277b31ad0bebfeac4f31e14ec648ac482e838c"
chnset 1000, "__vcs_perf_fef2b0c230c35dfb2d5c49ddf3168e31bce090e1dd122fe32e3705f8d0d670bc"
chnset 0.29999999999999999, "__vcs_perf_760f28410509b22de02893ffd96a9dc3b5fd6652ddc31ce462a827853871ec61"
chnset 0.14999999999999999, "__vcs_perf_580886d291fd5f84198c055bfe90349487f8b28ebe0eaacbc5f2c5d62078aed8"
chnset 2.5, "__vcs_perf_a9715bcb9e537a012079e8c1fae8e7c69106df97e14681c5583532445934cfea"
chnset 0.34999999999999998, "__vcs_perf_5a94f773f39f1a4865b25302f4f87693ed0ba505352f39638a974aecad3d977c"
chnset 0.59999999999999998, "__vcs_perf_d0026d433be3faabd992ea1dbca7ead5727b4816009a9f1ee44c1aecf507da2f"
connect "vcs_mix_1dc1baf55c97903a3ec0b1d9", "left", "vcs_mix_e1d7e481eb08ca2b9fc71c78", "p_360f84035942243c6a36537a"
connect "vcs_mix_1dc1baf55c97903a3ec0b1d9", "right", "vcs_mix_e1d7e481eb08ca2b9fc71c78", "p_27042f4e6eca7d0b2a7ee402"
connect "vcs_mix_63254fa67083d5eed1f09ece", "__vcs_direct_e0ee8bb50685e05fa0f47ed0_left", "vcs_mix_0644eeee2942927583ef32ed", "p_2336acbd28828ab05deafe52"
connect "vcs_mix_63254fa67083d5eed1f09ece", "__vcs_direct_e0ee8bb50685e05fa0f47ed0_right", "vcs_mix_0644eeee2942927583ef32ed", "p_2a250433534f9aea9d512171"
connect "vcs_mix_233b9a10d13cb7345fe0ac51", "pre_p_360f84035942243c6a36537a", "vcs_mix_776a9ca62745889b1ae2494d", "pre"
connect "vcs_mix_233b9a10d13cb7345fe0ac51", "post_p_360f84035942243c6a36537a", "vcs_mix_776a9ca62745889b1ae2494d", "post"
connect "vcs_mix_776a9ca62745889b1ae2494d", "out", "vcs_mix_63254fa67083d5eed1f09ece", "left"
connect "vcs_mix_233b9a10d13cb7345fe0ac51", "pre_p_27042f4e6eca7d0b2a7ee402", "vcs_mix_38e2e3dd71d7c951b8ee623c", "pre"
connect "vcs_mix_233b9a10d13cb7345fe0ac51", "post_p_27042f4e6eca7d0b2a7ee402", "vcs_mix_38e2e3dd71d7c951b8ee623c", "post"
connect "vcs_mix_38e2e3dd71d7c951b8ee623c", "out", "vcs_mix_63254fa67083d5eed1f09ece", "right"
connect "vcs_mix_d69e2b115c3aedc5f5e51463", "pre_p_360f84035942243c6a36537a", "vcs_mix_bf77b782450578498a75e856", "pre"
connect "vcs_mix_d69e2b115c3aedc5f5e51463", "post_p_360f84035942243c6a36537a", "vcs_mix_bf77b782450578498a75e856", "post"
connect "vcs_mix_bf77b782450578498a75e856", "out", "vcs_mix_63254fa67083d5eed1f09ece", "left"
connect "vcs_mix_d69e2b115c3aedc5f5e51463", "pre_p_27042f4e6eca7d0b2a7ee402", "vcs_mix_7d28de53beb30deccc25fc17", "pre"
connect "vcs_mix_d69e2b115c3aedc5f5e51463", "post_p_27042f4e6eca7d0b2a7ee402", "vcs_mix_7d28de53beb30deccc25fc17", "post"
connect "vcs_mix_7d28de53beb30deccc25fc17", "out", "vcs_mix_63254fa67083d5eed1f09ece", "right"
connect "vcs_mix_d128d928004c9323f776f93a", "pre_p_360f84035942243c6a36537a", "vcs_mix_725f6223d9072d1bb2e23c76", "pre"
connect "vcs_mix_d128d928004c9323f776f93a", "post_p_360f84035942243c6a36537a", "vcs_mix_725f6223d9072d1bb2e23c76", "post"
connect "vcs_mix_725f6223d9072d1bb2e23c76", "out", "vcs_mix_63254fa67083d5eed1f09ece", "left"
connect "vcs_mix_d128d928004c9323f776f93a", "pre_p_27042f4e6eca7d0b2a7ee402", "vcs_mix_d04fd17777bbf3b8af8783a5", "pre"
connect "vcs_mix_d128d928004c9323f776f93a", "post_p_27042f4e6eca7d0b2a7ee402", "vcs_mix_d04fd17777bbf3b8af8783a5", "post"
connect "vcs_mix_d04fd17777bbf3b8af8783a5", "out", "vcs_mix_63254fa67083d5eed1f09ece", "right"
connect "vcs_mix_96411e998269110c17432444", "pre_p_360f84035942243c6a36537a", "vcs_mix_b99cad66f5a693384ddaaa91", "pre"
connect "vcs_mix_96411e998269110c17432444", "post_p_360f84035942243c6a36537a", "vcs_mix_b99cad66f5a693384ddaaa91", "post"
connect "vcs_mix_b99cad66f5a693384ddaaa91", "out", "vcs_mix_63254fa67083d5eed1f09ece", "left"
connect "vcs_mix_96411e998269110c17432444", "pre_p_27042f4e6eca7d0b2a7ee402", "vcs_mix_bf6f81fb9ed80577ae278764", "pre"
connect "vcs_mix_96411e998269110c17432444", "post_p_27042f4e6eca7d0b2a7ee402", "vcs_mix_bf6f81fb9ed80577ae278764", "post"
connect "vcs_mix_bf6f81fb9ed80577ae278764", "out", "vcs_mix_63254fa67083d5eed1f09ece", "right"
connect "vcs_mix_8a252033ed35df6ff80fdae8", "pre_p_360f84035942243c6a36537a", "vcs_mix_72eedbbbd4d867877d198844", "pre"
connect "vcs_mix_8a252033ed35df6ff80fdae8", "post_p_360f84035942243c6a36537a", "vcs_mix_72eedbbbd4d867877d198844", "post"
connect "vcs_mix_72eedbbbd4d867877d198844", "out", "vcs_mix_63254fa67083d5eed1f09ece", "left"
connect "vcs_mix_8a252033ed35df6ff80fdae8", "pre_p_27042f4e6eca7d0b2a7ee402", "vcs_mix_bf26ce664958883e5fa5077a", "pre"
connect "vcs_mix_8a252033ed35df6ff80fdae8", "post_p_27042f4e6eca7d0b2a7ee402", "vcs_mix_bf26ce664958883e5fa5077a", "post"
connect "vcs_mix_bf26ce664958883e5fa5077a", "out", "vcs_mix_63254fa67083d5eed1f09ece", "right"
connect "vcs_mix_ac92f39f17c2687b02e604f4", "pre_p_360f84035942243c6a36537a", "vcs_mix_9f8ea62d9094b1ee06064c74", "pre"
connect "vcs_mix_ac92f39f17c2687b02e604f4", "post_p_360f84035942243c6a36537a", "vcs_mix_9f8ea62d9094b1ee06064c74", "post"
connect "vcs_mix_9f8ea62d9094b1ee06064c74", "out", "vcs_mix_63254fa67083d5eed1f09ece", "left"
connect "vcs_mix_ac92f39f17c2687b02e604f4", "pre_p_27042f4e6eca7d0b2a7ee402", "vcs_mix_ab29dbdb974d3cf3720ccde1", "pre"
connect "vcs_mix_ac92f39f17c2687b02e604f4", "post_p_27042f4e6eca7d0b2a7ee402", "vcs_mix_ab29dbdb974d3cf3720ccde1", "post"
connect "vcs_mix_ab29dbdb974d3cf3720ccde1", "out", "vcs_mix_63254fa67083d5eed1f09ece", "right"
connect "vcs_mix_c5cc5b5de6f0d6ab45b331f7", "pre_p_360f84035942243c6a36537a", "vcs_mix_a0bf5a6e682d1681b8c6dcab", "pre"
connect "vcs_mix_c5cc5b5de6f0d6ab45b331f7", "post_p_360f84035942243c6a36537a", "vcs_mix_a0bf5a6e682d1681b8c6dcab", "post"
connect "vcs_mix_a0bf5a6e682d1681b8c6dcab", "out", "vcs_mix_63254fa67083d5eed1f09ece", "left"
connect "vcs_mix_c5cc5b5de6f0d6ab45b331f7", "pre_p_27042f4e6eca7d0b2a7ee402", "vcs_mix_5e006bf5e9b69c39e6038e0c", "pre"
connect "vcs_mix_c5cc5b5de6f0d6ab45b331f7", "post_p_27042f4e6eca7d0b2a7ee402", "vcs_mix_5e006bf5e9b69c39e6038e0c", "post"
connect "vcs_mix_5e006bf5e9b69c39e6038e0c", "out", "vcs_mix_63254fa67083d5eed1f09ece", "right"
connect "vcs_mix_3fb9b3909cb149df8c692155", "pre_p_360f84035942243c6a36537a", "vcs_mix_7a9040b07366a0daa7dc6894", "pre"
connect "vcs_mix_3fb9b3909cb149df8c692155", "post_p_360f84035942243c6a36537a", "vcs_mix_7a9040b07366a0daa7dc6894", "post"
connect "vcs_mix_7a9040b07366a0daa7dc6894", "out", "vcs_mix_63254fa67083d5eed1f09ece", "left"
connect "vcs_mix_3fb9b3909cb149df8c692155", "pre_p_27042f4e6eca7d0b2a7ee402", "vcs_mix_898dca64f18bed88c536cb6b", "pre"
connect "vcs_mix_3fb9b3909cb149df8c692155", "post_p_27042f4e6eca7d0b2a7ee402", "vcs_mix_898dca64f18bed88c536cb6b", "post"
connect "vcs_mix_898dca64f18bed88c536cb6b", "out", "vcs_mix_63254fa67083d5eed1f09ece", "right"
connect "vcs_mix_e1d7e481eb08ca2b9fc71c78", "pre_p_360f84035942243c6a36537a", "vcs_mix_e07cbf7b561e14be9651d6d0", "pre"
connect "vcs_mix_e1d7e481eb08ca2b9fc71c78", "post_p_360f84035942243c6a36537a", "vcs_mix_e07cbf7b561e14be9651d6d0", "post"
connect "vcs_mix_e07cbf7b561e14be9651d6d0", "out", "vcs_mix_63254fa67083d5eed1f09ece", "left"
connect "vcs_mix_e1d7e481eb08ca2b9fc71c78", "pre_p_27042f4e6eca7d0b2a7ee402", "vcs_mix_9fa67706cd4495d936a25713", "pre"
connect "vcs_mix_e1d7e481eb08ca2b9fc71c78", "post_p_27042f4e6eca7d0b2a7ee402", "vcs_mix_9fa67706cd4495d936a25713", "post"
connect "vcs_mix_9fa67706cd4495d936a25713", "out", "vcs_mix_63254fa67083d5eed1f09ece", "right"
connect "vcs_mix_0644eeee2942927583ef32ed", "pre_p_2336acbd28828ab05deafe52", "vcs_mix_ec8b1641891924a3e102560a", "pre"
connect "vcs_mix_0644eeee2942927583ef32ed", "post_p_2336acbd28828ab05deafe52", "vcs_mix_ec8b1641891924a3e102560a", "post"
connect "vcs_mix_ec8b1641891924a3e102560a", "out", "vcs_mix_9cea1be1f8255375a6cf7b93", "left"
connect "vcs_mix_0644eeee2942927583ef32ed", "pre_p_2a250433534f9aea9d512171", "vcs_mix_5f16b779ade2ce91f307ff35", "pre"
connect "vcs_mix_0644eeee2942927583ef32ed", "post_p_2a250433534f9aea9d512171", "vcs_mix_5f16b779ade2ce91f307ff35", "post"
connect "vcs_mix_5f16b779ade2ce91f307ff35", "out", "vcs_mix_9cea1be1f8255375a6cf7b93", "right"
; Continuous patches and mixer stages start with alwayson; note instruments start from MIDI/score events.
alwayson "vcs_mix_d69e2b115c3aedc5f5e51463"
alwayson "vcs_mix_bf77b782450578498a75e856"
alwayson "vcs_mix_7d28de53beb30deccc25fc17"
alwayson "vcs_mix_96411e998269110c17432444"
alwayson "vcs_mix_b99cad66f5a693384ddaaa91"
alwayson "vcs_mix_bf6f81fb9ed80577ae278764"
alwayson "vcs_mix_233b9a10d13cb7345fe0ac51"
alwayson "vcs_mix_776a9ca62745889b1ae2494d"
alwayson "vcs_mix_38e2e3dd71d7c951b8ee623c"
alwayson "vcs_mix_3fb9b3909cb149df8c692155"
alwayson "vcs_mix_7a9040b07366a0daa7dc6894"
alwayson "vcs_mix_898dca64f18bed88c536cb6b"
alwayson "vcs_mix_d128d928004c9323f776f93a"
alwayson "vcs_mix_725f6223d9072d1bb2e23c76"
alwayson "vcs_mix_d04fd17777bbf3b8af8783a5"
alwayson "vcs_mix_ac92f39f17c2687b02e604f4"
alwayson "vcs_mix_9f8ea62d9094b1ee06064c74"
alwayson "vcs_mix_ab29dbdb974d3cf3720ccde1"
alwayson "vcs_mix_c5cc5b5de6f0d6ab45b331f7"
alwayson "vcs_mix_a0bf5a6e682d1681b8c6dcab"
alwayson "vcs_mix_5e006bf5e9b69c39e6038e0c"
alwayson "vcs_mix_8a252033ed35df6ff80fdae8"
alwayson "vcs_mix_72eedbbbd4d867877d198844"
alwayson "vcs_mix_bf26ce664958883e5fa5077a"
alwayson "vcs_mix_e1d7e481eb08ca2b9fc71c78"
alwayson "vcs_mix_e07cbf7b561e14be9651d6d0"
alwayson "vcs_mix_9fa67706cd4495d936a25713"
alwayson "vcs_mix_63254fa67083d5eed1f09ece"
alwayson "vcs_mix_0644eeee2942927583ef32ed"
alwayson "vcs_mix_ec8b1641891924a3e102560a"
alwayson "vcs_mix_5f16b779ade2ce91f307ff35"
alwayson "vcs_mix_9cea1be1f8255375a6cf7b93"
; mixer stage patch:bass
; patch:d6a771a3-056b-4a69-9ddc-0abaed75603b name:EBM DW — Sequencer Bass channel:1 always_on:false
; instance:bass csound:vcs_mix_33dc83ab9904e9526f7091d6
; description: Lean dry pulse/saw bass for short external sixteenth-note sequences. Velocity changes filter brightness; no built-in sequencer. Suggested MIDI 28–60. Velocity-sensitive; settings apply to new notes. Motion rates are Hz; echoes are fixed time. Route Stereo Output through the mixer to Master.
; trigger: MIDI channel 1 / score notes; score instrument number: 1
instr vcs_mix_33dc83ab9904e9526f7091d6
 i_vcs_internal_score_note_p4 = p4
 i_vcs_internal_score_velocity_p5 = p5
 i_ctl_accent_iout_10 chnget "__vcs_perf_3a3412564c51b46a1b2b5932e893c5377f697dde5eae688cc584ccdfcb58fea3"
 i_ctl_attack_iout_5 chnget "__vcs_perf_01cfe3facecca6f98f75a7d657f6b72de14cbcb96689449b53aa2ae1a2a7c2a4"
 i_ctl_decay_iout_9 chnget "__vcs_perf_8aec72c06cb403170c8ac63a0d5a94d557081def0437f1a9d96c5b04d0361dfb"
 i_ctl_drive_iout_11 chnget "__vcs_perf_6333461785375abfa3e1e56d0c4e5251693489c7f876994084fb955d2e46bb7f"
 i_ctl_release_iout_6 chnget "__vcs_perf_efbeab3b8275658b2b792cc65c6d372a9e0d68e5688f983cd2727a48127bf431"
 i_ctl_resonance_iout_8 chnget "__vcs_perf_a1a8c8efcf62954b467a2b3f810241abdcb02d8b13aee6af47a82e95ddd85faa"
 i_ctl_tone_iout_7 chnget "__vcs_perf_176a9d6c90e45f3a5c879b4295e6221cb45d64776c1f57ce4ab80488b1189302"
 ; node:env_sustain_const opcode:const_i
 i_env_sustain_const_iout_4 = 0.08
 ; node:pitch_cpsmidi opcode:cpsmidi
 i_pitch_cpsmidi_kfreq_1 = cpsmidinn(p4)
 ; node:pulse_gain opcode:const_k
 k_pulse_gain_kout_3 = 0.15
 ; node:saw_a_gain opcode:const_k
 k_saw_a_gain_kout_5 = 0.09
 ; node:velocity_scale_const opcode:const_i
 i_velocity_scale_const_iout_2 = 1.0
 ; node:filter_decay_envelope opcode:linseg
 k_filter_decay_envelope_kenv_7 linseg 1, i_ctl_decay_iout_9, 0
 ; node:amp_madsr opcode:madsr
 k_amp_madsr_kenv_1 madsr i_ctl_attack_iout_5, i_ctl_decay_iout_9, i_env_sustain_const_iout_4, i_ctl_release_iout_6, 0, -1
 ; node:velocity_ampmidi opcode:ampmidi
 i_velocity_ampmidi_iamp_3 = ((p5 / 128) * (i_velocity_scale_const_iout_2))
 ; node:amp_velocity_envelope opcode:k_mul
 k_amp_velocity_envelope_kout_2 = (i_velocity_ampmidi_iamp_3) * (k_amp_madsr_kenv_1)
 ; node:pulse_amp opcode:k_mul
 k_pulse_amp_kout_4 = (k_amp_velocity_envelope_kout_2) * (k_pulse_gain_kout_3)
 ; node:saw_a_amp opcode:k_mul
 k_saw_a_amp_kout_6 = (k_amp_velocity_envelope_kout_2) * (k_saw_a_gain_kout_5)
 ; node:pulse_vco2 opcode:vco2
 a_pulse_vco2_asig_1 vco2 k_pulse_amp_kout_4, i_pitch_cpsmidi_kfreq_1, 2, 0.5, 0, 0.5
 ; node:saw_a_vco2 opcode:vco2
 a_saw_a_vco2_asig_2 vco2 k_saw_a_amp_kout_6, (i_pitch_cpsmidi_kfreq_1 * 0.9965), 0, 0.5, 0, 0.5
 ; node:source_sum opcode:mix2
 a_source_sum_aout_5 = ((a_pulse_vco2_asig_1 + a_saw_a_vco2_asig_2)) + (0)
 ; node:voice_filter opcode:moogladder2
 a_voice_filter_aout_6 moogladder2 a_source_sum_aout_5, (i_ctl_tone_iout_7 + ((2600 * k_filter_decay_envelope_kenv_7) * ((.2 + ((.8 * i_velocity_ampmidi_iamp_3) * i_ctl_accent_iout_10))))), i_ctl_resonance_iout_8
 ; node:saturation opcode:distort1
 a_saturation_aout_7 distort1 a_voice_filter_aout_6, (i_ctl_drive_iout_11 * 3), (1 / ((1 + (.55 * ((i_ctl_drive_iout_11 - 1)))))), 0, 0, 1
 ; node:dc_filter opcode:butterhp
 a_dc_filter_aout_8 butterhp a_saturation_aout_7, 22, 0
 ; node:output_pan2 opcode:pan2
 a_output_pan2_aleft_3, a_output_pan2_aright_4 pan2 (a_dc_filter_aout_8 * 0.58), 0.5, 0
 ; node:output_left opcode:outleta
 outleta "left", a_output_pan2_aleft_3
 ; node:output_right opcode:outleta
 outleta "right", a_output_pan2_aright_4
endin

; mixer stage patch:clouds
; patch:1c823ae5-f5f5-4cbf-ac3b-4ca883fb6b68 name:EBM DW — Dark PWM Pad channel:3 always_on:false
; instance:clouds csound:vcs_mix_2caaf50d4b3b53e2f4ee2efb
; description: Shadowy triangle/pulse pad with slow PWM and filter movement, chorus and restrained reverb. Suggested MIDI 43–79. Velocity-sensitive; settings apply to new notes. Motion rates are Hz; echoes are fixed time. Route Stereo Output through the mixer to Master.
; trigger: MIDI channel 3 / score notes; score instrument number: 2
instr vcs_mix_2caaf50d4b3b53e2f4ee2efb
 i_vcs_internal_score_note_p4 = p4
 i_vcs_internal_score_velocity_p5 = p5
 ; node:chorus_left_lfo opcode:lfo
 k_chorus_left_lfo_kout_8 lfo 1, 0.23, 0
 ; node:chorus_right_lfo opcode:lfo
 k_chorus_right_lfo_kout_9 lfo 1, 0.31, 0
 i_ctl_attack_iout_6 chnget "__vcs_perf_3c456691c46e0004e9f68642bf628b78230761b885805d730fdaba837aba84c6"
 i_ctl_motion_depth_iout_10 chnget "__vcs_perf_c9b8a10bc7395e56c4f1e58b78ee975bc85395a8cfe4ee24559391e90b63d4ba"
 i_ctl_motion_rate_iout_11 chnget "__vcs_perf_6972386ce10da486d8150798b5fd31dd6370b22fa8ca9f84aaa59c2622d09633"
 i_ctl_pulse_blend_iout_9 chnget "__vcs_perf_135d781e2454b4e48599806b742e6e89762c5b1d5594a01c44baf7c3c5f7461f"
 i_ctl_release_iout_7 chnget "__vcs_perf_81eaa4a2bc2176bb0c4d870fa86fa96c4e691060bf41e4ce9778ffd6ad1a66ce"
 i_ctl_space_iout_12 chnget "__vcs_perf_e4492eb704bc9e3de2c33e65258c0cafca515039a9524b5e12d8010bd143066f"
 i_ctl_tone_iout_8 chnget "__vcs_perf_3352e2f8d65a84dfe6f573916ccef49d7f2c55e840e5aafac7d5a9046bafda8b"
 ; node:env_decay_const opcode:const_i
 i_env_decay_const_iout_4 = 2.0
 ; node:env_sustain_const opcode:const_i
 i_env_sustain_const_iout_5 = 0.75
 ; node:pitch_cpsmidi opcode:cpsmidi
 i_pitch_cpsmidi_kfreq_1 = cpsmidinn(p4)
 ; node:pulse_gain opcode:const_k
 k_pulse_gain_kout_5 = 0.15
 ; node:triangle_gain opcode:const_k
 k_triangle_gain_kout_3 = 0.2
 ; node:velocity_scale_const opcode:const_i
 i_velocity_scale_const_iout_2 = 1.0
 ; node:motion_lfo opcode:lfo
 k_motion_lfo_kout_7 lfo 1, i_ctl_motion_rate_iout_11, 0
 ; node:effect_tail opcode:xtratim
 xtratim (i_ctl_release_iout_7 + 10.0)
 ; node:audio_ctl_space_iout opcode:k_to_a
 a_audio_ctl_space_iout_aout_12 interp i_ctl_space_iout_12
 ; node:amp_madsr opcode:madsr
 k_amp_madsr_kenv_1 madsr i_ctl_attack_iout_6, i_env_decay_const_iout_4, i_env_sustain_const_iout_5, i_ctl_release_iout_7, 0, -1
 ; node:velocity_ampmidi opcode:ampmidi
 i_velocity_ampmidi_iamp_3 = ((p5 / 128) * (i_velocity_scale_const_iout_2))
 ; node:amp_velocity_envelope opcode:k_mul
 k_amp_velocity_envelope_kout_2 = (i_velocity_ampmidi_iamp_3) * (k_amp_madsr_kenv_1)
 ; node:pulse_amp opcode:k_mul
 k_pulse_amp_kout_6 = ((k_amp_velocity_envelope_kout_2 * i_ctl_pulse_blend_iout_9)) * (k_pulse_gain_kout_5)
 ; node:triangle_amp opcode:k_mul
 k_triangle_amp_kout_4 = ((k_amp_velocity_envelope_kout_2 * ((1 - (.6 * i_ctl_pulse_blend_iout_9))))) * (k_triangle_gain_kout_3)
 ; node:pulse_vco2 opcode:vco2
 a_pulse_vco2_asig_2 vco2 k_pulse_amp_kout_6, i_pitch_cpsmidi_kfreq_1, 2, (.5 + ((.2 * i_ctl_motion_depth_iout_10) * k_motion_lfo_kout_7)), 0, 0.5
 ; node:triangle_vco2 opcode:vco2
 a_triangle_vco2_asig_1 vco2 k_triangle_amp_kout_4, i_pitch_cpsmidi_kfreq_1, 12, 0.5, 0, 0.5
 ; node:source_sum opcode:mix2
 a_source_sum_aout_5 = ((a_triangle_vco2_asig_1 + a_pulse_vco2_asig_2)) + (0)
 ; node:voice_filter opcode:moogladder2
 a_voice_filter_aout_6 moogladder2 a_source_sum_aout_5, (i_ctl_tone_iout_8 * ((1 + ((.45 * i_ctl_motion_depth_iout_10) * k_motion_lfo_kout_7)))), 0.18
 ; node:dc_filter opcode:butterhp
 a_dc_filter_aout_7 butterhp a_voice_filter_aout_6, 22, 0
 ; node:output_pan2 opcode:pan2
 a_output_pan2_aleft_3, a_output_pan2_aright_4 pan2 a_dc_filter_aout_7, 0.5, 0
 ; node:chorus_left opcode:vdelay3
 a_chorus_left_aout_8 vdelay3 a_output_pan2_aleft_3, (14 + (3 * k_chorus_left_lfo_kout_8)), 35
 ; node:chorus_right opcode:vdelay3
 a_chorus_right_aout_15 vdelay3 a_output_pan2_aright_4, (19 + (3 * k_chorus_right_lfo_kout_9)), 35
 ; node:chorus_mix_left opcode:mix2
 a_chorus_mix_left_aout_9 = (((a_output_pan2_aleft_3 * 0.9125) + (a_chorus_left_aout_8 * 0.175))) + (0)
 ; node:chorus_mix_right opcode:mix2
 a_chorus_mix_right_aout_16 = (((a_output_pan2_aright_4 * 0.9125) + (a_chorus_right_aout_15 * 0.175))) + (0)
 ; node:room_predelay_left opcode:delay
 a_room_predelay_left_aout_10 delay a_chorus_mix_left_aout_9, 0.017, 0
 ; node:room_predelay_right opcode:delay
 a_room_predelay_right_aout_17 delay a_chorus_mix_right_aout_16, 0.029, 0
 ; node:room_left opcode:reverb2
 a_room_left_aout_11 reverb2 a_room_predelay_left_aout_10, 2.5, 0.45, 0
 ; node:room_right opcode:reverb2
 a_room_right_aout_18 reverb2 a_room_predelay_right_aout_17, 2.325, 0.45, 0
 ; node:room_mix_left opcode:mix2
 a_room_mix_left_aout_13 = ((a_chorus_mix_left_aout_9 + (a_audio_ctl_space_iout_aout_12 * a_room_left_aout_11))) + (0)
 ; node:room_mix_right opcode:mix2
 a_room_mix_right_aout_19 = ((a_chorus_mix_right_aout_16 + (a_audio_ctl_space_iout_aout_12 * a_room_right_aout_18))) + (0)
 ; node:final_level_left opcode:mix2
 a_final_level_left_aout_14 = ((a_room_mix_left_aout_13 * 0.5)) + (0)
 ; node:final_level_right opcode:mix2
 a_final_level_right_aout_20 = ((a_room_mix_right_aout_19 * 0.5)) + (0)
 ; node:output_left opcode:outleta
 outleta "left", a_final_level_left_aout_14
 ; node:output_right opcode:outleta
 outleta "right", a_final_level_right_aout_20
endin

; mixer stage patch:drums
; patch:979b006c-d2a5-47c1-836c-9f3f30453ddf name:Analog Drumkit channel:10 always_on:false
; instance:drums csound:vcs_mix_4f507889dae17bb5de425c56
; description: Five velocity-sensitive analog synthesis voices selected by MIDI notnum through Switch. MIDI notenum 35: Bass drum (pitch-swept sine + click); 36: Bass drum distorted (saturated sine + click); 46: Hi-hat open (700 ms); 42: Hi-hat closed (85 ms); 38: Snare (two sine resonances + filtered noise). Hats use six inharmonic square oscillators plus noise. One-shot decays survive short MIDI note-offs. Silent default; stereo output; no samples. GM bass-drum slot 36 is used for the distorted variation.
; trigger: MIDI channel 10 / score notes; score instrument number: 3
instr vcs_mix_4f507889dae17bb5de425c56
 i_vcs_internal_score_note_p4 = p4
 i_vcs_internal_score_velocity_p5 = p5
 ; node:note opcode:notnum
 i_note_inote_1 = p4
 ; node:velocity_scale opcode:const_i
 i_velocity_scale_iout_2 = 1
 ; node:velocity opcode:ampmidi
 i_velocity_iamp_3 = ((p5 / 128) * (i_velocity_scale_iout_2))
 ; node:kit opcode:Switch
 if (i_note_inote_1) == 35.0 then
   ; case:bass_drum Bass drum
   i_9da04da0_dadc_4020_888b_dec37077e0bc_iout_6 chnget "__vcs_perf_c47136601b6ea4e6370e270f9091838a70a71eaf9ef19a1000a71c57c70ca657"
   ; node:bass_drum_click_env opcode:expseg
   k_bass_drum_click_env_kenv_4 expseg 1, 0.012, 0.0001
   ; node:bass_drum_decay opcode:expseg
   k_bass_drum_decay_kenv_2 expseg 1, 0.129, 0.16, 0.301, 0.0001
   ; node:bass_drum_gate opcode:linseg
   k_bass_drum_gate_kenv_1 linseg 0, 0.001, 1, 0.421, 1, 0.008, 0
   ; node:bass_drum_pitch opcode:expseg
   k_bass_drum_pitch_kenv_3 expseg 165, 0.026, 57, 0.2, 46
   ; node:bass_drum_tail opcode:xtratim
   xtratim 0.455
   ; node:bass_drum_click opcode:noise
   a_bass_drum_click_aout_4 noise (k_bass_drum_click_env_kenv_4 * 0.14), 0
   ; node:bass_drum_amplitude opcode:upsamp
   a_bass_drum_amplitude_aout_7 upsamp (((k_bass_drum_decay_kenv_2 * k_bass_drum_gate_kenv_1) * i_velocity_iamp_3) * 0.52)
   ; node:bass_drum_tone opcode:oscili
   a_bass_drum_tone_asig_3 oscili 1, (k_bass_drum_pitch_kenv_3 * i_9da04da0_dadc_4020_888b_dec37077e0bc_iout_6), -1
   ; node:bass_drum_click_filter opcode:butterbp
   a_bass_drum_click_filter_aout_5 butterbp a_bass_drum_click_aout_4, 2200, 2500, 0
   ; node:bass_drum_mix opcode:mix2
   a_bass_drum_mix_aout_6 = (a_bass_drum_tone_asig_3) + (a_bass_drum_click_filter_aout_5)
   ; node:bass_drum_pan opcode:pan2
   a_bass_drum_pan_aleft_8, a_bass_drum_pan_aright_9 pan2 (a_bass_drum_mix_aout_6 * a_bass_drum_amplitude_aout_7), 0.5, 0
   a_kit_left_1 = a_bass_drum_pan_aleft_8
   a_kit_right_2 = a_bass_drum_pan_aright_9
 elseif (i_note_inote_1) == 36.0 then
   ; case:bass_drum_distorted Bass drum distorted
   i_1a9be505_b7fe_4d12_a783_60346b810c6a_iout_7 chnget "__vcs_perf_ad3c93d48fb5770da355be457ab89395386f05f9c5d130d292997b1e0d7d8c35"
   i_460f9e29_fa38_4055_8f7b_c9f7d7ebe7aa_iout_5 chnget "__vcs_perf_eab19a28d880be28fa5d086db1ac0c2039558b54d61d0c2c3b147dadb7c011cd"
   ; node:bass_drum_distorted_click_env opcode:expseg
   k_bass_drum_distorted_click_env_kenv_8 expseg 1, 0.012, 0.0001
   ; node:bass_drum_distorted_decay opcode:expseg
   k_bass_drum_distorted_decay_kenv_6 expseg 1, 0.108, 0.16, 0.252, 0.0001
   ; node:bass_drum_distorted_gate opcode:linseg
   k_bass_drum_distorted_gate_kenv_5 linseg 0, 0.001, 1, 0.351, 1, 0.008, 0
   ; node:bass_drum_distorted_pitch opcode:expseg
   k_bass_drum_distorted_pitch_kenv_7 expseg 190, 0.026, 57, 0.2, 49
   ; node:bass_drum_distorted_tail opcode:xtratim
   xtratim 0.385
   i_ddccf62d_f9e6_49f3_a0dc_f438c7783415_iout_4 chnget "__vcs_perf_a647f3b1a6eef979fd4b84ef7e00100e16030190a47530e1e8b14be603e6a934"
   ; node:bass_drum_distorted_click opcode:noise
   a_bass_drum_distorted_click_aout_11 noise (k_bass_drum_distorted_click_env_kenv_8 * 0.14), 0
   ; node:bass_drum_distorted_amplitude opcode:upsamp
   a_bass_drum_distorted_amplitude_aout_17 upsamp (((k_bass_drum_distorted_decay_kenv_6 * k_bass_drum_distorted_gate_kenv_5) * i_velocity_iamp_3) * 0.47)
   ; node:bass_drum_distorted_tone opcode:oscili
   a_bass_drum_distorted_tone_asig_10 oscili 1, (k_bass_drum_distorted_pitch_kenv_7 * i_1a9be505_b7fe_4d12_a783_60346b810c6a_iout_7), -1
   ; node:bass_drum_distorted_click_filter opcode:butterbp
   a_bass_drum_distorted_click_filter_aout_12 butterbp a_bass_drum_distorted_click_aout_11, 2200, 2500, 0
   ; node:bass_drum_distorted_mix opcode:mix2
   a_bass_drum_distorted_mix_aout_13 = (a_bass_drum_distorted_tone_asig_10) + (a_bass_drum_distorted_click_filter_aout_12)
   ; node:bass_drum_distorted_drive opcode:distort1
   a_bass_drum_distorted_drive_aout_14 distort1 a_bass_drum_distorted_mix_aout_13, i_ddccf62d_f9e6_49f3_a0dc_f438c7783415_iout_4, i_460f9e29_fa38_4055_8f7b_c9f7d7ebe7aa_iout_5, 0, 0, 1
   ; node:bass_drum_distorted_lowpass opcode:butterlp
   a_bass_drum_distorted_lowpass_aout_15 butterlp a_bass_drum_distorted_drive_aout_14, 3800, 0
   ; node:bass_drum_distorted_dc_filter opcode:butterhp
   a_bass_drum_distorted_dc_filter_aout_16 butterhp a_bass_drum_distorted_lowpass_aout_15, 22, 0
   ; node:bass_drum_distorted_pan opcode:pan2
   a_bass_drum_distorted_pan_aleft_18, a_bass_drum_distorted_pan_aright_19 pan2 (a_bass_drum_distorted_dc_filter_aout_16 * a_bass_drum_distorted_amplitude_aout_17), 0.5, 0
   a_kit_left_1 = a_bass_drum_distorted_pan_aleft_18
   a_kit_right_2 = a_bass_drum_distorted_pan_aright_19
 elseif (i_note_inote_1) == 46.0 then
   ; case:hihat_open Hi-hat open
   ; node:hihat_open_air opcode:noise
   a_hihat_open_air_aout_26 noise 0.24, 0
   ; node:hihat_open_decay opcode:expseg
   k_hihat_open_decay_kenv_10 expseg 1, 0.21, 0.16, 0.48999999999999994, 0.0001
   ; node:hihat_open_gate opcode:linseg
   k_hihat_open_gate_kenv_9 linseg 0, 0.001, 1, 0.691, 1, 0.008, 0
   ; node:hihat_open_metal_1 opcode:vco2
   a_hihat_open_metal_1_asig_20 vco2 0.16, 205.3, 2, 0.5, 0.137, 0.5
   ; node:hihat_open_metal_2 opcode:vco2
   a_hihat_open_metal_2_asig_21 vco2 0.16, 304.4, 2, 0.5, 0.274, 0.5
   ; node:hihat_open_metal_3 opcode:vco2
   a_hihat_open_metal_3_asig_22 vco2 0.16, 369.6, 2, 0.5, 0.41100000000000003, 0.5
   ; node:hihat_open_metal_4 opcode:vco2
   a_hihat_open_metal_4_asig_23 vco2 0.16, 522.7, 2, 0.5, 0.548, 0.5
   ; node:hihat_open_metal_5 opcode:vco2
   a_hihat_open_metal_5_asig_24 vco2 0.16, 540.5, 2, 0.5, 0.685, 0.5
   ; node:hihat_open_metal_6 opcode:vco2
   a_hihat_open_metal_6_asig_25 vco2 0.16, 800, 2, 0.5, 0.8220000000000001, 0.5
   ; node:hihat_open_tail opcode:xtratim
   xtratim 0.725
   ; node:hihat_open_amplitude opcode:upsamp
   a_hihat_open_amplitude_aout_29 upsamp (((k_hihat_open_decay_kenv_10 * k_hihat_open_gate_kenv_9) * i_velocity_iamp_3) * 0.75)
   ; node:hihat_open_highpass opcode:butterhp
   a_hihat_open_highpass_aout_27 butterhp ((((((a_hihat_open_metal_1_asig_20 + a_hihat_open_metal_2_asig_21) + a_hihat_open_metal_3_asig_22) + a_hihat_open_metal_4_asig_23) + a_hihat_open_metal_5_asig_24) + a_hihat_open_metal_6_asig_25) + a_hihat_open_air_aout_26), 6500, 0
   ; node:hihat_open_lowpass opcode:butterlp
   a_hihat_open_lowpass_aout_28 butterlp a_hihat_open_highpass_aout_27, 12500, 0
   ; node:hihat_open_pan opcode:pan2
   a_hihat_open_pan_aleft_30, a_hihat_open_pan_aright_31 pan2 (a_hihat_open_lowpass_aout_28 * a_hihat_open_amplitude_aout_29), 0.55, 0
   a_kit_left_1 = a_hihat_open_pan_aleft_30
   a_kit_right_2 = a_hihat_open_pan_aright_31
 elseif (i_note_inote_1) == 42.0 then
   ; case:hihat_closed Hi-hat closed
   ; node:hihat_closed_air opcode:noise
   a_hihat_closed_air_aout_38 noise 0.24, 0
   ; node:hihat_closed_decay opcode:expseg
   k_hihat_closed_decay_kenv_12 expseg 1, 0.025500000000000002, 0.16, 0.0595, 0.0001
   ; node:hihat_closed_gate opcode:linseg
   k_hihat_closed_gate_kenv_11 linseg 0, 0.001, 1, 0.07600000000000001, 1, 0.008, 0
   ; node:hihat_closed_metal_1 opcode:vco2
   a_hihat_closed_metal_1_asig_32 vco2 0.16, 205.3, 2, 0.5, 0.137, 0.5
   ; node:hihat_closed_metal_2 opcode:vco2
   a_hihat_closed_metal_2_asig_33 vco2 0.16, 304.4, 2, 0.5, 0.274, 0.5
   ; node:hihat_closed_metal_3 opcode:vco2
   a_hihat_closed_metal_3_asig_34 vco2 0.16, 369.6, 2, 0.5, 0.41100000000000003, 0.5
   ; node:hihat_closed_metal_4 opcode:vco2
   a_hihat_closed_metal_4_asig_35 vco2 0.16, 522.7, 2, 0.5, 0.548, 0.5
   ; node:hihat_closed_metal_5 opcode:vco2
   a_hihat_closed_metal_5_asig_36 vco2 0.16, 540.5, 2, 0.5, 0.685, 0.5
   ; node:hihat_closed_metal_6 opcode:vco2
   a_hihat_closed_metal_6_asig_37 vco2 0.16, 800, 2, 0.5, 0.8220000000000001, 0.5
   ; node:hihat_closed_tail opcode:xtratim
   xtratim 0.11000000000000001
   ; node:hihat_closed_amplitude opcode:upsamp
   a_hihat_closed_amplitude_aout_41 upsamp (((k_hihat_closed_decay_kenv_12 * k_hihat_closed_gate_kenv_11) * i_velocity_iamp_3) * 0.75)
   ; node:hihat_closed_highpass opcode:butterhp
   a_hihat_closed_highpass_aout_39 butterhp ((((((a_hihat_closed_metal_1_asig_32 + a_hihat_closed_metal_2_asig_33) + a_hihat_closed_metal_3_asig_34) + a_hihat_closed_metal_4_asig_35) + a_hihat_closed_metal_5_asig_36) + a_hihat_closed_metal_6_asig_37) + a_hihat_closed_air_aout_38), 6500, 0
   ; node:hihat_closed_lowpass opcode:butterlp
   a_hihat_closed_lowpass_aout_40 butterlp a_hihat_closed_highpass_aout_39, 12500, 0
   ; node:hihat_closed_pan opcode:pan2
   a_hihat_closed_pan_aleft_42, a_hihat_closed_pan_aright_43 pan2 (a_hihat_closed_lowpass_aout_40 * a_hihat_closed_amplitude_aout_41), 0.55, 0
   a_kit_left_1 = a_hihat_closed_pan_aleft_42
   a_kit_right_2 = a_hihat_closed_pan_aright_43
 elseif (i_note_inote_1) == 38.0 then
   ; case:snare Snare
   ; node:snare_body_decay opcode:expseg
   k_snare_body_decay_kenv_15 expseg 1, 0.1, 0.0001
   ; node:snare_decay opcode:expseg
   k_snare_decay_kenv_14 expseg 1, 0.075, 0.16, 0.175, 0.0001
   ; node:snare_gate opcode:linseg
   k_snare_gate_kenv_13 linseg 0, 0.001, 1, 0.241, 1, 0.008, 0
   ; node:snare_pitch opcode:expseg
   k_snare_pitch_kenv_16 expseg 250, 0.018, 185
   ; node:snare_tail opcode:xtratim
   xtratim 0.275
   ; node:snare_wires opcode:noise
   a_snare_wires_aout_46 noise 1, 0
   ; node:snare_overtone opcode:oscili
   a_snare_overtone_asig_45 oscili (k_snare_body_decay_kenv_15 * 0.28), 330, -1
   ; node:snare_amplitude opcode:upsamp
   a_snare_amplitude_aout_50 upsamp (((k_snare_decay_kenv_14 * k_snare_gate_kenv_13) * i_velocity_iamp_3) * 0.42)
   ; node:snare_body opcode:oscili
   a_snare_body_asig_44 oscili (k_snare_body_decay_kenv_15 * 0.7), k_snare_pitch_kenv_16, -1
   ; node:snare_highpass opcode:butterhp
   a_snare_highpass_aout_47 butterhp a_snare_wires_aout_46, 1100, 0
   ; node:snare_lowpass opcode:butterlp
   a_snare_lowpass_aout_48 butterlp a_snare_highpass_aout_47, 8500, 0
   ; node:snare_mix opcode:mix2
   a_snare_mix_aout_49 = ((a_snare_body_asig_44 + a_snare_overtone_asig_45)) + (a_snare_lowpass_aout_48)
   ; node:snare_pan opcode:pan2
   a_snare_pan_aleft_51, a_snare_pan_aright_52 pan2 (a_snare_mix_aout_49 * a_snare_amplitude_aout_50), 0.5, 0
   a_kit_left_1 = a_snare_pan_aleft_51
   a_kit_right_2 = a_snare_pan_aright_52
 else
   ; case:default Default
   a_kit_left_1 = 0
   a_kit_right_2 = 0
 endif
 a_output_left_asignal_53 = (a_kit_left_1 * 3)
 a_output_right_asignal_54 = (a_kit_right_2 * 3)
 ; node:output_left opcode:outleta
 outleta "left", a_output_left_asignal_53
 ; node:output_right opcode:outleta
 outleta "right", a_output_right_asignal_54
endin

; mixer stage patch:glints
; patch:fac3faea-086f-448c-9581-8692bc30cca1 name:EBM DW — Glass Bell channel:7 always_on:false
; instance:glints csound:vcs_mix_c0bf79aa1787b85d72e90369
; description: Cold glass bell with an inharmonic two-operator FM strike, decaying brightness and dark echoes/reverb. Suggested MIDI 48–88. Velocity-sensitive; settings apply to new notes. Motion rates are Hz; echoes are fixed time. Route Stereo Output through the mixer to Master.
; trigger: MIDI channel 7 / score notes; score instrument number: 4
instr vcs_mix_c0bf79aa1787b85d72e90369
 i_vcs_internal_score_note_p4 = p4
 i_vcs_internal_score_velocity_p5 = p5
 i_ctl_attack_iout_5 chnget "__vcs_perf_7bed4733f2cf30ab8ececa1d061911d769efcf74c6a49d1363352814d8091472"
 i_ctl_decay_iout_9 chnget "__vcs_perf_4255b4799c2baaaf696d06577c5498543050bfad2e3c9df38feb483a5ce61527"
 i_ctl_fm_depth_iout_8 chnget "__vcs_perf_c9a8118403c5574b0b1d67f4efeae02fab27ff5b77321aa79b10229307175559"
 i_ctl_ratio_iout_7 chnget "__vcs_perf_9d08305573089857d94b349a6d4a4d1065452491475f587164539f8b97c99b81"
 i_ctl_release_iout_6 chnget "__vcs_perf_aad91d389043ff39f61e83a540ef1ff51ba1b339b9a30ff2cb86fbb90071bdfb"
 i_ctl_space_iout_11 chnget "__vcs_perf_bc7d83397c1478f832e5730a3fadc9b5b8f3ab7080c0f65681c43415706500a4"
 i_ctl_tone_iout_10 chnget "__vcs_perf_b46a371f9eccb05e777dad1449cbe3ec085a046adde92c0acc50c8aee0494010"
 ; node:env_sustain_const opcode:const_i
 i_env_sustain_const_iout_4 = 0.0
 ; node:fm_gain opcode:const_k
 k_fm_gain_kout_3 = 0.18
 ; node:pitch_cpsmidi opcode:cpsmidi
 i_pitch_cpsmidi_kfreq_1 = cpsmidinn(p4)
 ; node:velocity_scale_const opcode:const_i
 i_velocity_scale_const_iout_2 = 1.0
 ; node:fm_decay_envelope opcode:linseg
 k_fm_decay_envelope_kenv_5 linseg 1, i_ctl_decay_iout_9, 0
 ; node:effect_tail opcode:xtratim
 xtratim (i_ctl_release_iout_6 + 8.8)
 ; node:audio_ctl_space_iout opcode:k_to_a
 a_audio_ctl_space_iout_aout_12 interp i_ctl_space_iout_11
 ; node:amp_madsr opcode:madsr
 k_amp_madsr_kenv_1 madsr i_ctl_attack_iout_5, i_ctl_decay_iout_9, i_env_sustain_const_iout_4, i_ctl_release_iout_6, 0, -1
 ; node:velocity_ampmidi opcode:ampmidi
 i_velocity_ampmidi_iamp_3 = ((p5 / 128) * (i_velocity_scale_const_iout_2))
 ; node:amp_velocity_envelope opcode:k_mul
 k_amp_velocity_envelope_kout_2 = (i_velocity_ampmidi_iamp_3) * (k_amp_madsr_kenv_1)
 ; node:fm_amp opcode:k_mul
 k_fm_amp_kout_4 = (k_amp_velocity_envelope_kout_2) * (k_fm_gain_kout_3)
 ; node:fm_foscili opcode:foscili
 a_fm_foscili_asig_1 foscili k_fm_amp_kout_4, i_pitch_cpsmidi_kfreq_1, 1, i_ctl_ratio_iout_7, (i_ctl_fm_depth_iout_8 * ((.04 + (.96 * k_fm_decay_envelope_kenv_5)))), 1, 0
 ; node:voice_filter opcode:moogladder2
 a_voice_filter_aout_4 moogladder2 a_fm_foscili_asig_1, i_ctl_tone_iout_10, 0.18
 ; node:dc_filter opcode:butterhp
 a_dc_filter_aout_5 butterhp a_voice_filter_aout_4, 22, 0
 ; node:output_pan2 opcode:pan2
 a_output_pan2_aleft_2, a_output_pan2_aright_3 pan2 a_dc_filter_aout_5, 0.5, 0
 ; node:echo_left_1 opcode:delay
 a_echo_left_1_aout_6 delay a_output_pan2_aleft_2, 0.27, 0
 ; node:echo_left_2 opcode:delay
 a_echo_left_2_aout_8 delay a_output_pan2_aleft_2, 0.54, 0
 ; node:echo_left_3 opcode:delay
 a_echo_left_3_aout_10 delay a_output_pan2_aleft_2, 0.81, 0
 ; node:echo_right_1 opcode:delay
 a_echo_right_1_aout_18 delay a_output_pan2_aright_3, 0.36, 0
 ; node:echo_right_2 opcode:delay
 a_echo_right_2_aout_20 delay a_output_pan2_aright_3, 0.72, 0
 ; node:echo_right_3 opcode:delay
 a_echo_right_3_aout_22 delay a_output_pan2_aright_3, 1.08, 0
 ; node:echo_tone_left_1 opcode:butterlp
 a_echo_tone_left_1_aout_7 butterlp a_echo_left_1_aout_6, 2900, 0
 ; node:echo_tone_left_2 opcode:butterlp
 a_echo_tone_left_2_aout_9 butterlp a_echo_left_2_aout_8, 2400, 0
 ; node:echo_tone_left_3 opcode:butterlp
 a_echo_tone_left_3_aout_11 butterlp a_echo_left_3_aout_10, 1900, 0
 ; node:echo_tone_right_1 opcode:butterlp
 a_echo_tone_right_1_aout_19 butterlp a_echo_right_1_aout_18, 2900, 0
 ; node:echo_tone_right_2 opcode:butterlp
 a_echo_tone_right_2_aout_21 butterlp a_echo_right_2_aout_20, 2400, 0
 ; node:echo_tone_right_3 opcode:butterlp
 a_echo_tone_right_3_aout_23 butterlp a_echo_right_3_aout_22, 1900, 0
 ; node:echo_mix_left opcode:mix2
 a_echo_mix_left_aout_13 = ((a_output_pan2_aleft_2 + (a_audio_ctl_space_iout_aout_12 * ((((.5 * a_echo_tone_left_1_aout_7) + (.25 * a_echo_tone_left_2_aout_9)) + (.125 * a_echo_tone_left_3_aout_11)))))) + (0)
 ; node:echo_mix_right opcode:mix2
 a_echo_mix_right_aout_24 = ((a_output_pan2_aright_3 + (a_audio_ctl_space_iout_aout_12 * ((((.5 * a_echo_tone_right_1_aout_19) + (.25 * a_echo_tone_right_2_aout_21)) + (.125 * a_echo_tone_right_3_aout_23)))))) + (0)
 ; node:room_predelay_left opcode:delay
 a_room_predelay_left_aout_14 delay a_echo_mix_left_aout_13, 0.017, 0
 ; node:room_predelay_right opcode:delay
 a_room_predelay_right_aout_25 delay a_echo_mix_right_aout_24, 0.029, 0
 ; node:room_left opcode:reverb2
 a_room_left_aout_15 reverb2 a_room_predelay_left_aout_14, 2.2, 0.45, 0
 ; node:room_right opcode:reverb2
 a_room_right_aout_26 reverb2 a_room_predelay_right_aout_25, 2.0460000000000003, 0.45, 0
 ; node:room_mix_left opcode:mix2
 a_room_mix_left_aout_16 = ((a_echo_mix_left_aout_13 + (a_audio_ctl_space_iout_aout_12 * a_room_left_aout_15))) + (0)
 ; node:room_mix_right opcode:mix2
 a_room_mix_right_aout_27 = ((a_echo_mix_right_aout_24 + (a_audio_ctl_space_iout_aout_12 * a_room_right_aout_26))) + (0)
 ; node:final_level_left opcode:mix2
 a_final_level_left_aout_17 = ((a_room_mix_left_aout_16 * 0.65)) + (0)
 ; node:final_level_right opcode:mix2
 a_final_level_right_aout_28 = ((a_room_mix_right_aout_27 * 0.65)) + (0)
 ; node:output_left opcode:outleta
 outleta "left", a_final_level_left_aout_17
 ; node:output_right opcode:outleta
 outleta "right", a_final_level_right_aout_28
endin

; mixer stage patch:strikes
; patch:8602f55b-cd7f-4f32-bd8e-c01f998288ec name:EBM DW — Industrial Stab channel:2 always_on:false
; instance:strikes csound:vcs_mix_40643c4521cf1547a72d6c19
; description: Pitched metallic FM strike with a separate short noise transient, distortion and compact room ambience. Suggested MIDI 36–84. Velocity-sensitive; settings apply to new notes. Motion rates are Hz; echoes are fixed time. Route Stereo Output through the mixer to Master.
; trigger: MIDI channel 2 / score notes; score instrument number: 5
instr vcs_mix_40643c4521cf1547a72d6c19
 i_vcs_internal_score_note_p4 = p4
 i_vcs_internal_score_velocity_p5 = p5
 ; node:air_gain opcode:const_k
 k_air_gain_kout_5 = 0.14
 i_ctl_attack_iout_5 chnget "__vcs_perf_a175d18a9bfcdf60ae5c73352c3c40605b50ce1572548d8c5583537d7da998bf"
 i_ctl_clang_iout_7 chnget "__vcs_perf_537c2b19d48f44e1e424e723788277a9281b9d43b761511324aca7e27c725a8f"
 i_ctl_decay_iout_9 chnget "__vcs_perf_41701256ec3711e8d169d6e04dc8984eebafdf6fec36817d76642ead9de79f94"
 i_ctl_drive_iout_10 chnget "__vcs_perf_72ff4df4af243629f02ebf152735801f63433bb25c6eb1115e4f7c731c835bac"
 i_ctl_noise_iout_8 chnget "__vcs_perf_af6123d7fa41370276ec9390d19919a421a3408261eddb7c22e2abdc0f7fac87"
 i_ctl_release_iout_6 chnget "__vcs_perf_300ce86c7a2a5bf21b93f4f78df99ae98603f3ab81a9e81f8b444dcae1cb7a8f"
 i_ctl_space_iout_11 chnget "__vcs_perf_78be482781265d240aa9c90b6cd369403569b19994d084ea9a9d84042e0029b3"
 ; node:env_sustain_const opcode:const_i
 i_env_sustain_const_iout_4 = 0.0
 ; node:fm_gain opcode:const_k
 k_fm_gain_kout_3 = 0.17
 ; node:noise_transient opcode:linseg
 k_noise_transient_kenv_8 linseg 1, 0.055, 0
 ; node:pitch_cpsmidi opcode:cpsmidi
 i_pitch_cpsmidi_kfreq_1 = cpsmidinn(p4)
 ; node:velocity_scale_const opcode:const_i
 i_velocity_scale_const_iout_2 = 1.0
 ; node:fm_decay_envelope opcode:linseg
 k_fm_decay_envelope_kenv_7 linseg 1, i_ctl_decay_iout_9, 0
 ; node:effect_tail opcode:xtratim
 xtratim (i_ctl_release_iout_6 + 2.6)
 ; node:audio_ctl_space_iout opcode:k_to_a
 a_audio_ctl_space_iout_aout_11 interp i_ctl_space_iout_11
 ; node:amp_madsr opcode:madsr
 k_amp_madsr_kenv_1 madsr i_ctl_attack_iout_5, i_ctl_decay_iout_9, i_env_sustain_const_iout_4, i_ctl_release_iout_6, 0, -1
 ; node:velocity_ampmidi opcode:ampmidi
 i_velocity_ampmidi_iamp_3 = ((p5 / 128) * (i_velocity_scale_const_iout_2))
 ; node:amp_velocity_envelope opcode:k_mul
 k_amp_velocity_envelope_kout_2 = (i_velocity_ampmidi_iamp_3) * (k_amp_madsr_kenv_1)
 ; node:fm_amp opcode:k_mul
 k_fm_amp_kout_4 = (k_amp_velocity_envelope_kout_2) * (k_fm_gain_kout_3)
 ; node:air_amp opcode:k_mul
 k_air_amp_kout_6 = (((k_amp_velocity_envelope_kout_2 * i_ctl_noise_iout_8) * k_noise_transient_kenv_8)) * (k_air_gain_kout_5)
 ; node:fm_foscili opcode:foscili
 a_fm_foscili_asig_1 foscili k_fm_amp_kout_4, i_pitch_cpsmidi_kfreq_1, 1, 3.17, (i_ctl_clang_iout_7 * ((.04 + (.96 * k_fm_decay_envelope_kenv_7)))), 1, 0
 ; node:air_noise opcode:noise
 a_air_noise_aout_2 noise k_air_amp_kout_6, 0
 ; node:source_sum opcode:mix2
 a_source_sum_aout_5 = ((a_fm_foscili_asig_1 + a_air_noise_aout_2)) + (0)
 ; node:voice_filter opcode:moogladder2
 a_voice_filter_aout_6 moogladder2 a_source_sum_aout_5, 6500, 0.18
 ; node:saturation opcode:distort1
 a_saturation_aout_7 distort1 a_voice_filter_aout_6, (i_ctl_drive_iout_10 * 3), (1 / ((1 + (.55 * ((i_ctl_drive_iout_10 - 1)))))), 0, 0, 1
 ; node:dc_filter opcode:butterhp
 a_dc_filter_aout_8 butterhp a_saturation_aout_7, 22, 0
 ; node:output_pan2 opcode:pan2
 a_output_pan2_aleft_3, a_output_pan2_aright_4 pan2 a_dc_filter_aout_8, 0.5, 0
 ; node:room_predelay_left opcode:delay
 a_room_predelay_left_aout_9 delay a_output_pan2_aleft_3, 0.017, 0
 ; node:room_predelay_right opcode:delay
 a_room_predelay_right_aout_14 delay a_output_pan2_aright_4, 0.029, 0
 ; node:room_left opcode:reverb2
 a_room_left_aout_10 reverb2 a_room_predelay_left_aout_9, 0.65, 0.45, 0
 ; node:room_right opcode:reverb2
 a_room_right_aout_15 reverb2 a_room_predelay_right_aout_14, 0.6045, 0.45, 0
 ; node:room_mix_left opcode:mix2
 a_room_mix_left_aout_12 = ((a_output_pan2_aleft_3 + (a_audio_ctl_space_iout_aout_11 * a_room_left_aout_10))) + (0)
 ; node:room_mix_right opcode:mix2
 a_room_mix_right_aout_16 = ((a_output_pan2_aright_4 + (a_audio_ctl_space_iout_aout_11 * a_room_right_aout_15))) + (0)
 ; node:final_level_left opcode:mix2
 a_final_level_left_aout_13 = ((a_room_mix_left_aout_12 * 0.65)) + (0)
 ; node:final_level_right opcode:mix2
 a_final_level_right_aout_17 = ((a_room_mix_right_aout_16 * 0.65)) + (0)
 ; node:output_left opcode:outleta
 outleta "left", a_final_level_left_aout_13
 ; node:output_right opcode:outleta
 outleta "right", a_final_level_right_aout_17
endin

; mixer stage patch:sunlight
; patch:41eb999e-9cc4-4380-8086-3da9fdbcebd4 name:EBM DW — String Ensemble channel:5 always_on:false
; instance:sunlight csound:vcs_mix_b91f7fd7965b2dad388bba2b
; description: Melancholic three-layer string ensemble with independent stereo chorus movement and dark reverb. Suggested MIDI 43–84. Velocity-sensitive; settings apply to new notes. Motion rates are Hz; echoes are fixed time. Route Stereo Output through the mixer to Master.
; trigger: MIDI channel 5 / score notes; score instrument number: 6
instr vcs_mix_b91f7fd7965b2dad388bba2b
 i_vcs_internal_score_note_p4 = p4
 i_vcs_internal_score_velocity_p5 = p5
 ; node:chorus_left_lfo opcode:lfo
 k_chorus_left_lfo_kout_9 lfo 1, 0.23, 0
 ; node:chorus_right_lfo opcode:lfo
 k_chorus_right_lfo_kout_10 lfo 1, 0.31, 0
 i_ctl_attack_iout_6 chnget "__vcs_perf_622518ee3862adc8b3f17f9f476cb2f2ffea4a9a674789344b4157b98214220f"
 i_ctl_chorus_iout_10 chnget "__vcs_perf_51f0147aa9651daa68390eeaf615c4143ee60381a2140a2072b442729ae89563"
 i_ctl_detune_iout_9 chnget "__vcs_perf_2d271b61eb8a76a4b00bfc63dca62a85d5e34c2f874d9217297884a5b9933dd4"
 i_ctl_release_iout_7 chnget "__vcs_perf_14dbd30ed863c0239c6d1025f30671a2a5cabbd34ffe8b3938f26fe92b47035c"
 i_ctl_reverb_iout_11 chnget "__vcs_perf_82b6576be193ba69f5e97deb72fe5b2c1c990f4a4058aec23336e3f002cc2dc7"
 i_ctl_tone_iout_8 chnget "__vcs_perf_6095aa39c8df8873ec5f19f8b9ceb8601aeb7c970a46922ba5394f7ce22edf83"
 ; node:env_decay_const opcode:const_i
 i_env_decay_const_iout_4 = 1.2
 ; node:env_sustain_const opcode:const_i
 i_env_sustain_const_iout_5 = 0.8
 ; node:pitch_cpsmidi opcode:cpsmidi
 i_pitch_cpsmidi_kfreq_1 = cpsmidinn(p4)
 ; node:pulse_gain opcode:const_k
 k_pulse_gain_kout_7 = 0.065
 ; node:saw_a_gain opcode:const_k
 k_saw_a_gain_kout_3 = 0.09
 ; node:saw_b_gain opcode:const_k
 k_saw_b_gain_kout_5 = 0.09
 ; node:velocity_scale_const opcode:const_i
 i_velocity_scale_const_iout_2 = 1.0
 ; node:audio_ctl_chorus_iout opcode:k_to_a
 a_audio_ctl_chorus_iout_aout_10 interp i_ctl_chorus_iout_10
 ; node:effect_tail opcode:xtratim
 xtratim (i_ctl_release_iout_7 + 9.2)
 ; node:audio_ctl_reverb_iout opcode:k_to_a
 a_audio_ctl_reverb_iout_aout_14 interp i_ctl_reverb_iout_11
 ; node:amp_madsr opcode:madsr
 k_amp_madsr_kenv_1 madsr i_ctl_attack_iout_6, i_env_decay_const_iout_4, i_env_sustain_const_iout_5, i_ctl_release_iout_7, 0, -1
 ; node:velocity_ampmidi opcode:ampmidi
 i_velocity_ampmidi_iamp_3 = ((p5 / 128) * (i_velocity_scale_const_iout_2))
 ; node:amp_velocity_envelope opcode:k_mul
 k_amp_velocity_envelope_kout_2 = (i_velocity_ampmidi_iamp_3) * (k_amp_madsr_kenv_1)
 ; node:saw_a_amp opcode:k_mul
 k_saw_a_amp_kout_4 = (k_amp_velocity_envelope_kout_2) * (k_saw_a_gain_kout_3)
 ; node:saw_b_amp opcode:k_mul
 k_saw_b_amp_kout_6 = (k_amp_velocity_envelope_kout_2) * (k_saw_b_gain_kout_5)
 ; node:pulse_amp opcode:k_mul
 k_pulse_amp_kout_8 = (k_amp_velocity_envelope_kout_2) * (k_pulse_gain_kout_7)
 ; node:saw_a_vco2 opcode:vco2
 a_saw_a_vco2_asig_1 vco2 k_saw_a_amp_kout_4, (i_pitch_cpsmidi_kfreq_1 * ((1 + (((-1) * i_ctl_detune_iout_9) * 0.0005777895)))), 0, 0.5, 0, 0.5
 ; node:saw_b_vco2 opcode:vco2
 a_saw_b_vco2_asig_2 vco2 k_saw_b_amp_kout_6, (i_pitch_cpsmidi_kfreq_1 * ((1 + ((1 * i_ctl_detune_iout_9) * 0.0005777895)))), 0, 0.5, 0, 0.5
 ; node:pulse_vco2 opcode:vco2
 a_pulse_vco2_asig_3 vco2 k_pulse_amp_kout_8, i_pitch_cpsmidi_kfreq_1, 2, 0.5, 0, 0.5
 ; node:source_sum opcode:mix2
 a_source_sum_aout_6 = (((a_saw_a_vco2_asig_1 + a_saw_b_vco2_asig_2) + a_pulse_vco2_asig_3)) + (0)
 ; node:voice_filter opcode:moogladder2
 a_voice_filter_aout_7 moogladder2 a_source_sum_aout_6, i_ctl_tone_iout_8, 0.18
 ; node:dc_filter opcode:butterhp
 a_dc_filter_aout_8 butterhp a_voice_filter_aout_7, 22, 0
 ; node:output_pan2 opcode:pan2
 a_output_pan2_aleft_4, a_output_pan2_aright_5 pan2 a_dc_filter_aout_8, 0.5, 0
 ; node:chorus_left opcode:vdelay3
 a_chorus_left_aout_9 vdelay3 a_output_pan2_aleft_4, (14 + (3 * k_chorus_left_lfo_kout_9)), 35
 ; node:chorus_right opcode:vdelay3
 a_chorus_right_aout_17 vdelay3 a_output_pan2_aright_5, (19 + (3 * k_chorus_right_lfo_kout_10)), 35
 ; node:chorus_mix_left opcode:mix2
 a_chorus_mix_left_aout_11 = (((a_output_pan2_aleft_4 * ((1 - (.25 * a_audio_ctl_chorus_iout_aout_10)))) + ((a_chorus_left_aout_9 * .5) * a_audio_ctl_chorus_iout_aout_10))) + (0)
 ; node:chorus_mix_right opcode:mix2
 a_chorus_mix_right_aout_18 = (((a_output_pan2_aright_5 * ((1 - (.25 * a_audio_ctl_chorus_iout_aout_10)))) + ((a_chorus_right_aout_17 * .5) * a_audio_ctl_chorus_iout_aout_10))) + (0)
 ; node:room_predelay_left opcode:delay
 a_room_predelay_left_aout_12 delay a_chorus_mix_left_aout_11, 0.017, 0
 ; node:room_predelay_right opcode:delay
 a_room_predelay_right_aout_19 delay a_chorus_mix_right_aout_18, 0.029, 0
 ; node:room_left opcode:reverb2
 a_room_left_aout_13 reverb2 a_room_predelay_left_aout_12, 2.3, 0.45, 0
 ; node:room_right opcode:reverb2
 a_room_right_aout_20 reverb2 a_room_predelay_right_aout_19, 2.139, 0.45, 0
 ; node:room_mix_left opcode:mix2
 a_room_mix_left_aout_15 = ((a_chorus_mix_left_aout_11 + (a_audio_ctl_reverb_iout_aout_14 * a_room_left_aout_13))) + (0)
 ; node:room_mix_right opcode:mix2
 a_room_mix_right_aout_21 = ((a_chorus_mix_right_aout_18 + (a_audio_ctl_reverb_iout_aout_14 * a_room_right_aout_20))) + (0)
 ; node:final_level_left opcode:mix2
 a_final_level_left_aout_16 = ((a_room_mix_left_aout_15 * 0.45)) + (0)
 ; node:final_level_right opcode:mix2
 a_final_level_right_aout_22 = ((a_room_mix_right_aout_21 * 0.45)) + (0)
 ; node:output_left opcode:outleta
 outleta "left", a_final_level_left_aout_16
 ; node:output_right opcode:outleta
 outleta "right", a_final_level_right_aout_22
endin

; mixer stage patch:sunrays
; patch:612db40c-e83f-4d26-a447-b2efd391ff0d name:EBM DW — Analog Brass channel:6 always_on:false
; instance:sunrays csound:vcs_mix_91d317b8f793206966758b36
; description: Dramatic saw brass with a separate opening filter envelope and a quiet room tail. Suggested MIDI 43–79. Velocity-sensitive; settings apply to new notes. Motion rates are Hz; echoes are fixed time. Route Stereo Output through the mixer to Master.
; trigger: MIDI channel 6 / score notes; score instrument number: 7
instr vcs_mix_91d317b8f793206966758b36
 i_vcs_internal_score_note_p4 = p4
 i_vcs_internal_score_velocity_p5 = p5
 i_ctl_attack_iout_6 chnget "__vcs_perf_86cc378af9041d5294c29fb180a2a447071c085191121fb86d925c5c920f83d4"
 i_ctl_detune_iout_11 chnget "__vcs_perf_7bfe3a3bce6abc89f529fe690548d1de6d37a6906f707c07a5732e196818788f"
 i_ctl_filter_decay_iout_10 chnget "__vcs_perf_82ba3acdefcc6460f500231c4626a68f7f1d91c9601a5cfddd7f510d6801f9bf"
 i_ctl_filter_envelope_iout_9 chnget "__vcs_perf_99772fabed33c9193cc02a44d6d6f674521a18473e8e5a8cc3f5250477373958"
 i_ctl_release_iout_7 chnget "__vcs_perf_4fecc0c9b25b5fa647de6c824a65b6a7adb98a15406d418b5dd1c4ddcb954d76"
 i_ctl_space_iout_12 chnget "__vcs_perf_64c2b17f354e4038455ce71c6c7c49230ef5af9c620e4541d59a4cc898d10b48"
 i_ctl_tone_iout_8 chnget "__vcs_perf_d959aaca533b2b7656b57cacc21119939ad9308c4925af04cec1940da7079c69"
 ; node:env_decay_const opcode:const_i
 i_env_decay_const_iout_4 = 0.3
 ; node:env_sustain_const opcode:const_i
 i_env_sustain_const_iout_5 = 0.6
 ; node:pitch_cpsmidi opcode:cpsmidi
 i_pitch_cpsmidi_kfreq_1 = cpsmidinn(p4)
 ; node:saw_a_gain opcode:const_k
 k_saw_a_gain_kout_3 = 0.12
 ; node:saw_b_gain opcode:const_k
 k_saw_b_gain_kout_5 = 0.12
 ; node:velocity_scale_const opcode:const_i
 i_velocity_scale_const_iout_2 = 1.0
 ; node:filter_decay_envelope opcode:linseg
 k_filter_decay_envelope_kenv_7 linseg 0, .015, 1, i_ctl_filter_decay_iout_10, 0.12
 ; node:effect_tail opcode:xtratim
 xtratim (i_ctl_release_iout_7 + 3.2)
 ; node:audio_ctl_space_iout opcode:k_to_a
 a_audio_ctl_space_iout_aout_10 interp i_ctl_space_iout_12
 ; node:amp_madsr opcode:madsr
 k_amp_madsr_kenv_1 madsr i_ctl_attack_iout_6, i_env_decay_const_iout_4, i_env_sustain_const_iout_5, i_ctl_release_iout_7, 0, -1
 ; node:velocity_ampmidi opcode:ampmidi
 i_velocity_ampmidi_iamp_3 = ((p5 / 128) * (i_velocity_scale_const_iout_2))
 ; node:amp_velocity_envelope opcode:k_mul
 k_amp_velocity_envelope_kout_2 = (i_velocity_ampmidi_iamp_3) * (k_amp_madsr_kenv_1)
 ; node:saw_a_amp opcode:k_mul
 k_saw_a_amp_kout_4 = (k_amp_velocity_envelope_kout_2) * (k_saw_a_gain_kout_3)
 ; node:saw_b_amp opcode:k_mul
 k_saw_b_amp_kout_6 = (k_amp_velocity_envelope_kout_2) * (k_saw_b_gain_kout_5)
 ; node:saw_a_vco2 opcode:vco2
 a_saw_a_vco2_asig_1 vco2 k_saw_a_amp_kout_4, (i_pitch_cpsmidi_kfreq_1 * ((1 + (((-1) * i_ctl_detune_iout_11) * 0.0005777895)))), 0, 0.5, 0, 0.5
 ; node:saw_b_vco2 opcode:vco2
 a_saw_b_vco2_asig_2 vco2 k_saw_b_amp_kout_6, (i_pitch_cpsmidi_kfreq_1 * ((1 + ((1 * i_ctl_detune_iout_11) * 0.0005777895)))), 0, 0.5, 0, 0.5
 ; node:source_sum opcode:mix2
 a_source_sum_aout_5 = ((a_saw_a_vco2_asig_1 + a_saw_b_vco2_asig_2)) + (0)
 ; node:voice_filter opcode:moogladder2
 a_voice_filter_aout_6 moogladder2 a_source_sum_aout_5, (i_ctl_tone_iout_8 + (i_ctl_filter_envelope_iout_9 * k_filter_decay_envelope_kenv_7)), 0.18
 ; node:dc_filter opcode:butterhp
 a_dc_filter_aout_7 butterhp a_voice_filter_aout_6, 22, 0
 ; node:output_pan2 opcode:pan2
 a_output_pan2_aleft_3, a_output_pan2_aright_4 pan2 a_dc_filter_aout_7, 0.5, 0
 ; node:room_predelay_left opcode:delay
 a_room_predelay_left_aout_8 delay a_output_pan2_aleft_3, 0.017, 0
 ; node:room_predelay_right opcode:delay
 a_room_predelay_right_aout_13 delay a_output_pan2_aright_4, 0.029, 0
 ; node:room_left opcode:reverb2
 a_room_left_aout_9 reverb2 a_room_predelay_left_aout_8, 0.8, 0.45, 0
 ; node:room_right opcode:reverb2
 a_room_right_aout_14 reverb2 a_room_predelay_right_aout_13, 0.7440000000000001, 0.45, 0
 ; node:room_mix_left opcode:mix2
 a_room_mix_left_aout_11 = ((a_output_pan2_aleft_3 + (a_audio_ctl_space_iout_aout_10 * a_room_left_aout_9))) + (0)
 ; node:room_mix_right opcode:mix2
 a_room_mix_right_aout_15 = ((a_output_pan2_aright_4 + (a_audio_ctl_space_iout_aout_10 * a_room_right_aout_14))) + (0)
 ; node:final_level_left opcode:mix2
 a_final_level_left_aout_12 = ((a_room_mix_left_aout_11 * 0.65)) + (0)
 ; node:final_level_right opcode:mix2
 a_final_level_right_aout_16 = ((a_room_mix_right_aout_15 * 0.65)) + (0)
 ; node:output_left opcode:outleta
 outleta "left", a_final_level_left_aout_12
 ; node:output_right opcode:outleta
 outleta "right", a_final_level_right_aout_16
endin

; mixer stage patch:theme
; patch:fd59788a-4a07-4515-8ef6-977fe69ec569 name:EBM DW — Dark Saw Lead channel:4 always_on:false
; instance:theme csound:vcs_mix_b9e4b05138bfb5ddfecff5e1
; description: Cold expressive saw lead with modest detune, subtle vibrato, animated stereo chorus and quiet filtered echoes. Suggested MIDI 48–84. Velocity-sensitive; settings apply to new notes. Motion rates are Hz; echoes are fixed time. Route Stereo Output through the mixer to Master.
; trigger: MIDI channel 4 / score notes; score instrument number: 8
instr vcs_mix_b9e4b05138bfb5ddfecff5e1
 i_vcs_internal_score_note_p4 = p4
 i_vcs_internal_score_velocity_p5 = p5
 ; node:chorus_left_lfo opcode:lfo
 k_chorus_left_lfo_kout_9 lfo 1, 0.23, 0
 ; node:chorus_right_lfo opcode:lfo
 k_chorus_right_lfo_kout_10 lfo 1, 0.31, 0
 i_ctl_attack_iout_6 chnget "__vcs_perf_2693177ded5b3704bc870384173a72470fa3a13e6144717854f4ac738b76f410"
 i_ctl_chorus_iout_11 chnget "__vcs_perf_fa8a70d97431f3f6f5fce3a5432ef703e1b598ea68a3d5e09b6c1ecedf441a6e"
 i_ctl_detune_iout_9 chnget "__vcs_perf_789e61ba750aee5900aaa96e284eb96bdc9cb40bb441ce6d2fdb57b52575c586"
 i_ctl_echo_iout_12 chnget "__vcs_perf_0294b3b47f66a9344cca1a5a51883b7e317cc1b65ecb77149d574ea73b0b5164"
 i_ctl_release_iout_7 chnget "__vcs_perf_efd680873290a7110225cf770c00597f7560977a50b17fa760838a8cf73e0277"
 i_ctl_tone_iout_8 chnget "__vcs_perf_b18357a98b0c231b8a2e7613ff04e4358d691722ebe869470e9a694fda744a9e"
 i_ctl_vibrato_iout_10 chnget "__vcs_perf_3dfb949bdf5981a798b597953f83889a8d82fded009fbb9ac6bc96de1f879192"
 ; node:env_decay_const opcode:const_i
 i_env_decay_const_iout_4 = 0.25
 ; node:env_sustain_const opcode:const_i
 i_env_sustain_const_iout_5 = 0.65
 ; node:pitch_cpsmidi opcode:cpsmidi
 i_pitch_cpsmidi_kfreq_1 = cpsmidinn(p4)
 ; node:saw_a_gain opcode:const_k
 k_saw_a_gain_kout_3 = 0.12
 ; node:saw_b_gain opcode:const_k
 k_saw_b_gain_kout_5 = 0.12
 ; node:velocity_scale_const opcode:const_i
 i_velocity_scale_const_iout_2 = 1.0
 ; node:vibrato_lfo opcode:lfo
 k_vibrato_lfo_kout_7 lfo 1, 5.2, 0
 ; node:audio_ctl_chorus_iout opcode:k_to_a
 a_audio_ctl_chorus_iout_aout_9 interp i_ctl_chorus_iout_11
 ; node:audio_ctl_echo_iout opcode:k_to_a
 a_audio_ctl_echo_iout_aout_17 interp i_ctl_echo_iout_12
 ; node:effect_tail opcode:xtratim
 xtratim (i_ctl_release_iout_7 + 2)
 ; node:amp_madsr opcode:madsr
 k_amp_madsr_kenv_1 madsr i_ctl_attack_iout_6, i_env_decay_const_iout_4, i_env_sustain_const_iout_5, i_ctl_release_iout_7, 0, -1
 ; node:velocity_ampmidi opcode:ampmidi
 i_velocity_ampmidi_iamp_3 = ((p5 / 128) * (i_velocity_scale_const_iout_2))
 ; node:vibrato_depth opcode:k_mul
 k_vibrato_depth_kout_8 = ((k_vibrato_lfo_kout_7 * i_ctl_vibrato_iout_10)) * (1)
 ; node:amp_velocity_envelope opcode:k_mul
 k_amp_velocity_envelope_kout_2 = (i_velocity_ampmidi_iamp_3) * (k_amp_madsr_kenv_1)
 ; node:saw_a_amp opcode:k_mul
 k_saw_a_amp_kout_4 = (k_amp_velocity_envelope_kout_2) * (k_saw_a_gain_kout_3)
 ; node:saw_b_amp opcode:k_mul
 k_saw_b_amp_kout_6 = (k_amp_velocity_envelope_kout_2) * (k_saw_b_gain_kout_5)
 ; node:saw_a_vco2 opcode:vco2
 a_saw_a_vco2_asig_1 vco2 k_saw_a_amp_kout_4, ((i_pitch_cpsmidi_kfreq_1 * ((1 + (((-1) * i_ctl_detune_iout_9) * 0.0005777895)))) * ((1 + (k_vibrato_depth_kout_8 * 0.0005777895)))), 0, 0.5, 0, 0.5
 ; node:saw_b_vco2 opcode:vco2
 a_saw_b_vco2_asig_2 vco2 k_saw_b_amp_kout_6, ((i_pitch_cpsmidi_kfreq_1 * ((1 + ((1 * i_ctl_detune_iout_9) * 0.0005777895)))) * ((1 + (k_vibrato_depth_kout_8 * 0.0005777895)))), 0, 0.5, 0, 0.5
 ; node:source_sum opcode:mix2
 a_source_sum_aout_5 = ((a_saw_a_vco2_asig_1 + a_saw_b_vco2_asig_2)) + (0)
 ; node:voice_filter opcode:moogladder2
 a_voice_filter_aout_6 moogladder2 a_source_sum_aout_5, i_ctl_tone_iout_8, 0.18
 ; node:dc_filter opcode:butterhp
 a_dc_filter_aout_7 butterhp a_voice_filter_aout_6, 22, 0
 ; node:output_pan2 opcode:pan2
 a_output_pan2_aleft_3, a_output_pan2_aright_4 pan2 a_dc_filter_aout_7, 0.5, 0
 ; node:chorus_left opcode:vdelay3
 a_chorus_left_aout_8 vdelay3 a_output_pan2_aleft_3, (14 + (3 * k_chorus_left_lfo_kout_9)), 35
 ; node:chorus_right opcode:vdelay3
 a_chorus_right_aout_20 vdelay3 a_output_pan2_aright_4, (19 + (3 * k_chorus_right_lfo_kout_10)), 35
 ; node:chorus_mix_left opcode:mix2
 a_chorus_mix_left_aout_10 = (((a_output_pan2_aleft_3 * ((1 - (.25 * a_audio_ctl_chorus_iout_aout_9)))) + ((a_chorus_left_aout_8 * .5) * a_audio_ctl_chorus_iout_aout_9))) + (0)
 ; node:chorus_mix_right opcode:mix2
 a_chorus_mix_right_aout_21 = (((a_output_pan2_aright_4 * ((1 - (.25 * a_audio_ctl_chorus_iout_aout_9)))) + ((a_chorus_right_aout_20 * .5) * a_audio_ctl_chorus_iout_aout_9))) + (0)
 ; node:echo_left_1 opcode:delay
 a_echo_left_1_aout_11 delay a_chorus_mix_left_aout_10, 0.27, 0
 ; node:echo_left_2 opcode:delay
 a_echo_left_2_aout_13 delay a_chorus_mix_left_aout_10, 0.54, 0
 ; node:echo_left_3 opcode:delay
 a_echo_left_3_aout_15 delay a_chorus_mix_left_aout_10, 0.81, 0
 ; node:echo_right_1 opcode:delay
 a_echo_right_1_aout_22 delay a_chorus_mix_right_aout_21, 0.36, 0
 ; node:echo_right_2 opcode:delay
 a_echo_right_2_aout_24 delay a_chorus_mix_right_aout_21, 0.72, 0
 ; node:echo_right_3 opcode:delay
 a_echo_right_3_aout_26 delay a_chorus_mix_right_aout_21, 1.08, 0
 ; node:echo_tone_left_1 opcode:butterlp
 a_echo_tone_left_1_aout_12 butterlp a_echo_left_1_aout_11, 2900, 0
 ; node:echo_tone_left_2 opcode:butterlp
 a_echo_tone_left_2_aout_14 butterlp a_echo_left_2_aout_13, 2400, 0
 ; node:echo_tone_left_3 opcode:butterlp
 a_echo_tone_left_3_aout_16 butterlp a_echo_left_3_aout_15, 1900, 0
 ; node:echo_tone_right_1 opcode:butterlp
 a_echo_tone_right_1_aout_23 butterlp a_echo_right_1_aout_22, 2900, 0
 ; node:echo_tone_right_2 opcode:butterlp
 a_echo_tone_right_2_aout_25 butterlp a_echo_right_2_aout_24, 2400, 0
 ; node:echo_tone_right_3 opcode:butterlp
 a_echo_tone_right_3_aout_27 butterlp a_echo_right_3_aout_26, 1900, 0
 ; node:echo_mix_left opcode:mix2
 a_echo_mix_left_aout_18 = ((a_chorus_mix_left_aout_10 + (a_audio_ctl_echo_iout_aout_17 * ((((.5 * a_echo_tone_left_1_aout_12) + (.25 * a_echo_tone_left_2_aout_14)) + (.125 * a_echo_tone_left_3_aout_16)))))) + (0)
 ; node:echo_mix_right opcode:mix2
 a_echo_mix_right_aout_28 = ((a_chorus_mix_right_aout_21 + (a_audio_ctl_echo_iout_aout_17 * ((((.5 * a_echo_tone_right_1_aout_23) + (.25 * a_echo_tone_right_2_aout_25)) + (.125 * a_echo_tone_right_3_aout_27)))))) + (0)
 ; node:final_level_left opcode:mix2
 a_final_level_left_aout_19 = ((a_echo_mix_left_aout_18 * 0.75)) + (0)
 ; node:final_level_right opcode:mix2
 a_final_level_right_aout_29 = ((a_echo_mix_right_aout_28 * 0.75)) + (0)
 ; node:output_left opcode:outleta
 outleta "left", a_final_level_left_aout_19
 ; node:output_right opcode:outleta
 outleta "right", a_final_level_right_aout_29
endin

; mixer stage patch:weather
; patch:e77f6354-8a77-4473-850c-91758ee210d0 name:EBM DW — Noise Metal FX channel:8 always_on:false
; instance:weather csound:vcs_mix_1dc1baf55c97903a3ec0b1d9
; description: Sustained mechanical noise/FM texture with slow spectral sweeps and dark ambience. Note pitch controls the metal layer. Suggested MIDI 36–79. Velocity-sensitive; settings apply to new notes. Motion rates are Hz; echoes are fixed time. Route Stereo Output through the mixer to Master.
; trigger: MIDI channel 8 / score notes; score instrument number: 9
instr vcs_mix_1dc1baf55c97903a3ec0b1d9
 i_vcs_internal_score_note_p4 = p4
 i_vcs_internal_score_velocity_p5 = p5
 ; node:air_gain opcode:const_k
 k_air_gain_kout_5 = 0.18
 i_ctl_attack_iout_6 chnget "__vcs_perf_cb7fe217f51092eabaf2b7e443277b31ad0bebfeac4f31e14ec648ac482e838c"
 i_ctl_color_iout_9 chnget "__vcs_perf_fef2b0c230c35dfb2d5c49ddf3168e31bce090e1dd122fe32e3705f8d0d670bc"
 i_ctl_metal_blend_iout_8 chnget "__vcs_perf_760f28410509b22de02893ffd96a9dc3b5fd6652ddc31ce462a827853871ec61"
 i_ctl_motion_rate_iout_11 chnget "__vcs_perf_580886d291fd5f84198c055bfe90349487f8b28ebe0eaacbc5f2c5d62078aed8"
 i_ctl_release_iout_7 chnget "__vcs_perf_a9715bcb9e537a012079e8c1fae8e7c69106df97e14681c5583532445934cfea"
 i_ctl_space_iout_12 chnget "__vcs_perf_5a94f773f39f1a4865b25302f4f87693ed0ba505352f39638a974aecad3d977c"
 i_ctl_sweep_depth_iout_10 chnget "__vcs_perf_d0026d433be3faabd992ea1dbca7ead5727b4816009a9f1ee44c1aecf507da2f"
 ; node:env_decay_const opcode:const_i
 i_env_decay_const_iout_4 = 1.0
 ; node:env_sustain_const opcode:const_i
 i_env_sustain_const_iout_5 = 0.7
 ; node:fm_gain opcode:const_k
 k_fm_gain_kout_3 = 0.16
 ; node:pitch_cpsmidi opcode:cpsmidi
 i_pitch_cpsmidi_kfreq_1 = cpsmidinn(p4)
 ; node:velocity_scale_const opcode:const_i
 i_velocity_scale_const_iout_2 = 1.0
 ; node:motion_lfo opcode:lfo
 k_motion_lfo_kout_7 lfo 1, i_ctl_motion_rate_iout_11, 0
 ; node:effect_tail opcode:xtratim
 xtratim (i_ctl_release_iout_7 + 10.8)
 ; node:audio_ctl_space_iout opcode:k_to_a
 a_audio_ctl_space_iout_aout_14 interp i_ctl_space_iout_12
 ; node:amp_madsr opcode:madsr
 k_amp_madsr_kenv_1 madsr i_ctl_attack_iout_6, i_env_decay_const_iout_4, i_env_sustain_const_iout_5, i_ctl_release_iout_7, 0, -1
 ; node:velocity_ampmidi opcode:ampmidi
 i_velocity_ampmidi_iamp_3 = ((p5 / 128) * (i_velocity_scale_const_iout_2))
 ; node:amp_velocity_envelope opcode:k_mul
 k_amp_velocity_envelope_kout_2 = (i_velocity_ampmidi_iamp_3) * (k_amp_madsr_kenv_1)
 ; node:fm_amp opcode:k_mul
 k_fm_amp_kout_4 = ((k_amp_velocity_envelope_kout_2 * i_ctl_metal_blend_iout_8)) * (k_fm_gain_kout_3)
 ; node:air_amp opcode:k_mul
 k_air_amp_kout_6 = ((k_amp_velocity_envelope_kout_2 * ((1 - i_ctl_metal_blend_iout_8)))) * (k_air_gain_kout_5)
 ; node:fm_foscili opcode:foscili
 a_fm_foscili_asig_1 foscili k_fm_amp_kout_4, i_pitch_cpsmidi_kfreq_1, 1, 2.718, (2.5 + ((1.5 * i_ctl_sweep_depth_iout_10) * k_motion_lfo_kout_7)), 1, 0
 ; node:air_noise opcode:noise
 a_air_noise_aout_2 noise k_air_amp_kout_6, 0
 ; node:source_sum opcode:mix2
 a_source_sum_aout_5 = ((a_fm_foscili_asig_1 + a_air_noise_aout_2)) + (0)
 ; node:voice_filter opcode:moogladder2
 a_voice_filter_aout_6 moogladder2 a_source_sum_aout_5, (i_ctl_color_iout_9 * ((1 + ((.65 * i_ctl_sweep_depth_iout_10) * k_motion_lfo_kout_7)))), 0.18
 ; node:dc_filter opcode:butterhp
 a_dc_filter_aout_7 butterhp a_voice_filter_aout_6, 22, 0
 ; node:output_pan2 opcode:pan2
 a_output_pan2_aleft_3, a_output_pan2_aright_4 pan2 a_dc_filter_aout_7, 0.5, 0
 ; node:echo_left_1 opcode:delay
 a_echo_left_1_aout_8 delay a_output_pan2_aleft_3, 0.27, 0
 ; node:echo_left_2 opcode:delay
 a_echo_left_2_aout_10 delay a_output_pan2_aleft_3, 0.54, 0
 ; node:echo_left_3 opcode:delay
 a_echo_left_3_aout_12 delay a_output_pan2_aleft_3, 0.81, 0
 ; node:echo_right_1 opcode:delay
 a_echo_right_1_aout_20 delay a_output_pan2_aright_4, 0.36, 0
 ; node:echo_right_2 opcode:delay
 a_echo_right_2_aout_22 delay a_output_pan2_aright_4, 0.72, 0
 ; node:echo_right_3 opcode:delay
 a_echo_right_3_aout_24 delay a_output_pan2_aright_4, 1.08, 0
 ; node:echo_tone_left_1 opcode:butterlp
 a_echo_tone_left_1_aout_9 butterlp a_echo_left_1_aout_8, 2900, 0
 ; node:echo_tone_left_2 opcode:butterlp
 a_echo_tone_left_2_aout_11 butterlp a_echo_left_2_aout_10, 2400, 0
 ; node:echo_tone_left_3 opcode:butterlp
 a_echo_tone_left_3_aout_13 butterlp a_echo_left_3_aout_12, 1900, 0
 ; node:echo_tone_right_1 opcode:butterlp
 a_echo_tone_right_1_aout_21 butterlp a_echo_right_1_aout_20, 2900, 0
 ; node:echo_tone_right_2 opcode:butterlp
 a_echo_tone_right_2_aout_23 butterlp a_echo_right_2_aout_22, 2400, 0
 ; node:echo_tone_right_3 opcode:butterlp
 a_echo_tone_right_3_aout_25 butterlp a_echo_right_3_aout_24, 1900, 0
 ; node:echo_mix_left opcode:mix2
 a_echo_mix_left_aout_15 = ((a_output_pan2_aleft_3 + (a_audio_ctl_space_iout_aout_14 * ((((.5 * a_echo_tone_left_1_aout_9) + (.25 * a_echo_tone_left_2_aout_11)) + (.125 * a_echo_tone_left_3_aout_13)))))) + (0)
 ; node:echo_mix_right opcode:mix2
 a_echo_mix_right_aout_26 = ((a_output_pan2_aright_4 + (a_audio_ctl_space_iout_aout_14 * ((((.5 * a_echo_tone_right_1_aout_21) + (.25 * a_echo_tone_right_2_aout_23)) + (.125 * a_echo_tone_right_3_aout_25)))))) + (0)
 ; node:room_predelay_left opcode:delay
 a_room_predelay_left_aout_16 delay a_echo_mix_left_aout_15, 0.017, 0
 ; node:room_predelay_right opcode:delay
 a_room_predelay_right_aout_27 delay a_echo_mix_right_aout_26, 0.029, 0
 ; node:room_left opcode:reverb2
 a_room_left_aout_17 reverb2 a_room_predelay_left_aout_16, 2.7, 0.45, 0
 ; node:room_right opcode:reverb2
 a_room_right_aout_28 reverb2 a_room_predelay_right_aout_27, 2.511, 0.45, 0
 ; node:room_mix_left opcode:mix2
 a_room_mix_left_aout_18 = ((a_echo_mix_left_aout_15 + (a_audio_ctl_space_iout_aout_14 * a_room_left_aout_17))) + (0)
 ; node:room_mix_right opcode:mix2
 a_room_mix_right_aout_29 = ((a_echo_mix_right_aout_26 + (a_audio_ctl_space_iout_aout_14 * a_room_right_aout_28))) + (0)
 ; node:final_level_left opcode:mix2
 a_final_level_left_aout_19 = ((a_room_mix_left_aout_18 * 0.6)) + (0)
 ; node:final_level_right opcode:mix2
 a_final_level_right_aout_30 = ((a_room_mix_right_aout_29 * 0.6)) + (0)
 ; node:output_left opcode:outleta
 outleta "left", a_final_level_left_aout_19
 ; node:output_right opcode:outleta
 outleta "right", a_final_level_right_aout_30
endin

; mixer stage strip:bass
; mixer strip: EBM DW — Sequencer Bass [bass]
; initial gain: -8 dB; balance/pan: 0; mute: false; solo: false
; Voices and insert returns sum before the strip; pre taps precede balance/fader, post taps follow them.
instr vcs_mix_d69e2b115c3aedc5f5e51463
 k_meter metro 15
 k_gain chnget "__vcs_mixer_strip_441349e1ec2f7fd0aa17267b_gain"
 a_gain vcs_mixer_ramp k_gain, 0.3981071705534972
 k_left chnget "__vcs_mixer_strip_441349e1ec2f7fd0aa17267b_left"
 a_left vcs_mixer_ramp k_left, 1
 k_right chnget "__vcs_mixer_strip_441349e1ec2f7fd0aa17267b_right"
 a_right vcs_mixer_ramp k_right, 1
 k_mute chnget "__vcs_mixer_strip_441349e1ec2f7fd0aa17267b_mute"
 a_mute vcs_mixer_ramp k_mute, 1
 a_p_360f84035942243c6a36537a inleta "p_360f84035942243c6a36537a"
 a_p_360f84035942243c6a36537a_post = a_p_360f84035942243c6a36537a * a_gain * a_left
 a_p_27042f4e6eca7d0b2a7ee402 inleta "p_27042f4e6eca7d0b2a7ee402"
 a_p_27042f4e6eca7d0b2a7ee402_post = a_p_27042f4e6eca7d0b2a7ee402 * a_gain * a_right
 a_meter_left = a_p_360f84035942243c6a36537a_post * a_mute
 a_meter_right = a_p_27042f4e6eca7d0b2a7ee402_post * a_mute
 k_peakL max_k a_meter_left, k_meter, 1
 k_rmsL rms a_meter_left
 chnset k_peakL / 1.0, "__vcs_mixer_meter_441349e1ec2f7fd0aa17267b_peakL"
 chnset k_rmsL / 1.0, "__vcs_mixer_meter_441349e1ec2f7fd0aa17267b_rmsL"
 k_peakR max_k a_meter_right, k_meter, 1
 k_rmsR rms a_meter_right
 chnset k_peakR / 1.0, "__vcs_mixer_meter_441349e1ec2f7fd0aa17267b_peakR"
 chnset k_rmsR / 1.0, "__vcs_mixer_meter_441349e1ec2f7fd0aa17267b_rmsR"
 outleta "pre_p_360f84035942243c6a36537a", a_p_360f84035942243c6a36537a
 outleta "post_p_360f84035942243c6a36537a", a_p_360f84035942243c6a36537a_post
 outleta "pre_p_27042f4e6eca7d0b2a7ee402", a_p_27042f4e6eca7d0b2a7ee402
 outleta "post_p_27042f4e6eca7d0b2a7ee402", a_p_27042f4e6eca7d0b2a7ee402_post
endin

; mixer stage route:bass-to-master-left
; audio route:bass-to-master-left kind:main
; from: EBM DW — Sequencer Bass [bass] port:left stage:strip -> Master [$master] port:left stage:input
; tap: post-fader; initial route gain: 0 dB; source mute and mixer solo gate this route.
instr vcs_mix_bf77b782450578498a75e856
 k_post chnget "__vcs_mixer_route_3e8014902b44dfaf5918f0cb_post"
 a_post vcs_mixer_ramp k_post, 1
 k_pan chnget "__vcs_mixer_route_3e8014902b44dfaf5918f0cb_pan"
 a_pan vcs_mixer_ramp k_pan, 1
 a_pre inleta "pre"
 a_post_signal inleta "post"
 a_signal = a_pre * (1 - a_post) + a_post_signal * a_post * a_pan
 k_send chnget "__vcs_mixer_route_3e8014902b44dfaf5918f0cb_gain"
 a_send vcs_mixer_ramp k_send, 1
 a_route_output = a_signal * a_send
 outleta "out", a_route_output
endin

; mixer stage route:bass-to-master-right
; audio route:bass-to-master-right kind:main
; from: EBM DW — Sequencer Bass [bass] port:right stage:strip -> Master [$master] port:right stage:input
; tap: post-fader; initial route gain: 0 dB; source mute and mixer solo gate this route.
instr vcs_mix_7d28de53beb30deccc25fc17
 k_post chnget "__vcs_mixer_route_c99934ba5158b7053b82b3c7_post"
 a_post vcs_mixer_ramp k_post, 1
 k_pan chnget "__vcs_mixer_route_c99934ba5158b7053b82b3c7_pan"
 a_pan vcs_mixer_ramp k_pan, 1
 a_pre inleta "pre"
 a_post_signal inleta "post"
 a_signal = a_pre * (1 - a_post) + a_post_signal * a_post * a_pan
 k_send chnget "__vcs_mixer_route_c99934ba5158b7053b82b3c7_gain"
 a_send vcs_mixer_ramp k_send, 1
 a_route_output = a_signal * a_send
 outleta "out", a_route_output
endin

; mixer stage strip:clouds
; mixer strip: EBM DW — Dark PWM Pad [clouds]
; initial gain: -8 dB; balance/pan: 0; mute: false; solo: false
; Voices and insert returns sum before the strip; pre taps precede balance/fader, post taps follow them.
instr vcs_mix_96411e998269110c17432444
 k_meter metro 15
 k_gain chnget "__vcs_mixer_strip_15fa97b5a488542761982797_gain"
 a_gain vcs_mixer_ramp k_gain, 0.3981071705534972
 k_left chnget "__vcs_mixer_strip_15fa97b5a488542761982797_left"
 a_left vcs_mixer_ramp k_left, 1
 k_right chnget "__vcs_mixer_strip_15fa97b5a488542761982797_right"
 a_right vcs_mixer_ramp k_right, 1
 k_mute chnget "__vcs_mixer_strip_15fa97b5a488542761982797_mute"
 a_mute vcs_mixer_ramp k_mute, 1
 a_p_360f84035942243c6a36537a inleta "p_360f84035942243c6a36537a"
 a_p_360f84035942243c6a36537a_post = a_p_360f84035942243c6a36537a * a_gain * a_left
 a_p_27042f4e6eca7d0b2a7ee402 inleta "p_27042f4e6eca7d0b2a7ee402"
 a_p_27042f4e6eca7d0b2a7ee402_post = a_p_27042f4e6eca7d0b2a7ee402 * a_gain * a_right
 a_meter_left = a_p_360f84035942243c6a36537a_post * a_mute
 a_meter_right = a_p_27042f4e6eca7d0b2a7ee402_post * a_mute
 k_peakL max_k a_meter_left, k_meter, 1
 k_rmsL rms a_meter_left
 chnset k_peakL / 1.0, "__vcs_mixer_meter_15fa97b5a488542761982797_peakL"
 chnset k_rmsL / 1.0, "__vcs_mixer_meter_15fa97b5a488542761982797_rmsL"
 k_peakR max_k a_meter_right, k_meter, 1
 k_rmsR rms a_meter_right
 chnset k_peakR / 1.0, "__vcs_mixer_meter_15fa97b5a488542761982797_peakR"
 chnset k_rmsR / 1.0, "__vcs_mixer_meter_15fa97b5a488542761982797_rmsR"
 outleta "pre_p_360f84035942243c6a36537a", a_p_360f84035942243c6a36537a
 outleta "post_p_360f84035942243c6a36537a", a_p_360f84035942243c6a36537a_post
 outleta "pre_p_27042f4e6eca7d0b2a7ee402", a_p_27042f4e6eca7d0b2a7ee402
 outleta "post_p_27042f4e6eca7d0b2a7ee402", a_p_27042f4e6eca7d0b2a7ee402_post
endin

; mixer stage route:clouds-to-master-left
; audio route:clouds-to-master-left kind:main
; from: EBM DW — Dark PWM Pad [clouds] port:left stage:strip -> Master [$master] port:left stage:input
; tap: post-fader; initial route gain: 0 dB; source mute and mixer solo gate this route.
instr vcs_mix_b99cad66f5a693384ddaaa91
 k_post chnget "__vcs_mixer_route_5c765a9573cccf11ec260943_post"
 a_post vcs_mixer_ramp k_post, 1
 k_pan chnget "__vcs_mixer_route_5c765a9573cccf11ec260943_pan"
 a_pan vcs_mixer_ramp k_pan, 1
 a_pre inleta "pre"
 a_post_signal inleta "post"
 a_signal = a_pre * (1 - a_post) + a_post_signal * a_post * a_pan
 k_send chnget "__vcs_mixer_route_5c765a9573cccf11ec260943_gain"
 a_send vcs_mixer_ramp k_send, 1
 a_route_output = a_signal * a_send
 outleta "out", a_route_output
endin

; mixer stage route:clouds-to-master-right
; audio route:clouds-to-master-right kind:main
; from: EBM DW — Dark PWM Pad [clouds] port:right stage:strip -> Master [$master] port:right stage:input
; tap: post-fader; initial route gain: 0 dB; source mute and mixer solo gate this route.
instr vcs_mix_bf6f81fb9ed80577ae278764
 k_post chnget "__vcs_mixer_route_aca770adf6d5aa1d37b31081_post"
 a_post vcs_mixer_ramp k_post, 1
 k_pan chnget "__vcs_mixer_route_aca770adf6d5aa1d37b31081_pan"
 a_pan vcs_mixer_ramp k_pan, 1
 a_pre inleta "pre"
 a_post_signal inleta "post"
 a_signal = a_pre * (1 - a_post) + a_post_signal * a_post * a_pan
 k_send chnget "__vcs_mixer_route_aca770adf6d5aa1d37b31081_gain"
 a_send vcs_mixer_ramp k_send, 1
 a_route_output = a_signal * a_send
 outleta "out", a_route_output
endin

; mixer stage strip:drums
; mixer strip: Analog Drumkit [drums]
; initial gain: -11 dB; balance/pan: 0; mute: false; solo: false
; Voices and insert returns sum before the strip; pre taps precede balance/fader, post taps follow them.
instr vcs_mix_233b9a10d13cb7345fe0ac51
 k_meter metro 15
 k_gain chnget "__vcs_mixer_strip_7cc44eb19abccf91739a7239_gain"
 a_gain vcs_mixer_ramp k_gain, 0.28183829312644537
 k_left chnget "__vcs_mixer_strip_7cc44eb19abccf91739a7239_left"
 a_left vcs_mixer_ramp k_left, 1
 k_right chnget "__vcs_mixer_strip_7cc44eb19abccf91739a7239_right"
 a_right vcs_mixer_ramp k_right, 1
 k_mute chnget "__vcs_mixer_strip_7cc44eb19abccf91739a7239_mute"
 a_mute vcs_mixer_ramp k_mute, 1
 a_p_360f84035942243c6a36537a inleta "p_360f84035942243c6a36537a"
 a_p_360f84035942243c6a36537a_post = a_p_360f84035942243c6a36537a * a_gain * a_left
 a_p_27042f4e6eca7d0b2a7ee402 inleta "p_27042f4e6eca7d0b2a7ee402"
 a_p_27042f4e6eca7d0b2a7ee402_post = a_p_27042f4e6eca7d0b2a7ee402 * a_gain * a_right
 a_meter_left = a_p_360f84035942243c6a36537a_post * a_mute
 a_meter_right = a_p_27042f4e6eca7d0b2a7ee402_post * a_mute
 k_peakL max_k a_meter_left, k_meter, 1
 k_rmsL rms a_meter_left
 chnset k_peakL / 1.0, "__vcs_mixer_meter_7cc44eb19abccf91739a7239_peakL"
 chnset k_rmsL / 1.0, "__vcs_mixer_meter_7cc44eb19abccf91739a7239_rmsL"
 k_peakR max_k a_meter_right, k_meter, 1
 k_rmsR rms a_meter_right
 chnset k_peakR / 1.0, "__vcs_mixer_meter_7cc44eb19abccf91739a7239_peakR"
 chnset k_rmsR / 1.0, "__vcs_mixer_meter_7cc44eb19abccf91739a7239_rmsR"
 outleta "pre_p_360f84035942243c6a36537a", a_p_360f84035942243c6a36537a
 outleta "post_p_360f84035942243c6a36537a", a_p_360f84035942243c6a36537a_post
 outleta "pre_p_27042f4e6eca7d0b2a7ee402", a_p_27042f4e6eca7d0b2a7ee402
 outleta "post_p_27042f4e6eca7d0b2a7ee402", a_p_27042f4e6eca7d0b2a7ee402_post
endin

; mixer stage route:drums-to-master-left
; audio route:drums-to-master-left kind:main
; from: Analog Drumkit [drums] port:left stage:strip -> Master [$master] port:left stage:input
; tap: post-fader; initial route gain: 0 dB; source mute and mixer solo gate this route.
instr vcs_mix_776a9ca62745889b1ae2494d
 k_post chnget "__vcs_mixer_route_83b8456f5a6ccf61bd09771f_post"
 a_post vcs_mixer_ramp k_post, 1
 k_pan chnget "__vcs_mixer_route_83b8456f5a6ccf61bd09771f_pan"
 a_pan vcs_mixer_ramp k_pan, 1
 a_pre inleta "pre"
 a_post_signal inleta "post"
 a_signal = a_pre * (1 - a_post) + a_post_signal * a_post * a_pan
 k_send chnget "__vcs_mixer_route_83b8456f5a6ccf61bd09771f_gain"
 a_send vcs_mixer_ramp k_send, 1
 a_route_output = a_signal * a_send
 outleta "out", a_route_output
endin

; mixer stage route:drums-to-master-right
; audio route:drums-to-master-right kind:main
; from: Analog Drumkit [drums] port:right stage:strip -> Master [$master] port:right stage:input
; tap: post-fader; initial route gain: 0 dB; source mute and mixer solo gate this route.
instr vcs_mix_38e2e3dd71d7c951b8ee623c
 k_post chnget "__vcs_mixer_route_b5f389b4e240e65eb88e717c_post"
 a_post vcs_mixer_ramp k_post, 1
 k_pan chnget "__vcs_mixer_route_b5f389b4e240e65eb88e717c_pan"
 a_pan vcs_mixer_ramp k_pan, 1
 a_pre inleta "pre"
 a_post_signal inleta "post"
 a_signal = a_pre * (1 - a_post) + a_post_signal * a_post * a_pan
 k_send chnget "__vcs_mixer_route_b5f389b4e240e65eb88e717c_gain"
 a_send vcs_mixer_ramp k_send, 1
 a_route_output = a_signal * a_send
 outleta "out", a_route_output
endin

; mixer stage strip:glints
; mixer strip: EBM DW — Glass Bell [glints]
; initial gain: -12 dB; balance/pan: 0.15; mute: false; solo: false
; Voices and insert returns sum before the strip; pre taps precede balance/fader, post taps follow them.
instr vcs_mix_3fb9b3909cb149df8c692155
 k_meter metro 15
 k_gain chnget "__vcs_mixer_strip_5187e59d9b00ec8dfc6ace45_gain"
 a_gain vcs_mixer_ramp k_gain, 0.25118864315095801
 k_left chnget "__vcs_mixer_strip_5187e59d9b00ec8dfc6ace45_left"
 a_left vcs_mixer_ramp k_left, 0.84999999999999998
 k_right chnget "__vcs_mixer_strip_5187e59d9b00ec8dfc6ace45_right"
 a_right vcs_mixer_ramp k_right, 1
 k_mute chnget "__vcs_mixer_strip_5187e59d9b00ec8dfc6ace45_mute"
 a_mute vcs_mixer_ramp k_mute, 1
 a_p_360f84035942243c6a36537a inleta "p_360f84035942243c6a36537a"
 a_p_360f84035942243c6a36537a_post = a_p_360f84035942243c6a36537a * a_gain * a_left
 a_p_27042f4e6eca7d0b2a7ee402 inleta "p_27042f4e6eca7d0b2a7ee402"
 a_p_27042f4e6eca7d0b2a7ee402_post = a_p_27042f4e6eca7d0b2a7ee402 * a_gain * a_right
 a_meter_left = a_p_360f84035942243c6a36537a_post * a_mute
 a_meter_right = a_p_27042f4e6eca7d0b2a7ee402_post * a_mute
 k_peakL max_k a_meter_left, k_meter, 1
 k_rmsL rms a_meter_left
 chnset k_peakL / 1.0, "__vcs_mixer_meter_5187e59d9b00ec8dfc6ace45_peakL"
 chnset k_rmsL / 1.0, "__vcs_mixer_meter_5187e59d9b00ec8dfc6ace45_rmsL"
 k_peakR max_k a_meter_right, k_meter, 1
 k_rmsR rms a_meter_right
 chnset k_peakR / 1.0, "__vcs_mixer_meter_5187e59d9b00ec8dfc6ace45_peakR"
 chnset k_rmsR / 1.0, "__vcs_mixer_meter_5187e59d9b00ec8dfc6ace45_rmsR"
 outleta "pre_p_360f84035942243c6a36537a", a_p_360f84035942243c6a36537a
 outleta "post_p_360f84035942243c6a36537a", a_p_360f84035942243c6a36537a_post
 outleta "pre_p_27042f4e6eca7d0b2a7ee402", a_p_27042f4e6eca7d0b2a7ee402
 outleta "post_p_27042f4e6eca7d0b2a7ee402", a_p_27042f4e6eca7d0b2a7ee402_post
endin

; mixer stage route:glints-to-master-left
; audio route:glints-to-master-left kind:main
; from: EBM DW — Glass Bell [glints] port:left stage:strip -> Master [$master] port:left stage:input
; tap: post-fader; initial route gain: 0 dB; source mute and mixer solo gate this route.
instr vcs_mix_7a9040b07366a0daa7dc6894
 k_post chnget "__vcs_mixer_route_7d9706dbf4b80041a7bac944_post"
 a_post vcs_mixer_ramp k_post, 1
 k_pan chnget "__vcs_mixer_route_7d9706dbf4b80041a7bac944_pan"
 a_pan vcs_mixer_ramp k_pan, 1
 a_pre inleta "pre"
 a_post_signal inleta "post"
 a_signal = a_pre * (1 - a_post) + a_post_signal * a_post * a_pan
 k_send chnget "__vcs_mixer_route_7d9706dbf4b80041a7bac944_gain"
 a_send vcs_mixer_ramp k_send, 1
 a_route_output = a_signal * a_send
 outleta "out", a_route_output
endin

; mixer stage route:glints-to-master-right
; audio route:glints-to-master-right kind:main
; from: EBM DW — Glass Bell [glints] port:right stage:strip -> Master [$master] port:right stage:input
; tap: post-fader; initial route gain: 0 dB; source mute and mixer solo gate this route.
instr vcs_mix_898dca64f18bed88c536cb6b
 k_post chnget "__vcs_mixer_route_5471588a628d780162691603_post"
 a_post vcs_mixer_ramp k_post, 1
 k_pan chnget "__vcs_mixer_route_5471588a628d780162691603_pan"
 a_pan vcs_mixer_ramp k_pan, 1
 a_pre inleta "pre"
 a_post_signal inleta "post"
 a_signal = a_pre * (1 - a_post) + a_post_signal * a_post * a_pan
 k_send chnget "__vcs_mixer_route_5471588a628d780162691603_gain"
 a_send vcs_mixer_ramp k_send, 1
 a_route_output = a_signal * a_send
 outleta "out", a_route_output
endin

; mixer stage strip:strikes
; mixer strip: EBM DW — Industrial Stab [strikes]
; initial gain: -14 dB; balance/pan: -0.12; mute: false; solo: false
; Voices and insert returns sum before the strip; pre taps precede balance/fader, post taps follow them.
instr vcs_mix_d128d928004c9323f776f93a
 k_meter metro 15
 k_gain chnget "__vcs_mixer_strip_69a5a5c217c582a0ca581019_gain"
 a_gain vcs_mixer_ramp k_gain, 0.19952623149688797
 k_left chnget "__vcs_mixer_strip_69a5a5c217c582a0ca581019_left"
 a_left vcs_mixer_ramp k_left, 1
 k_right chnget "__vcs_mixer_strip_69a5a5c217c582a0ca581019_right"
 a_right vcs_mixer_ramp k_right, 0.88
 k_mute chnget "__vcs_mixer_strip_69a5a5c217c582a0ca581019_mute"
 a_mute vcs_mixer_ramp k_mute, 1
 a_p_360f84035942243c6a36537a inleta "p_360f84035942243c6a36537a"
 a_p_360f84035942243c6a36537a_post = a_p_360f84035942243c6a36537a * a_gain * a_left
 a_p_27042f4e6eca7d0b2a7ee402 inleta "p_27042f4e6eca7d0b2a7ee402"
 a_p_27042f4e6eca7d0b2a7ee402_post = a_p_27042f4e6eca7d0b2a7ee402 * a_gain * a_right
 a_meter_left = a_p_360f84035942243c6a36537a_post * a_mute
 a_meter_right = a_p_27042f4e6eca7d0b2a7ee402_post * a_mute
 k_peakL max_k a_meter_left, k_meter, 1
 k_rmsL rms a_meter_left
 chnset k_peakL / 1.0, "__vcs_mixer_meter_69a5a5c217c582a0ca581019_peakL"
 chnset k_rmsL / 1.0, "__vcs_mixer_meter_69a5a5c217c582a0ca581019_rmsL"
 k_peakR max_k a_meter_right, k_meter, 1
 k_rmsR rms a_meter_right
 chnset k_peakR / 1.0, "__vcs_mixer_meter_69a5a5c217c582a0ca581019_peakR"
 chnset k_rmsR / 1.0, "__vcs_mixer_meter_69a5a5c217c582a0ca581019_rmsR"
 outleta "pre_p_360f84035942243c6a36537a", a_p_360f84035942243c6a36537a
 outleta "post_p_360f84035942243c6a36537a", a_p_360f84035942243c6a36537a_post
 outleta "pre_p_27042f4e6eca7d0b2a7ee402", a_p_27042f4e6eca7d0b2a7ee402
 outleta "post_p_27042f4e6eca7d0b2a7ee402", a_p_27042f4e6eca7d0b2a7ee402_post
endin

; mixer stage route:strikes-to-master-left
; audio route:strikes-to-master-left kind:main
; from: EBM DW — Industrial Stab [strikes] port:left stage:strip -> Master [$master] port:left stage:input
; tap: post-fader; initial route gain: 0 dB; source mute and mixer solo gate this route.
instr vcs_mix_725f6223d9072d1bb2e23c76
 k_post chnget "__vcs_mixer_route_1d60c1873f7c84bee9eada4e_post"
 a_post vcs_mixer_ramp k_post, 1
 k_pan chnget "__vcs_mixer_route_1d60c1873f7c84bee9eada4e_pan"
 a_pan vcs_mixer_ramp k_pan, 1
 a_pre inleta "pre"
 a_post_signal inleta "post"
 a_signal = a_pre * (1 - a_post) + a_post_signal * a_post * a_pan
 k_send chnget "__vcs_mixer_route_1d60c1873f7c84bee9eada4e_gain"
 a_send vcs_mixer_ramp k_send, 1
 a_route_output = a_signal * a_send
 outleta "out", a_route_output
endin

; mixer stage route:strikes-to-master-right
; audio route:strikes-to-master-right kind:main
; from: EBM DW — Industrial Stab [strikes] port:right stage:strip -> Master [$master] port:right stage:input
; tap: post-fader; initial route gain: 0 dB; source mute and mixer solo gate this route.
instr vcs_mix_d04fd17777bbf3b8af8783a5
 k_post chnget "__vcs_mixer_route_51517161fc68e6e3eeac9206_post"
 a_post vcs_mixer_ramp k_post, 1
 k_pan chnget "__vcs_mixer_route_51517161fc68e6e3eeac9206_pan"
 a_pan vcs_mixer_ramp k_pan, 1
 a_pre inleta "pre"
 a_post_signal inleta "post"
 a_signal = a_pre * (1 - a_post) + a_post_signal * a_post * a_pan
 k_send chnget "__vcs_mixer_route_51517161fc68e6e3eeac9206_gain"
 a_send vcs_mixer_ramp k_send, 1
 a_route_output = a_signal * a_send
 outleta "out", a_route_output
endin

; mixer stage strip:sunlight
; mixer strip: EBM DW — String Ensemble [sunlight]
; initial gain: -1 dB; balance/pan: 0; mute: false; solo: false
; Voices and insert returns sum before the strip; pre taps precede balance/fader, post taps follow them.
instr vcs_mix_ac92f39f17c2687b02e604f4
 k_meter metro 15
 k_gain chnget "__vcs_mixer_strip_921a95e8b614f668981d9eee_gain"
 a_gain vcs_mixer_ramp k_gain, 0.89125093813374556
 k_left chnget "__vcs_mixer_strip_921a95e8b614f668981d9eee_left"
 a_left vcs_mixer_ramp k_left, 1
 k_right chnget "__vcs_mixer_strip_921a95e8b614f668981d9eee_right"
 a_right vcs_mixer_ramp k_right, 1
 k_mute chnget "__vcs_mixer_strip_921a95e8b614f668981d9eee_mute"
 a_mute vcs_mixer_ramp k_mute, 1
 a_p_360f84035942243c6a36537a inleta "p_360f84035942243c6a36537a"
 a_p_360f84035942243c6a36537a_post = a_p_360f84035942243c6a36537a * a_gain * a_left
 a_p_27042f4e6eca7d0b2a7ee402 inleta "p_27042f4e6eca7d0b2a7ee402"
 a_p_27042f4e6eca7d0b2a7ee402_post = a_p_27042f4e6eca7d0b2a7ee402 * a_gain * a_right
 a_meter_left = a_p_360f84035942243c6a36537a_post * a_mute
 a_meter_right = a_p_27042f4e6eca7d0b2a7ee402_post * a_mute
 k_peakL max_k a_meter_left, k_meter, 1
 k_rmsL rms a_meter_left
 chnset k_peakL / 1.0, "__vcs_mixer_meter_921a95e8b614f668981d9eee_peakL"
 chnset k_rmsL / 1.0, "__vcs_mixer_meter_921a95e8b614f668981d9eee_rmsL"
 k_peakR max_k a_meter_right, k_meter, 1
 k_rmsR rms a_meter_right
 chnset k_peakR / 1.0, "__vcs_mixer_meter_921a95e8b614f668981d9eee_peakR"
 chnset k_rmsR / 1.0, "__vcs_mixer_meter_921a95e8b614f668981d9eee_rmsR"
 outleta "pre_p_360f84035942243c6a36537a", a_p_360f84035942243c6a36537a
 outleta "post_p_360f84035942243c6a36537a", a_p_360f84035942243c6a36537a_post
 outleta "pre_p_27042f4e6eca7d0b2a7ee402", a_p_27042f4e6eca7d0b2a7ee402
 outleta "post_p_27042f4e6eca7d0b2a7ee402", a_p_27042f4e6eca7d0b2a7ee402_post
endin

; mixer stage route:sunlight-to-master-left
; audio route:sunlight-to-master-left kind:main
; from: EBM DW — String Ensemble [sunlight] port:left stage:strip -> Master [$master] port:left stage:input
; tap: post-fader; initial route gain: 0 dB; source mute and mixer solo gate this route.
instr vcs_mix_9f8ea62d9094b1ee06064c74
 k_post chnget "__vcs_mixer_route_c01b8e240438f78a8824cfd3_post"
 a_post vcs_mixer_ramp k_post, 1
 k_pan chnget "__vcs_mixer_route_c01b8e240438f78a8824cfd3_pan"
 a_pan vcs_mixer_ramp k_pan, 1
 a_pre inleta "pre"
 a_post_signal inleta "post"
 a_signal = a_pre * (1 - a_post) + a_post_signal * a_post * a_pan
 k_send chnget "__vcs_mixer_route_c01b8e240438f78a8824cfd3_gain"
 a_send vcs_mixer_ramp k_send, 1
 a_route_output = a_signal * a_send
 outleta "out", a_route_output
endin

; mixer stage route:sunlight-to-master-right
; audio route:sunlight-to-master-right kind:main
; from: EBM DW — String Ensemble [sunlight] port:right stage:strip -> Master [$master] port:right stage:input
; tap: post-fader; initial route gain: 0 dB; source mute and mixer solo gate this route.
instr vcs_mix_ab29dbdb974d3cf3720ccde1
 k_post chnget "__vcs_mixer_route_1a360e0bf12680fcccccf68a_post"
 a_post vcs_mixer_ramp k_post, 1
 k_pan chnget "__vcs_mixer_route_1a360e0bf12680fcccccf68a_pan"
 a_pan vcs_mixer_ramp k_pan, 1
 a_pre inleta "pre"
 a_post_signal inleta "post"
 a_signal = a_pre * (1 - a_post) + a_post_signal * a_post * a_pan
 k_send chnget "__vcs_mixer_route_1a360e0bf12680fcccccf68a_gain"
 a_send vcs_mixer_ramp k_send, 1
 a_route_output = a_signal * a_send
 outleta "out", a_route_output
endin

; mixer stage strip:sunrays
; mixer strip: EBM DW — Analog Brass [sunrays]
; initial gain: 0 dB; balance/pan: 0.13; mute: false; solo: false
; Voices and insert returns sum before the strip; pre taps precede balance/fader, post taps follow them.
instr vcs_mix_c5cc5b5de6f0d6ab45b331f7
 k_meter metro 15
 k_gain chnget "__vcs_mixer_strip_4357ddb2013f8c1bae14ef67_gain"
 a_gain vcs_mixer_ramp k_gain, 1
 k_left chnget "__vcs_mixer_strip_4357ddb2013f8c1bae14ef67_left"
 a_left vcs_mixer_ramp k_left, 0.87
 k_right chnget "__vcs_mixer_strip_4357ddb2013f8c1bae14ef67_right"
 a_right vcs_mixer_ramp k_right, 1
 k_mute chnget "__vcs_mixer_strip_4357ddb2013f8c1bae14ef67_mute"
 a_mute vcs_mixer_ramp k_mute, 1
 a_p_360f84035942243c6a36537a inleta "p_360f84035942243c6a36537a"
 a_p_360f84035942243c6a36537a_post = a_p_360f84035942243c6a36537a * a_gain * a_left
 a_p_27042f4e6eca7d0b2a7ee402 inleta "p_27042f4e6eca7d0b2a7ee402"
 a_p_27042f4e6eca7d0b2a7ee402_post = a_p_27042f4e6eca7d0b2a7ee402 * a_gain * a_right
 a_meter_left = a_p_360f84035942243c6a36537a_post * a_mute
 a_meter_right = a_p_27042f4e6eca7d0b2a7ee402_post * a_mute
 k_peakL max_k a_meter_left, k_meter, 1
 k_rmsL rms a_meter_left
 chnset k_peakL / 1.0, "__vcs_mixer_meter_4357ddb2013f8c1bae14ef67_peakL"
 chnset k_rmsL / 1.0, "__vcs_mixer_meter_4357ddb2013f8c1bae14ef67_rmsL"
 k_peakR max_k a_meter_right, k_meter, 1
 k_rmsR rms a_meter_right
 chnset k_peakR / 1.0, "__vcs_mixer_meter_4357ddb2013f8c1bae14ef67_peakR"
 chnset k_rmsR / 1.0, "__vcs_mixer_meter_4357ddb2013f8c1bae14ef67_rmsR"
 outleta "pre_p_360f84035942243c6a36537a", a_p_360f84035942243c6a36537a
 outleta "post_p_360f84035942243c6a36537a", a_p_360f84035942243c6a36537a_post
 outleta "pre_p_27042f4e6eca7d0b2a7ee402", a_p_27042f4e6eca7d0b2a7ee402
 outleta "post_p_27042f4e6eca7d0b2a7ee402", a_p_27042f4e6eca7d0b2a7ee402_post
endin

; mixer stage route:sunrays-to-master-left
; audio route:sunrays-to-master-left kind:main
; from: EBM DW — Analog Brass [sunrays] port:left stage:strip -> Master [$master] port:left stage:input
; tap: post-fader; initial route gain: 0 dB; source mute and mixer solo gate this route.
instr vcs_mix_a0bf5a6e682d1681b8c6dcab
 k_post chnget "__vcs_mixer_route_3bf52259f3a75a40898bd370_post"
 a_post vcs_mixer_ramp k_post, 1
 k_pan chnget "__vcs_mixer_route_3bf52259f3a75a40898bd370_pan"
 a_pan vcs_mixer_ramp k_pan, 1
 a_pre inleta "pre"
 a_post_signal inleta "post"
 a_signal = a_pre * (1 - a_post) + a_post_signal * a_post * a_pan
 k_send chnget "__vcs_mixer_route_3bf52259f3a75a40898bd370_gain"
 a_send vcs_mixer_ramp k_send, 1
 a_route_output = a_signal * a_send
 outleta "out", a_route_output
endin

; mixer stage route:sunrays-to-master-right
; audio route:sunrays-to-master-right kind:main
; from: EBM DW — Analog Brass [sunrays] port:right stage:strip -> Master [$master] port:right stage:input
; tap: post-fader; initial route gain: 0 dB; source mute and mixer solo gate this route.
instr vcs_mix_5e006bf5e9b69c39e6038e0c
 k_post chnget "__vcs_mixer_route_95085945e8b7aaf31960266c_post"
 a_post vcs_mixer_ramp k_post, 1
 k_pan chnget "__vcs_mixer_route_95085945e8b7aaf31960266c_pan"
 a_pan vcs_mixer_ramp k_pan, 1
 a_pre inleta "pre"
 a_post_signal inleta "post"
 a_signal = a_pre * (1 - a_post) + a_post_signal * a_post * a_pan
 k_send chnget "__vcs_mixer_route_95085945e8b7aaf31960266c_gain"
 a_send vcs_mixer_ramp k_send, 1
 a_route_output = a_signal * a_send
 outleta "out", a_route_output
endin

; mixer stage strip:theme
; mixer strip: EBM DW — Dark Saw Lead [theme]
; initial gain: 0 dB; balance/pan: -0.08; mute: false; solo: false
; Voices and insert returns sum before the strip; pre taps precede balance/fader, post taps follow them.
instr vcs_mix_8a252033ed35df6ff80fdae8
 k_meter metro 15
 k_gain chnget "__vcs_mixer_strip_3cb8201e7ff1e7777446032e_gain"
 a_gain vcs_mixer_ramp k_gain, 1
 k_left chnget "__vcs_mixer_strip_3cb8201e7ff1e7777446032e_left"
 a_left vcs_mixer_ramp k_left, 1
 k_right chnget "__vcs_mixer_strip_3cb8201e7ff1e7777446032e_right"
 a_right vcs_mixer_ramp k_right, 0.92000000000000004
 k_mute chnget "__vcs_mixer_strip_3cb8201e7ff1e7777446032e_mute"
 a_mute vcs_mixer_ramp k_mute, 1
 a_p_360f84035942243c6a36537a inleta "p_360f84035942243c6a36537a"
 a_p_360f84035942243c6a36537a_post = a_p_360f84035942243c6a36537a * a_gain * a_left
 a_p_27042f4e6eca7d0b2a7ee402 inleta "p_27042f4e6eca7d0b2a7ee402"
 a_p_27042f4e6eca7d0b2a7ee402_post = a_p_27042f4e6eca7d0b2a7ee402 * a_gain * a_right
 a_meter_left = a_p_360f84035942243c6a36537a_post * a_mute
 a_meter_right = a_p_27042f4e6eca7d0b2a7ee402_post * a_mute
 k_peakL max_k a_meter_left, k_meter, 1
 k_rmsL rms a_meter_left
 chnset k_peakL / 1.0, "__vcs_mixer_meter_3cb8201e7ff1e7777446032e_peakL"
 chnset k_rmsL / 1.0, "__vcs_mixer_meter_3cb8201e7ff1e7777446032e_rmsL"
 k_peakR max_k a_meter_right, k_meter, 1
 k_rmsR rms a_meter_right
 chnset k_peakR / 1.0, "__vcs_mixer_meter_3cb8201e7ff1e7777446032e_peakR"
 chnset k_rmsR / 1.0, "__vcs_mixer_meter_3cb8201e7ff1e7777446032e_rmsR"
 outleta "pre_p_360f84035942243c6a36537a", a_p_360f84035942243c6a36537a
 outleta "post_p_360f84035942243c6a36537a", a_p_360f84035942243c6a36537a_post
 outleta "pre_p_27042f4e6eca7d0b2a7ee402", a_p_27042f4e6eca7d0b2a7ee402
 outleta "post_p_27042f4e6eca7d0b2a7ee402", a_p_27042f4e6eca7d0b2a7ee402_post
endin

; mixer stage route:theme-to-master-left
; audio route:theme-to-master-left kind:main
; from: EBM DW — Dark Saw Lead [theme] port:left stage:strip -> Master [$master] port:left stage:input
; tap: post-fader; initial route gain: 0 dB; source mute and mixer solo gate this route.
instr vcs_mix_72eedbbbd4d867877d198844
 k_post chnget "__vcs_mixer_route_6ef9be26494bffae34fdfd29_post"
 a_post vcs_mixer_ramp k_post, 1
 k_pan chnget "__vcs_mixer_route_6ef9be26494bffae34fdfd29_pan"
 a_pan vcs_mixer_ramp k_pan, 1
 a_pre inleta "pre"
 a_post_signal inleta "post"
 a_signal = a_pre * (1 - a_post) + a_post_signal * a_post * a_pan
 k_send chnget "__vcs_mixer_route_6ef9be26494bffae34fdfd29_gain"
 a_send vcs_mixer_ramp k_send, 1
 a_route_output = a_signal * a_send
 outleta "out", a_route_output
endin

; mixer stage route:theme-to-master-right
; audio route:theme-to-master-right kind:main
; from: EBM DW — Dark Saw Lead [theme] port:right stage:strip -> Master [$master] port:right stage:input
; tap: post-fader; initial route gain: 0 dB; source mute and mixer solo gate this route.
instr vcs_mix_bf26ce664958883e5fa5077a
 k_post chnget "__vcs_mixer_route_43f837ee6d4c255b17854c22_post"
 a_post vcs_mixer_ramp k_post, 1
 k_pan chnget "__vcs_mixer_route_43f837ee6d4c255b17854c22_pan"
 a_pan vcs_mixer_ramp k_pan, 1
 a_pre inleta "pre"
 a_post_signal inleta "post"
 a_signal = a_pre * (1 - a_post) + a_post_signal * a_post * a_pan
 k_send chnget "__vcs_mixer_route_43f837ee6d4c255b17854c22_gain"
 a_send vcs_mixer_ramp k_send, 1
 a_route_output = a_signal * a_send
 outleta "out", a_route_output
endin

; mixer stage strip:weather
; mixer strip: EBM DW — Noise Metal FX [weather]
; initial gain: -16 dB; balance/pan: 0; mute: false; solo: false
; Voices and insert returns sum before the strip; pre taps precede balance/fader, post taps follow them.
instr vcs_mix_e1d7e481eb08ca2b9fc71c78
 k_meter metro 15
 k_gain chnget "__vcs_mixer_strip_e5e72beb4e3c6926d3dc9e3e_gain"
 a_gain vcs_mixer_ramp k_gain, 0.15848931924611134
 k_left chnget "__vcs_mixer_strip_e5e72beb4e3c6926d3dc9e3e_left"
 a_left vcs_mixer_ramp k_left, 1
 k_right chnget "__vcs_mixer_strip_e5e72beb4e3c6926d3dc9e3e_right"
 a_right vcs_mixer_ramp k_right, 1
 k_mute chnget "__vcs_mixer_strip_e5e72beb4e3c6926d3dc9e3e_mute"
 a_mute vcs_mixer_ramp k_mute, 1
 a_p_360f84035942243c6a36537a inleta "p_360f84035942243c6a36537a"
 a_p_360f84035942243c6a36537a_post = a_p_360f84035942243c6a36537a * a_gain * a_left
 a_p_27042f4e6eca7d0b2a7ee402 inleta "p_27042f4e6eca7d0b2a7ee402"
 a_p_27042f4e6eca7d0b2a7ee402_post = a_p_27042f4e6eca7d0b2a7ee402 * a_gain * a_right
 a_meter_left = a_p_360f84035942243c6a36537a_post * a_mute
 a_meter_right = a_p_27042f4e6eca7d0b2a7ee402_post * a_mute
 k_peakL max_k a_meter_left, k_meter, 1
 k_rmsL rms a_meter_left
 chnset k_peakL / 1.0, "__vcs_mixer_meter_e5e72beb4e3c6926d3dc9e3e_peakL"
 chnset k_rmsL / 1.0, "__vcs_mixer_meter_e5e72beb4e3c6926d3dc9e3e_rmsL"
 k_peakR max_k a_meter_right, k_meter, 1
 k_rmsR rms a_meter_right
 chnset k_peakR / 1.0, "__vcs_mixer_meter_e5e72beb4e3c6926d3dc9e3e_peakR"
 chnset k_rmsR / 1.0, "__vcs_mixer_meter_e5e72beb4e3c6926d3dc9e3e_rmsR"
 outleta "pre_p_360f84035942243c6a36537a", a_p_360f84035942243c6a36537a
 outleta "post_p_360f84035942243c6a36537a", a_p_360f84035942243c6a36537a_post
 outleta "pre_p_27042f4e6eca7d0b2a7ee402", a_p_27042f4e6eca7d0b2a7ee402
 outleta "post_p_27042f4e6eca7d0b2a7ee402", a_p_27042f4e6eca7d0b2a7ee402_post
endin

; mixer stage route:weather-to-master-left
; audio route:weather-to-master-left kind:main
; from: EBM DW — Noise Metal FX [weather] port:left stage:strip -> Master [$master] port:left stage:input
; tap: post-fader; initial route gain: 0 dB; source mute and mixer solo gate this route.
instr vcs_mix_e07cbf7b561e14be9651d6d0
 k_post chnget "__vcs_mixer_route_215dfad6ea4278df9c5b5929_post"
 a_post vcs_mixer_ramp k_post, 1
 k_pan chnget "__vcs_mixer_route_215dfad6ea4278df9c5b5929_pan"
 a_pan vcs_mixer_ramp k_pan, 1
 a_pre inleta "pre"
 a_post_signal inleta "post"
 a_signal = a_pre * (1 - a_post) + a_post_signal * a_post * a_pan
 k_send chnget "__vcs_mixer_route_215dfad6ea4278df9c5b5929_gain"
 a_send vcs_mixer_ramp k_send, 1
 a_route_output = a_signal * a_send
 outleta "out", a_route_output
endin

; mixer stage route:weather-to-master-right
; audio route:weather-to-master-right kind:main
; from: EBM DW — Noise Metal FX [weather] port:right stage:strip -> Master [$master] port:right stage:input
; tap: post-fader; initial route gain: 0 dB; source mute and mixer solo gate this route.
instr vcs_mix_9fa67706cd4495d936a25713
 k_post chnget "__vcs_mixer_route_7ccdeae3e4931ae57c24ee42_post"
 a_post vcs_mixer_ramp k_post, 1
 k_pan chnget "__vcs_mixer_route_7ccdeae3e4931ae57c24ee42_pan"
 a_pan vcs_mixer_ramp k_pan, 1
 a_pre inleta "pre"
 a_post_signal inleta "post"
 a_signal = a_pre * (1 - a_post) + a_post_signal * a_post * a_pan
 k_send chnget "__vcs_mixer_route_7ccdeae3e4931ae57c24ee42_gain"
 a_send vcs_mixer_ramp k_send, 1
 a_route_output = a_signal * a_send
 outleta "out", a_route_output
endin

; mixer stage patch:$master
; patch:$master name:Master channel:0 always_on:true
; instance:$master csound:vcs_mix_63254fa67083d5eed1f09ece
; trigger: continuous (alwayson); score instrument number: 37
; role: Master processor; only audio explicitly routed here passes through Master.
instr vcs_mix_63254fa67083d5eed1f09ece
 a_left inleta "left"
 a_right inleta "right"
 outleta "__vcs_direct_e0ee8bb50685e05fa0f47ed0_left", a_left
 outleta "__vcs_direct_e0ee8bb50685e05fa0f47ed0_right", a_right
endin

; mixer stage strip:$master
; mixer strip: Master [$master]
; initial gain: -4 dB; balance/pan: 0; mute: false; solo: false
; Voices and insert returns sum before the strip; pre taps precede balance/fader, post taps follow them.
instr vcs_mix_0644eeee2942927583ef32ed
 k_meter metro 15
 k_gain chnget "__vcs_mixer_strip_b5c7638620f2f38a657a5790_gain"
 a_gain vcs_mixer_ramp k_gain, 0.63095734448019325
 k_left chnget "__vcs_mixer_strip_b5c7638620f2f38a657a5790_left"
 a_left vcs_mixer_ramp k_left, 1
 k_right chnget "__vcs_mixer_strip_b5c7638620f2f38a657a5790_right"
 a_right vcs_mixer_ramp k_right, 1
 k_mute chnget "__vcs_mixer_strip_b5c7638620f2f38a657a5790_mute"
 a_mute vcs_mixer_ramp k_mute, 1
 a_p_2336acbd28828ab05deafe52 inleta "p_2336acbd28828ab05deafe52"
 a_p_2336acbd28828ab05deafe52_post = a_p_2336acbd28828ab05deafe52 * a_gain * a_left
 a_p_2a250433534f9aea9d512171 inleta "p_2a250433534f9aea9d512171"
 a_p_2a250433534f9aea9d512171_post = a_p_2a250433534f9aea9d512171 * a_gain * a_right
 a_meter_left = a_p_2336acbd28828ab05deafe52_post * a_mute
 a_meter_right = a_p_2a250433534f9aea9d512171_post * a_mute
 k_peakL max_k a_meter_left, k_meter, 1
 k_rmsL rms a_meter_left
 chnset k_peakL / 1.0, "__vcs_mixer_meter_b5c7638620f2f38a657a5790_peakL"
 chnset k_rmsL / 1.0, "__vcs_mixer_meter_b5c7638620f2f38a657a5790_rmsL"
 k_peakR max_k a_meter_right, k_meter, 1
 k_rmsR rms a_meter_right
 chnset k_peakR / 1.0, "__vcs_mixer_meter_b5c7638620f2f38a657a5790_peakR"
 chnset k_rmsR / 1.0, "__vcs_mixer_meter_b5c7638620f2f38a657a5790_rmsR"
 outleta "pre_p_2336acbd28828ab05deafe52", a_p_2336acbd28828ab05deafe52
 outleta "post_p_2336acbd28828ab05deafe52", a_p_2336acbd28828ab05deafe52_post
 outleta "pre_p_2a250433534f9aea9d512171", a_p_2a250433534f9aea9d512171
 outleta "post_p_2a250433534f9aea9d512171", a_p_2a250433534f9aea9d512171_post
endin

; mixer stage route:direct_663d9de6aaa09d717ad1da85
; audio route:direct_663d9de6aaa09d717ad1da85 kind:main
; from: Master [$master] port:$direct.left stage:strip -> Audio Output port:left stage:input
; tap: post-fader; initial route gain: 0 dB; source mute and mixer solo gate this route.
instr vcs_mix_ec8b1641891924a3e102560a
 k_post chnget "__vcs_mixer_route_ebe4d00ca1570557781dee01_post"
 a_post vcs_mixer_ramp k_post, 1
 k_pan chnget "__vcs_mixer_route_ebe4d00ca1570557781dee01_pan"
 a_pan vcs_mixer_ramp k_pan, 1
 a_pre inleta "pre"
 a_post_signal inleta "post"
 a_signal = a_pre * (1 - a_post) + a_post_signal * a_post * a_pan
 k_send chnget "__vcs_mixer_route_ebe4d00ca1570557781dee01_gain"
 a_send vcs_mixer_ramp k_send, 1
 a_route_output = a_signal * a_send
 outleta "out", a_route_output
endin

; mixer stage route:direct_86c9f89b472612e7d2cddb1f
; audio route:direct_86c9f89b472612e7d2cddb1f kind:main
; from: Master [$master] port:$direct.right stage:strip -> Audio Output port:right stage:input
; tap: post-fader; initial route gain: 0 dB; source mute and mixer solo gate this route.
instr vcs_mix_5f16b779ade2ce91f307ff35
 k_post chnget "__vcs_mixer_route_208ab40923d5bf707587f01b_post"
 a_post vcs_mixer_ramp k_post, 1
 k_pan chnget "__vcs_mixer_route_208ab40923d5bf707587f01b_pan"
 a_pan vcs_mixer_ramp k_pan, 1
 a_pre inleta "pre"
 a_post_signal inleta "post"
 a_signal = a_pre * (1 - a_post) + a_post_signal * a_post * a_pan
 k_send chnget "__vcs_mixer_route_208ab40923d5bf707587f01b_gain"
 a_send vcs_mixer_ramp k_send, 1
 a_route_output = a_signal * a_send
 outleta "out", a_route_output
endin

; mixer stage $output
; Final Audio Output: sums all routed paths, including direct paths that bypass Master.
instr vcs_mix_9cea1be1f8255375a6cf7b93
 a_left inleta "left"
 a_right inleta "right"
 outs a_left, a_right
 k_meter metro 15
 k_peakL max_k a_left, k_meter, 1
 k_rmsL rms a_left
 chnset k_peakL / 1.0, "__vcs_mixer_meter_9cea1be1f8255375a6cf7b93_peakL"
 chnset k_rmsL / 1.0, "__vcs_mixer_meter_9cea1be1f8255375a6cf7b93_rmsL"
 k_peakR max_k a_right, k_meter, 1
 k_rmsR rms a_right
 chnset k_peakR / 1.0, "__vcs_mixer_meter_9cea1be1f8255375a6cf7b93_peakR"
 chnset k_rmsR / 1.0, "__vcs_mixer_meter_9cea1be1f8255375a6cf7b93_rmsR"
endin

</CsInstruments>
<CsScore>
f 1 0 16384 10 1
i 2 0 4.017857 52 37
i 2 0 4.017857 55 37
i 2 0 4.017857 59 37
i 2 0 4.017857 62 37
i 9 0 4.017857 52 28
i 9 4.285714 4.017857 52 20
i 2 8.571429 4.017857 52 32
i 2 8.571429 4.017857 54 32
i 2 8.571429 4.017857 59 32
i 3 8.571429 0.133929 42 42
i 3 9.107143 0.133929 42 42
i 3 9.642857 0.133929 42 42
i 8 9.642857 1.071429 64 54
i 3 10.178571 0.133929 42 42
i 3 10.714286 0.133929 42 42
i 3 11.25 0.133929 42 42
i 3 11.785714 0.133929 42 42
i 8 11.785714 0.803571 71 48
i 3 12.321429 0.133929 42 42
i 3 12.857143 0.133929 42 42
i 9 12.857143 4.017857 52 28
i 3 13.392857 0.133929 42 42
i 3 13.928571 0.133929 42 42
i 3 14.464286 0.133929 42 42
i 3 15 0.133929 42 42
i 3 15.535714 0.133929 42 42
i 3 16.071429 0.133929 42 42
i 3 16.607143 0.133929 42 42
i 2 17.142857 4.017857 52 51
i 2 17.142857 4.017857 55 51
i 2 17.142857 4.017857 59 51
i 3 17.142857 0.133929 36 85
i 1 17.410714 0.267857 40 62
i 3 17.410714 0.133929 42 60
i 3 17.946429 0.133929 42 60
i 1 18.482143 0.267857 40 62
i 3 18.482143 0.133929 42 60
i 3 18.75 0.133929 38 77
i 3 19.017857 0.133929 42 60
i 3 19.285714 0.133929 36 88
i 1 19.553571 0.267857 40 62
i 3 19.553571 0.133929 42 60
i 3 20.089286 0.133929 42 60
i 1 20.625 0.267857 40 62
i 3 20.625 0.133929 42 60
i 3 20.892857 0.133929 38 81
i 3 21.160714 0.133929 42 60
i 3 21.428571 0.133929 36 85
i 1 21.696429 0.267857 40 62
i 3 21.696429 0.133929 42 60
i 3 22.232143 0.133929 42 60
i 1 22.767857 0.267857 40 62
i 3 22.767857 0.133929 42 60
i 3 23.035714 0.133929 38 77
i 3 23.303571 0.133929 42 60
i 3 23.571429 0.133929 36 88
i 1 23.839286 0.267857 40 62
i 3 23.839286 0.133929 42 60
i 3 24.375 0.133929 42 60
i 1 24.910714 0.267857 40 62
i 3 24.910714 0.133929 42 60
i 3 25.178571 0.133929 38 81
i 3 25.446429 0.133929 42 60
i 2 25.714286 4.017857 47 49
i 2 25.714286 4.017857 52 49
i 2 25.714286 4.017857 54 49
i 3 25.714286 0.133929 36 108
i 3 25.714286 0.133929 42 59
i 1 25.982143 0.133929 40 99
i 3 25.982143 0.133929 42 72
i 1 26.116071 0.133929 40 77
i 3 26.25 0.133929 38 102
i 3 26.25 0.133929 42 59
i 8 26.25 1.071429 67 54
i 1 26.517857 0.133929 40 82
i 3 26.517857 0.133929 42 72
i 3 26.785714 0.133929 36 99
i 3 26.785714 0.133929 42 59
i 1 27.053571 0.133929 40 99
i 3 27.053571 0.133929 42 72
i 1 27.1875 0.133929 40 85
i 3 27.321429 0.133929 38 105
i 3 27.321429 0.133929 42 59
i 1 27.589286 0.133929 52 74
i 3 27.589286 0.133929 46 52
i 3 27.857143 0.133929 36 106
i 3 27.857143 0.133929 42 59
i 8 27.857143 0.535714 66 49
i 1 28.125 0.133929 40 99
i 3 28.125 0.133929 42 72
i 1 28.258929 0.133929 40 77
i 3 28.392857 0.133929 38 101
i 3 28.392857 0.133929 42 59
i 1 28.660714 0.133929 40 82
i 3 28.660714 0.133929 42 72
i 3 28.928571 0.133929 36 101
i 3 28.928571 0.133929 42 59
i 8 28.928571 0.803571 64 46
i 1 29.196429 0.133929 40 99
i 3 29.196429 0.133929 42 72
i 1 29.330357 0.133929 40 85
i 3 29.464286 0.133929 38 108
i 3 29.464286 0.133929 42 59
i 1 29.732143 0.133929 52 74
i 3 29.732143 0.133929 46 57
i 3 30 0.133929 36 108
i 3 30 0.133929 42 59
i 5 30 0.133929 52 44
i 9 30 4.017857 59 34
i 1 30.267857 0.133929 40 99
i 3 30.267857 0.133929 42 72
i 1 30.401786 0.133929 40 77
i 3 30.535714 0.133929 38 102
i 3 30.535714 0.133929 42 59
i 1 30.803571 0.133929 40 82
i 3 30.803571 0.133929 42 72
i 3 31.071429 0.133929 36 99
i 3 31.071429 0.133929 42 59
i 1 31.339286 0.133929 40 99
i 3 31.339286 0.133929 42 72
i 1 31.473214 0.133929 40 85
i 3 31.607143 0.133929 38 105
i 3 31.607143 0.133929 42 59
i 1 31.875 0.133929 52 74
i 3 31.875 0.133929 46 52
i 3 32.142857 0.133929 36 106
i 3 32.142857 0.133929 42 59
i 1 32.410714 0.133929 40 99
i 3 32.410714 0.133929 42 72
i 1 32.544643 0.133929 40 77
i 3 32.678571 0.133929 38 101
i 3 32.678571 0.133929 42 59
i 1 32.946429 0.133929 40 82
i 3 32.946429 0.133929 42 72
i 3 33.214286 0.133929 36 101
i 3 33.214286 0.133929 42 59
i 1 33.482143 0.133929 40 99
i 3 33.482143 0.133929 38 65
i 3 33.482143 0.133929 42 72
i 1 33.616071 0.133929 40 85
i 3 33.75 0.133929 38 108
i 3 33.75 0.133929 42 59
i 1 34.017857 0.133929 52 74
i 3 34.017857 0.133929 38 80
i 3 34.017857 0.133929 46 57
i 3 34.151786 0.133929 38 49
i 2 34.285714 4.017857 52 51
i 2 34.285714 4.017857 55 51
i 2 34.285714 4.017857 59 51
i 3 34.285714 0.133929 36 108
i 3 34.285714 0.133929 42 59
i 1 34.553571 0.133929 40 99
i 3 34.553571 0.133929 42 72
i 8 34.553571 0.267857 64 86
i 1 34.6875 0.133929 40 77
i 3 34.821429 0.133929 38 102
i 3 34.821429 0.133929 42 59
i 1 35.089286 0.133929 40 82
i 3 35.089286 0.133929 42 72
i 3 35.357143 0.133929 36 99
i 3 35.357143 0.133929 42 59
i 8 35.357143 0.401786 67 76
i 1 35.625 0.133929 40 99
i 3 35.625 0.133929 42 72
i 1 35.758929 0.133929 40 85
i 5 35.758929 0.133929 52 60
i 3 35.892857 0.133929 38 105
i 3 35.892857 0.133929 42 59
i 1 36.160714 0.133929 52 74
i 3 36.160714 0.133929 46 52
i 8 36.160714 0.267857 66 81
i 3 36.428571 0.133929 36 106
i 3 36.428571 0.133929 42 59
i 1 36.696429 0.133929 40 99
i 3 36.696429 0.133929 42 72
i 1 36.830357 0.133929 40 77
i 3 36.964286 0.133929 38 101
i 3 36.964286 0.133929 42 59
i 8 36.964286 1.071429 71 84
i 1 37.232143 0.133929 40 82
i 3 37.232143 0.133929 42 72
i 3 37.5 0.133929 36 101
i 3 37.5 0.133929 42 59
i 1 37.767857 0.133929 40 99
i 3 37.767857 0.133929 42 72
i 1 37.901786 0.133929 40 85
i 5 37.901786 0.133929 52 51
i 3 38.035714 0.133929 38 108
i 3 38.035714 0.133929 42 59
i 1 38.303571 0.133929 52 74
i 3 38.303571 0.133929 46 57
i 2 38.571429 4.017857 48 47
i 2 38.571429 4.017857 52 47
i 2 38.571429 4.017857 55 47
i 3 38.571429 0.133929 36 108
i 3 38.571429 0.133929 42 59
i 1 38.839286 0.133929 36 99
i 3 38.839286 0.133929 42 72
i 8 38.839286 0.535714 67 79
i 1 38.973214 0.133929 36 77
i 3 39.107143 0.133929 38 102
i 3 39.107143 0.133929 42 59
i 1 39.375 0.133929 36 82
i 3 39.375 0.133929 42 72
i 3 39.642857 0.133929 36 99
i 3 39.642857 0.133929 42 59
i 8 39.642857 0.535714 71 83
i 1 39.910714 0.133929 36 99
i 3 39.910714 0.133929 42 72
i 1 40.044643 0.133929 36 85
i 3 40.178571 0.133929 38 105
i 3 40.178571 0.133929 42 59
i 1 40.446429 0.133929 48 74
i 3 40.446429 0.133929 46 52
i 3 40.714286 0.133929 36 106
i 3 40.714286 0.133929 42 59
i 8 40.714286 0.401786 69 78
i 1 40.982143 0.133929 36 99
i 3 40.982143 0.133929 42 72
i 1 41.116071 0.133929 36 77
i 3 41.25 0.133929 38 101
i 3 41.25 0.133929 42 59
i 1 41.517857 0.133929 36 82
i 3 41.517857 0.133929 42 72
i 3 41.785714 0.133929 36 101
i 3 41.785714 0.133929 42 59
i 8 41.785714 0.803571 67 72
i 1 42.053571 0.133929 36 99
i 3 42.053571 0.133929 42 72
i 1 42.1875 0.133929 36 85
i 3 42.321429 0.133929 38 108
i 3 42.321429 0.133929 42 59
i 1 42.589286 0.133929 48 74
i 3 42.589286 0.133929 46 57
i 2 42.857143 4.017857 45 49
i 2 42.857143 4.017857 48 49
i 2 42.857143 4.017857 52 49
i 3 42.857143 0.133929 36 108
i 3 42.857143 0.133929 42 59
i 1 43.125 0.133929 33 99
i 3 43.125 0.133929 42 72
i 8 43.125 0.535714 64 77
i 1 43.258929 0.133929 33 77
i 3 43.392857 0.133929 38 102
i 3 43.392857 0.133929 42 59
i 1 43.660714 0.133929 33 82
i 3 43.660714 0.133929 42 72
i 3 43.928571 0.133929 36 99
i 3 43.928571 0.133929 42 59
i 8 43.928571 0.535714 69 82
i 1 44.196429 0.133929 33 99
i 3 44.196429 0.133929 42 72
i 1 44.330357 0.133929 33 85
i 3 44.464286 0.133929 38 105
i 3 44.464286 0.133929 42 59
i 1 44.732143 0.133929 45 74
i 3 44.732143 0.133929 46 52
i 3 45 0.133929 36 106
i 3 45 0.133929 42 59
i 8 45 0.401786 67 75
i 1 45.267857 0.133929 33 99
i 3 45.267857 0.133929 42 72
i 1 45.401786 0.133929 33 77
i 3 45.535714 0.133929 38 101
i 3 45.535714 0.133929 42 59
i 1 45.803571 0.133929 33 82
i 3 45.803571 0.133929 42 72
i 3 46.071429 0.133929 36 101
i 3 46.071429 0.133929 42 59
i 8 46.071429 0.803571 64 72
i 1 46.339286 0.133929 33 99
i 3 46.339286 0.133929 42 72
i 1 46.473214 0.133929 33 85
i 3 46.607143 0.133929 38 108
i 3 46.607143 0.133929 42 59
i 1 46.875 0.133929 45 74
i 3 46.875 0.133929 46 57
i 2 47.142857 4.017857 47 49
i 2 47.142857 4.017857 52 49
i 2 47.142857 4.017857 54 49
i 3 47.142857 0.133929 36 108
i 3 47.142857 0.133929 42 59
i 8 47.142857 0.535714 66 82
i 1 47.410714 0.133929 35 99
i 3 47.410714 0.133929 42 72
i 1 47.544643 0.133929 35 77
i 3 47.678571 0.133929 38 102
i 3 47.678571 0.133929 42 59
i 1 47.946429 0.133929 35 82
i 3 47.946429 0.133929 42 72
i 5 48.080357 0.133929 47 77
i 3 48.214286 0.133929 36 99
i 3 48.214286 0.133929 42 59
i 8 48.214286 0.401786 64 76
i 1 48.482143 0.133929 35 99
i 3 48.482143 0.133929 42 72
i 1 48.616071 0.133929 35 85
i 3 48.75 0.133929 38 105
i 3 48.75 0.133929 42 59
i 1 49.017857 0.133929 47 74
i 3 49.017857 0.133929 46 52
i 8 49.017857 0.535714 59 78
i 3 49.285714 0.133929 36 106
i 3 49.285714 0.133929 42 59
i 1 49.553571 0.133929 35 99
i 3 49.553571 0.133929 42 72
i 5 49.553571 0.133929 47 68
i 1 49.6875 0.133929 35 77
i 3 49.821429 0.133929 38 101
i 3 49.821429 0.133929 42 59
i 1 50.089286 0.133929 35 82
i 3 50.089286 0.133929 42 72
i 8 50.089286 1.071429 66 83
i 3 50.357143 0.133929 36 101
i 3 50.357143 0.133929 42 59
i 1 50.625 0.133929 35 99
i 3 50.625 0.133929 38 65
i 3 50.625 0.133929 42 72
i 1 50.758929 0.133929 35 85
i 5 50.758929 0.133929 47 59
i 3 50.892857 0.133929 38 108
i 3 50.892857 0.133929 42 59
i 1 51.160714 0.133929 47 74
i 3 51.160714 0.133929 38 80
i 3 51.160714 0.133929 46 57
i 3 51.294643 0.133929 38 49
i 2 51.428571 4.017857 52 51
i 2 51.428571 4.017857 55 51
i 2 51.428571 4.017857 59 51
i 3 51.428571 0.133929 36 108
i 3 51.428571 0.133929 42 59
i 8 51.428571 0.535714 69 82
i 1 51.696429 0.133929 40 99
i 3 51.696429 0.133929 42 72
i 1 51.830357 0.133929 40 77
i 3 51.964286 0.133929 38 102
i 3 51.964286 0.133929 42 59
i 1 52.232143 0.133929 40 82
i 3 52.232143 0.133929 42 72
i 8 52.232143 0.535714 67 78
i 5 52.366071 0.133929 52 78
i 3 52.5 0.133929 36 99
i 3 52.5 0.133929 42 59
i 1 52.767857 0.133929 40 99
i 3 52.767857 0.133929 42 72
i 1 52.901786 0.133929 40 85
i 3 53.035714 0.133929 38 105
i 3 53.035714 0.133929 42 59
i 8 53.035714 0.401786 66 85
i 1 53.303571 0.133929 52 74
i 3 53.303571 0.133929 46 52
i 3 53.571429 0.133929 36 106
i 3 53.571429 0.133929 42 59
i 1 53.839286 0.133929 40 99
i 3 53.839286 0.133929 42 72
i 5 53.839286 0.133929 52 69
i 1 53.973214 0.133929 40 77
i 3 54.107143 0.133929 38 101
i 3 54.107143 0.133929 42 59
i 1 54.375 0.133929 40 82
i 3 54.375 0.133929 42 72
i 8 54.375 0.803571 64 75
i 3 54.642857 0.133929 36 101
i 3 54.642857 0.133929 42 59
i 1 54.910714 0.133929 40 99
i 3 54.910714 0.133929 42 72
i 1 55.044643 0.133929 40 85
i 5 55.044643 0.133929 52 60
i 3 55.178571 0.133929 38 108
i 3 55.178571 0.133929 42 59
i 1 55.446429 0.133929 52 74
i 3 55.446429 0.133929 46 57
i 2 55.714286 4.017857 48 47
i 2 55.714286 4.017857 52 47
i 2 55.714286 4.017857 55 47
i 3 55.714286 0.133929 36 108
i 3 55.714286 0.133929 42 59
i 1 55.982143 0.133929 36 99
i 3 55.982143 0.133929 42 72
i 1 56.116071 0.133929 36 77
i 3 56.25 0.133929 38 102
i 3 56.25 0.133929 42 59
i 1 56.517857 0.133929 36 82
i 3 56.517857 0.133929 42 72
i 5 56.651786 0.133929 48 76
i 3 56.785714 0.133929 36 99
i 3 56.785714 0.133929 42 59
i 1 57.053571 0.133929 36 99
i 3 57.053571 0.133929 42 72
i 1 57.1875 0.133929 36 85
i 3 57.321429 0.133929 38 105
i 3 57.321429 0.133929 42 59
i 1 57.589286 0.133929 48 74
i 3 57.589286 0.133929 46 52
i 3 57.857143 0.133929 36 106
i 3 57.857143 0.133929 42 59
i 1 58.125 0.133929 36 99
i 3 58.125 0.133929 42 72
i 5 58.125 0.133929 48 67
i 1 58.258929 0.133929 36 77
i 3 58.392857 0.133929 38 101
i 3 58.392857 0.133929 42 59
i 1 58.660714 0.133929 36 82
i 3 58.660714 0.133929 42 72
i 3 58.928571 0.133929 36 101
i 3 58.928571 0.133929 42 59
i 1 59.196429 0.133929 36 99
i 3 59.196429 0.133929 42 72
i 1 59.330357 0.133929 36 85
i 5 59.330357 0.133929 48 58
i 3 59.464286 0.133929 38 108
i 3 59.464286 0.133929 42 59
i 1 59.732143 0.133929 48 74
i 3 59.732143 0.133929 46 57
i 2 60 4.017857 45 49
i 2 60 4.017857 48 49
i 2 60 4.017857 52 49
i 3 60 0.133929 36 108
i 3 60 0.133929 42 59
i 1 60.267857 0.133929 33 99
i 3 60.267857 0.133929 42 72
i 8 60.267857 0.535714 64 77
i 1 60.401786 0.133929 33 77
i 3 60.535714 0.133929 38 102
i 3 60.535714 0.133929 42 59
i 1 60.803571 0.133929 33 82
i 3 60.803571 0.133929 42 72
i 3 60.9375 0.133929 42 40
i 5 60.9375 0.133929 45 78
i 3 61.071429 0.133929 36 99
i 3 61.071429 0.133929 42 59
i 8 61.071429 0.535714 69 82
i 1 61.339286 0.133929 33 99
i 3 61.339286 0.133929 42 72
i 1 61.473214 0.133929 33 85
i 3 61.607143 0.133929 38 105
i 3 61.607143 0.133929 42 59
i 1 61.875 0.133929 45 74
i 3 61.875 0.133929 46 52
i 3 62.008929 0.133929 42 43
i 3 62.142857 0.133929 36 106
i 3 62.142857 0.133929 42 59
i 8 62.142857 0.401786 67 75
i 1 62.410714 0.133929 33 99
i 3 62.410714 0.133929 42 72
i 5 62.410714 0.133929 45 69
i 1 62.544643 0.133929 33 77
i 3 62.544643 0.133929 38 43
i 3 62.678571 0.133929 38 101
i 3 62.678571 0.133929 42 59
i 1 62.946429 0.133929 33 82
i 3 62.946429 0.133929 42 72
i 3 63.080357 0.133929 36 69
i 3 63.214286 0.133929 36 101
i 3 63.214286 0.133929 42 59
i 8 63.214286 0.803571 64 72
i 1 63.482143 0.133929 33 99
i 3 63.482143 0.133929 42 72
i 1 63.616071 0.133929 33 85
i 3 63.616071 0.133929 42 44
i 5 63.616071 0.133929 45 60
i 3 63.75 0.133929 38 108
i 3 63.75 0.133929 42 59
i 1 64.017857 0.133929 45 74
i 3 64.017857 0.133929 46 57
i 3 64.151786 0.133929 42 40
i 2 64.285714 4.017857 47 49
i 2 64.285714 4.017857 52 49
i 2 64.285714 4.017857 54 49
i 3 64.285714 0.133929 36 108
i 3 64.285714 0.133929 42 59
i 8 64.285714 0.535714 66 82
i 1 64.553571 0.133929 35 99
i 3 64.553571 0.133929 42 72
i 1 64.6875 0.133929 35 77
i 3 64.821429 0.133929 38 102
i 3 64.821429 0.133929 42 59
i 1 65.089286 0.133929 35 82
i 3 65.089286 0.133929 42 72
i 5 65.223214 0.133929 52 85
i 3 65.357143 0.133929 36 99
i 3 65.357143 0.133929 42 59
i 8 65.357143 0.401786 64 76
i 1 65.625 0.133929 35 99
i 3 65.625 0.133929 42 72
i 1 65.758929 0.133929 35 85
i 3 65.892857 0.133929 38 105
i 3 65.892857 0.133929 42 59
i 1 66.160714 0.133929 47 74
i 3 66.160714 0.133929 46 52
i 8 66.160714 0.535714 59 78
i 3 66.428571 0.133929 36 106
i 3 66.428571 0.133929 42 59
i 9 66.428571 1.875 64 38
i 1 66.696429 0.133929 35 99
i 3 66.696429 0.133929 42 72
i 1 66.830357 0.133929 35 77
i 3 66.964286 0.133929 38 101
i 3 66.964286 0.133929 42 59
i 1 67.232143 0.133929 35 82
i 3 67.232143 0.133929 42 72
i 8 67.232143 1.071429 66 83
i 5 67.366071 0.133929 52 76
i 3 67.5 0.133929 36 101
i 3 67.5 0.133929 42 59
i 1 67.767857 0.133929 35 99
i 3 67.767857 0.133929 38 65
i 3 67.767857 0.133929 42 72
i 5 67.767857 0.133929 52 67
i 1 67.901786 0.133929 35 85
i 3 68.035714 0.133929 38 108
i 3 68.035714 0.133929 42 59
i 1 68.303571 0.133929 47 74
i 3 68.303571 0.133929 38 80
i 3 68.303571 0.133929 46 57
i 5 68.303571 0.133929 52 85
i 3 68.4375 0.133929 38 49
i 2 68.571429 4.017857 52 51
i 2 68.571429 4.017857 55 51
i 2 68.571429 4.017857 59 51
i 3 68.571429 0.133929 36 108
i 3 68.571429 0.133929 42 59
i 1 68.839286 0.133929 40 99
i 3 68.839286 0.133929 42 72
i 8 68.839286 0.267857 64 86
i 1 68.973214 0.133929 40 77
i 3 69.107143 0.133929 38 102
i 3 69.107143 0.133929 42 59
i 1 69.375 0.133929 40 82
i 3 69.375 0.133929 42 72
i 3 69.642857 0.133929 36 99
i 3 69.642857 0.133929 42 59
i 8 69.642857 0.401786 67 76
i 1 69.910714 0.133929 40 99
i 3 69.910714 0.133929 42 72
i 1 70.044643 0.133929 40 85
i 5 70.044643 0.133929 52 60
i 3 70.178571 0.133929 38 105
i 3 70.178571 0.133929 42 59
i 1 70.446429 0.133929 52 74
i 3 70.446429 0.133929 46 52
i 8 70.446429 0.267857 66 81
i 3 70.714286 0.133929 36 106
i 3 70.714286 0.133929 42 59
i 1 70.982143 0.133929 40 99
i 3 70.982143 0.133929 42 72
i 1 71.116071 0.133929 40 77
i 3 71.25 0.133929 38 101
i 3 71.25 0.133929 42 59
i 8 71.25 1.071429 71 84
i 1 71.517857 0.133929 40 82
i 3 71.517857 0.133929 42 72
i 3 71.785714 0.133929 36 101
i 3 71.785714 0.133929 42 59
i 1 72.053571 0.133929 40 99
i 3 72.053571 0.133929 42 72
i 1 72.1875 0.133929 40 85
i 5 72.1875 0.133929 52 51
i 3 72.321429 0.133929 38 108
i 3 72.321429 0.133929 42 59
i 1 72.589286 0.133929 52 74
i 3 72.589286 0.133929 46 57
i 2 72.857143 4.017857 48 47
i 2 72.857143 4.017857 52 47
i 2 72.857143 4.017857 55 47
i 3 72.857143 0.133929 36 108
i 3 72.857143 0.133929 42 59
i 1 73.125 0.133929 36 99
i 3 73.125 0.133929 42 72
i 8 73.125 0.535714 67 79
i 1 73.258929 0.133929 36 77
i 3 73.392857 0.133929 38 102
i 3 73.392857 0.133929 42 59
i 1 73.660714 0.133929 36 82
i 3 73.660714 0.133929 42 72
i 3 73.928571 0.133929 36 99
i 3 73.928571 0.133929 42 59
i 8 73.928571 0.535714 71 83
i 1 74.196429 0.133929 36 99
i 3 74.196429 0.133929 42 72
i 1 74.330357 0.133929 36 85
i 3 74.464286 0.133929 38 105
i 3 74.464286 0.133929 42 59
i 1 74.732143 0.133929 48 74
i 3 74.732143 0.133929 46 52
i 3 75 0.133929 36 106
i 3 75 0.133929 42 59
i 8 75 0.401786 69 78
i 1 75.267857 0.133929 36 99
i 3 75.267857 0.133929 42 72
i 1 75.401786 0.133929 36 77
i 3 75.535714 0.133929 38 101
i 3 75.535714 0.133929 42 59
i 1 75.803571 0.133929 36 82
i 3 75.803571 0.133929 42 72
i 3 76.071429 0.133929 36 101
i 3 76.071429 0.133929 42 59
i 8 76.071429 0.803571 67 72
i 1 76.339286 0.133929 36 99
i 3 76.339286 0.133929 42 72
i 1 76.473214 0.133929 36 85
i 3 76.607143 0.133929 38 108
i 3 76.607143 0.133929 42 59
i 1 76.875 0.133929 48 74
i 3 76.875 0.133929 46 57
i 2 77.142857 4.017857 45 49
i 2 77.142857 4.017857 48 49
i 2 77.142857 4.017857 52 49
i 3 77.142857 0.133929 36 108
i 3 77.142857 0.133929 42 59
i 1 77.410714 0.133929 33 99
i 3 77.410714 0.133929 42 72
i 8 77.410714 0.535714 64 77
i 1 77.544643 0.133929 33 77
i 3 77.678571 0.133929 38 102
i 3 77.678571 0.133929 42 59
i 1 77.946429 0.133929 33 82
i 3 77.946429 0.133929 42 72
i 3 78.214286 0.133929 36 99
i 3 78.214286 0.133929 42 59
i 8 78.214286 0.535714 69 82
i 1 78.482143 0.133929 33 99
i 3 78.482143 0.133929 42 72
i 1 78.616071 0.133929 33 85
i 3 78.75 0.133929 38 105
i 3 78.75 0.133929 42 59
i 1 79.017857 0.133929 45 74
i 3 79.017857 0.133929 46 52
i 3 79.285714 0.133929 36 106
i 3 79.285714 0.133929 42 59
i 8 79.285714 0.401786 67 75
i 1 79.553571 0.133929 33 99
i 3 79.553571 0.133929 42 72
i 1 79.6875 0.133929 33 77
i 3 79.821429 0.133929 38 101
i 3 79.821429 0.133929 42 59
i 1 80.089286 0.133929 33 82
i 3 80.089286 0.133929 42 72
i 3 80.357143 0.133929 36 101
i 3 80.357143 0.133929 42 59
i 8 80.357143 0.803571 64 72
i 1 80.625 0.133929 33 99
i 3 80.625 0.133929 42 72
i 1 80.758929 0.133929 33 85
i 3 80.892857 0.133929 38 108
i 3 80.892857 0.133929 42 59
i 1 81.160714 0.133929 45 74
i 3 81.160714 0.133929 46 57
i 2 81.428571 4.017857 47 49
i 2 81.428571 4.017857 52 49
i 2 81.428571 4.017857 54 49
i 3 81.428571 0.133929 36 108
i 3 81.428571 0.133929 42 59
i 8 81.428571 0.535714 66 82
i 1 81.696429 0.133929 35 99
i 3 81.696429 0.133929 42 72
i 1 81.830357 0.133929 35 77
i 3 81.964286 0.133929 38 102
i 3 81.964286 0.133929 42 59
i 1 82.232143 0.133929 35 82
i 3 82.232143 0.133929 42 72
i 5 82.366071 0.133929 47 77
i 3 82.5 0.133929 36 99
i 3 82.5 0.133929 42 59
i 8 82.5 0.401786 64 76
i 1 82.767857 0.133929 35 99
i 3 82.767857 0.133929 42 72
i 1 82.901786 0.133929 35 85
i 3 83.035714 0.133929 38 105
i 3 83.035714 0.133929 42 59
i 1 83.303571 0.133929 47 74
i 3 83.303571 0.133929 46 52
i 8 83.303571 0.535714 59 78
i 3 83.571429 0.133929 36 106
i 3 83.571429 0.133929 42 59
i 1 83.839286 0.133929 35 99
i 3 83.839286 0.133929 42 72
i 5 83.839286 0.133929 47 68
i 1 83.973214 0.133929 35 77
i 3 84.107143 0.133929 38 101
i 3 84.107143 0.133929 42 59
i 1 84.375 0.133929 35 82
i 3 84.375 0.133929 42 72
i 8 84.375 1.071429 66 83
i 3 84.642857 0.133929 36 101
i 3 84.642857 0.133929 42 59
i 1 84.910714 0.133929 35 99
i 3 84.910714 0.133929 38 65
i 3 84.910714 0.133929 42 72
i 1 85.044643 0.133929 35 85
i 5 85.044643 0.133929 47 59
i 3 85.178571 0.133929 38 108
i 3 85.178571 0.133929 42 59
i 1 85.446429 0.133929 47 74
i 3 85.446429 0.133929 38 80
i 3 85.446429 0.133929 46 57
i 3 85.580357 0.133929 38 49
i 2 85.714286 4.017857 52 51
i 2 85.714286 4.017857 55 51
i 2 85.714286 4.017857 59 51
i 3 85.714286 0.133929 36 108
i 3 85.714286 0.133929 42 59
i 8 85.714286 0.535714 69 82
i 1 85.982143 0.133929 40 99
i 3 85.982143 0.133929 42 72
i 1 86.116071 0.133929 40 77
i 3 86.25 0.133929 38 102
i 3 86.25 0.133929 42 59
i 1 86.517857 0.133929 40 82
i 3 86.517857 0.133929 42 72
i 8 86.517857 0.535714 67 78
i 5 86.651786 0.133929 52 78
i 3 86.785714 0.133929 36 99
i 3 86.785714 0.133929 42 59
i 1 87.053571 0.133929 40 99
i 3 87.053571 0.133929 42 72
i 1 87.1875 0.133929 40 85
i 3 87.321429 0.133929 38 105
i 3 87.321429 0.133929 42 59
i 8 87.321429 0.401786 66 85
i 1 87.589286 0.133929 52 74
i 3 87.589286 0.133929 46 52
i 3 87.857143 0.133929 36 106
i 3 87.857143 0.133929 42 59
i 1 88.125 0.133929 40 99
i 3 88.125 0.133929 42 72
i 5 88.125 0.133929 52 69
i 1 88.258929 0.133929 40 77
i 3 88.392857 0.133929 38 101
i 3 88.392857 0.133929 42 59
i 1 88.660714 0.133929 40 82
i 3 88.660714 0.133929 42 72
i 8 88.660714 0.803571 64 75
i 3 88.928571 0.133929 36 101
i 3 88.928571 0.133929 42 59
i 1 89.196429 0.133929 40 99
i 3 89.196429 0.133929 42 72
i 1 89.330357 0.133929 40 85
i 5 89.330357 0.133929 52 60
i 3 89.464286 0.133929 38 108
i 3 89.464286 0.133929 42 59
i 1 89.732143 0.133929 52 74
i 3 89.732143 0.133929 46 57
i 2 90 4.017857 48 47
i 2 90 4.017857 52 47
i 2 90 4.017857 55 47
i 3 90 0.133929 36 108
i 3 90 0.133929 42 59
i 1 90.267857 0.133929 36 99
i 3 90.267857 0.133929 42 72
i 8 90.267857 0.535714 67 79
i 1 90.401786 0.133929 36 77
i 3 90.535714 0.133929 38 102
i 3 90.535714 0.133929 42 59
i 1 90.803571 0.133929 36 82
i 3 90.803571 0.133929 42 72
i 5 90.9375 0.133929 48 76
i 3 91.071429 0.133929 36 99
i 3 91.071429 0.133929 42 59
i 8 91.071429 0.535714 71 83
i 1 91.339286 0.133929 36 99
i 3 91.339286 0.133929 42 72
i 1 91.473214 0.133929 36 85
i 3 91.607143 0.133929 38 105
i 3 91.607143 0.133929 42 59
i 1 91.875 0.133929 48 74
i 3 91.875 0.133929 46 52
i 3 92.142857 0.133929 36 106
i 3 92.142857 0.133929 42 59
i 8 92.142857 0.401786 69 78
i 1 92.410714 0.133929 36 99
i 3 92.410714 0.133929 42 72
i 5 92.410714 0.133929 48 67
i 1 92.544643 0.133929 36 77
i 3 92.678571 0.133929 38 101
i 3 92.678571 0.133929 42 59
i 1 92.946429 0.133929 36 82
i 3 92.946429 0.133929 42 72
i 3 93.214286 0.133929 36 101
i 3 93.214286 0.133929 42 59
i 8 93.214286 0.803571 67 72
i 1 93.482143 0.133929 36 99
i 3 93.482143 0.133929 42 72
i 1 93.616071 0.133929 36 85
i 5 93.616071 0.133929 48 58
i 3 93.75 0.133929 38 108
i 3 93.75 0.133929 42 59
i 1 94.017857 0.133929 48 74
i 3 94.017857 0.133929 46 57
i 2 94.285714 4.017857 45 49
i 2 94.285714 4.017857 48 49
i 2 94.285714 4.017857 52 49
i 3 94.285714 0.133929 36 108
i 3 94.285714 0.133929 42 59
i 1 94.553571 0.133929 33 99
i 3 94.553571 0.133929 42 72
i 1 94.6875 0.133929 33 77
i 3 94.821429 0.133929 38 102
i 3 94.821429 0.133929 42 59
i 1 95.089286 0.133929 33 82
i 3 95.089286 0.133929 42 72
i 3 95.223214 0.133929 42 40
i 5 95.223214 0.133929 45 78
i 3 95.357143 0.133929 36 99
i 3 95.357143 0.133929 42 59
i 1 95.625 0.133929 33 99
i 3 95.625 0.133929 42 72
i 1 95.758929 0.133929 33 85
i 3 95.892857 0.133929 38 105
i 3 95.892857 0.133929 42 59
i 1 96.160714 0.133929 45 74
i 3 96.160714 0.133929 46 52
i 3 96.294643 0.133929 42 43
i 3 96.428571 0.133929 36 106
i 3 96.428571 0.133929 42 59
i 1 96.696429 0.133929 33 99
i 3 96.696429 0.133929 42 72
i 5 96.696429 0.133929 45 69
i 1 96.830357 0.133929 33 77
i 3 96.830357 0.133929 38 43
i 3 96.964286 0.133929 38 101
i 3 96.964286 0.133929 42 59
i 1 97.232143 0.133929 33 82
i 3 97.232143 0.133929 42 72
i 3 97.366071 0.133929 36 69
i 3 97.5 0.133929 36 101
i 3 97.5 0.133929 42 59
i 1 97.767857 0.133929 33 99
i 3 97.767857 0.133929 42 72
i 1 97.901786 0.133929 33 85
i 3 97.901786 0.133929 42 44
i 5 97.901786 0.133929 45 60
i 3 98.035714 0.133929 38 108
i 3 98.035714 0.133929 42 59
i 1 98.303571 0.133929 45 74
i 3 98.303571 0.133929 46 57
i 3 98.4375 0.133929 42 40
i 2 98.571429 4.017857 47 49
i 2 98.571429 4.017857 52 49
i 2 98.571429 4.017857 54 49
i 3 98.571429 0.133929 36 108
i 3 98.571429 0.133929 42 59
i 8 98.571429 0.535714 66 82
i 9 98.571429 4.017857 59 34
i 1 98.839286 0.133929 35 99
i 3 98.839286 0.133929 42 72
i 1 98.973214 0.133929 35 77
i 3 99.107143 0.133929 38 102
i 3 99.107143 0.133929 42 59
i 1 99.375 0.133929 35 82
i 3 99.375 0.133929 42 72
i 5 99.508929 0.133929 52 85
i 3 99.642857 0.133929 36 99
i 3 99.642857 0.133929 42 59
i 8 99.642857 0.401786 64 76
i 1 99.910714 0.133929 35 99
i 3 99.910714 0.133929 42 72
i 1 100.044643 0.133929 35 85
i 3 100.178571 0.133929 38 105
i 3 100.178571 0.133929 42 59
i 1 100.446429 0.133929 47 74
i 3 100.446429 0.133929 46 52
i 8 100.446429 0.535714 59 78
i 3 100.714286 0.133929 36 106
i 3 100.714286 0.133929 42 59
i 1 100.982143 0.133929 35 99
i 3 100.982143 0.133929 42 72
i 1 101.116071 0.133929 35 77
i 3 101.25 0.133929 38 101
i 3 101.25 0.133929 42 59
i 1 101.517857 0.133929 35 82
i 3 101.517857 0.133929 42 72
i 8 101.517857 1.071429 66 83
i 5 101.651786 0.133929 52 76
i 3 101.785714 0.133929 36 101
i 3 101.785714 0.133929 42 59
i 1 102.053571 0.133929 35 99
i 3 102.053571 0.133929 38 65
i 3 102.053571 0.133929 42 72
i 5 102.053571 0.133929 52 67
i 1 102.1875 0.133929 35 85
i 3 102.321429 0.133929 38 108
i 3 102.321429 0.133929 42 59
i 1 102.589286 0.133929 47 74
i 3 102.589286 0.133929 38 80
i 3 102.589286 0.133929 46 57
i 5 102.589286 0.133929 52 85
i 3 102.723214 0.133929 38 49
i 3 102.857143 0.133929 35 83
i 6 102.857143 4.017857 48 71
i 6 102.857143 4.017857 52 71
i 6 102.857143 4.017857 55 71
i 6 102.857143 4.017857 59 71
i 1 103.125 0.267857 36 62
i 3 103.392857 0.133929 42 34
i 4 103.660714 1.071429 76 53
i 7 103.928571 0.803571 64 70
i 1 104.196429 0.267857 36 62
i 3 104.464286 0.133929 38 54
i 3 104.464286 0.133929 42 34
i 3 105 0.133929 35 77
i 1 105.267857 0.267857 36 62
i 3 105.535714 0.133929 42 34
i 7 105.535714 1.071429 67 65
i 4 105.803571 1.071429 71 44
i 1 106.339286 0.267857 36 62
i 3 106.607143 0.133929 38 57
i 3 106.607143 0.133929 42 34
i 3 107.142857 0.133929 35 66
i 6 107.142857 4.017857 55 68
i 6 107.142857 4.017857 59 68
i 6 107.142857 4.017857 62 68
i 6 107.142857 4.017857 66 68
i 1 107.410714 0.267857 31 62
i 3 107.946429 0.133929 42 37
i 7 108.214286 0.803571 62 67
i 1 108.482143 0.267857 31 62
i 4 108.482143 1.071429 74 50
i 3 109.017857 0.133929 42 37
i 1 109.553571 0.267857 31 62
i 7 109.821429 1.071429 59 64
i 3 110.089286 0.133929 42 37
i 1 110.625 0.267857 31 62
i 4 110.625 0.669643 78 42
i 3 111.160714 0.133929 42 37
i 3 111.428571 0.133929 35 83
i 6 111.428571 4.017857 48 71
i 6 111.428571 4.017857 52 71
i 6 111.428571 4.017857 55 71
i 6 111.428571 4.017857 59 71
i 1 111.696429 0.267857 36 62
i 3 111.964286 0.133929 42 34
i 7 112.5 1.339286 60 58
i 7 112.5 1.339286 64 58
i 7 112.5 1.339286 67 58
i 1 112.767857 0.267857 36 62
i 3 113.035714 0.133929 38 54
i 3 113.035714 0.133929 42 34
i 3 113.571429 0.133929 35 77
i 1 113.839286 0.267857 36 62
i 3 114.107143 0.133929 42 34
i 1 114.910714 0.267857 36 62
i 3 115.178571 0.133929 38 57
i 3 115.178571 0.133929 42 34
i 3 115.714286 0.133929 35 66
i 6 115.714286 4.017857 55 68
i 6 115.714286 4.017857 59 68
i 6 115.714286 4.017857 62 68
i 6 115.714286 4.017857 66 68
i 1 115.982143 0.267857 31 62
i 3 116.517857 0.133929 42 37
i 1 117.053571 0.267857 31 62
i 4 117.053571 1.071429 74 50
i 7 117.321429 1.339286 55 59
i 7 117.321429 1.339286 59 59
i 7 117.321429 1.339286 62 59
i 3 117.589286 0.133929 42 37
i 1 118.125 0.267857 31 62
i 3 118.660714 0.133929 42 37
i 1 119.196429 0.267857 31 62
i 4 119.196429 0.669643 78 42
i 3 119.732143 0.133929 42 37
i 2 120 4.017857 52 51
i 2 120 4.017857 55 51
i 2 120 4.017857 59 51
i 3 120 0.133929 36 108
i 3 120 0.133929 42 59
i 1 120.267857 0.133929 40 99
i 3 120.267857 0.133929 42 72
i 8 120.267857 0.267857 64 86
i 1 120.401786 0.133929 40 77
i 3 120.535714 0.133929 38 102
i 3 120.535714 0.133929 42 59
i 1 120.803571 0.133929 40 82
i 3 120.803571 0.133929 42 72
i 5 120.9375 0.133929 52 78
i 3 121.071429 0.133929 36 99
i 3 121.071429 0.133929 42 59
i 8 121.071429 0.401786 67 76
i 1 121.339286 0.133929 40 99
i 3 121.339286 0.133929 42 72
i 1 121.473214 0.133929 40 85
i 3 121.607143 0.133929 38 105
i 3 121.607143 0.133929 42 59
i 1 121.875 0.133929 52 74
i 3 121.875 0.133929 46 52
i 8 121.875 0.267857 66 81
i 3 122.142857 0.133929 36 106
i 3 122.142857 0.133929 42 59
i 1 122.410714 0.133929 40 99
i 3 122.410714 0.133929 42 72
i 5 122.410714 0.133929 52 69
i 1 122.544643 0.133929 40 77
i 3 122.678571 0.133929 38 101
i 3 122.678571 0.133929 42 59
i 8 122.678571 1.071429 71 84
i 1 122.946429 0.133929 40 82
i 3 122.946429 0.133929 42 72
i 3 123.214286 0.133929 36 101
i 3 123.214286 0.133929 42 59
i 1 123.482143 0.133929 40 99
i 3 123.482143 0.133929 42 72
i 1 123.616071 0.133929 40 85
i 5 123.616071 0.133929 52 60
i 3 123.75 0.133929 38 108
i 3 123.75 0.133929 42 59
i 1 124.017857 0.133929 52 74
i 3 124.017857 0.133929 46 57
i 2 124.285714 4.017857 48 47
i 2 124.285714 4.017857 52 47
i 2 124.285714 4.017857 55 47
i 3 124.285714 0.133929 36 108
i 3 124.285714 0.133929 42 59
i 1 124.553571 0.133929 36 99
i 3 124.553571 0.133929 42 72
i 8 124.553571 0.535714 67 79
i 1 124.6875 0.133929 36 77
i 3 124.821429 0.133929 38 102
i 3 124.821429 0.133929 42 59
i 1 125.089286 0.133929 36 82
i 3 125.089286 0.133929 42 72
i 5 125.223214 0.133929 48 76
i 3 125.357143 0.133929 36 99
i 3 125.357143 0.133929 42 59
i 8 125.357143 0.535714 71 83
i 1 125.625 0.133929 36 99
i 3 125.625 0.133929 42 72
i 1 125.758929 0.133929 36 85
i 3 125.892857 0.133929 38 105
i 3 125.892857 0.133929 42 59
i 1 126.160714 0.133929 48 74
i 3 126.160714 0.133929 46 52
i 3 126.428571 0.133929 36 106
i 3 126.428571 0.133929 42 59
i 8 126.428571 0.401786 69 78
i 1 126.696429 0.133929 36 99
i 3 126.696429 0.133929 42 72
i 5 126.696429 0.133929 48 67
i 1 126.830357 0.133929 36 77
i 3 126.964286 0.133929 38 101
i 3 126.964286 0.133929 42 59
i 1 127.232143 0.133929 36 82
i 3 127.232143 0.133929 42 72
i 3 127.5 0.133929 36 101
i 3 127.5 0.133929 42 59
i 8 127.5 0.803571 67 72
i 1 127.767857 0.133929 36 99
i 3 127.767857 0.133929 42 72
i 1 127.901786 0.133929 36 85
i 5 127.901786 0.133929 48 58
i 3 128.035714 0.133929 38 108
i 3 128.035714 0.133929 42 59
i 1 128.303571 0.133929 48 74
i 3 128.303571 0.133929 46 57
i 2 128.571429 4.017857 45 49
i 2 128.571429 4.017857 48 49
i 2 128.571429 4.017857 52 49
i 3 128.571429 0.133929 36 108
i 3 128.571429 0.133929 42 59
i 1 128.839286 0.133929 33 99
i 3 128.839286 0.133929 42 72
i 8 128.839286 0.535714 64 77
i 1 128.973214 0.133929 33 77
i 3 129.107143 0.133929 38 102
i 3 129.107143 0.133929 42 59
i 1 129.375 0.133929 33 82
i 3 129.375 0.133929 42 72
i 3 129.508929 0.133929 42 40
i 5 129.508929 0.133929 45 78
i 3 129.642857 0.133929 36 99
i 3 129.642857 0.133929 42 59
i 8 129.642857 0.535714 69 82
i 1 129.910714 0.133929 33 99
i 3 129.910714 0.133929 42 72
i 1 130.044643 0.133929 33 85
i 3 130.178571 0.133929 38 105
i 3 130.178571 0.133929 42 59
i 1 130.446429 0.133929 45 74
i 3 130.446429 0.133929 46 52
i 3 130.580357 0.133929 42 43
i 3 130.714286 0.133929 36 106
i 3 130.714286 0.133929 42 59
i 8 130.714286 0.401786 67 75
i 1 130.982143 0.133929 33 99
i 3 130.982143 0.133929 42 72
i 5 130.982143 0.133929 45 69
i 1 131.116071 0.133929 33 77
i 3 131.116071 0.133929 38 43
i 3 131.25 0.133929 38 101
i 3 131.25 0.133929 42 59
i 1 131.517857 0.133929 33 82
i 3 131.517857 0.133929 42 72
i 3 131.651786 0.133929 36 69
i 3 131.785714 0.133929 36 101
i 3 131.785714 0.133929 42 59
i 8 131.785714 0.803571 64 72
i 1 132.053571 0.133929 33 99
i 3 132.053571 0.133929 42 72
i 1 132.1875 0.133929 33 85
i 3 132.1875 0.133929 42 44
i 5 132.1875 0.133929 45 60
i 3 132.321429 0.133929 38 108
i 3 132.321429 0.133929 42 59
i 1 132.589286 0.133929 45 74
i 3 132.589286 0.133929 46 57
i 3 132.723214 0.133929 42 40
i 2 132.857143 4.017857 47 49
i 2 132.857143 4.017857 52 49
i 2 132.857143 4.017857 54 49
i 3 132.857143 0.133929 36 108
i 3 132.857143 0.133929 42 59
i 8 132.857143 0.535714 66 82
i 1 133.125 0.133929 35 99
i 3 133.125 0.133929 42 72
i 1 133.258929 0.133929 35 77
i 3 133.392857 0.133929 38 102
i 3 133.392857 0.133929 42 59
i 1 133.660714 0.133929 35 82
i 3 133.660714 0.133929 42 72
i 5 133.794643 0.133929 47 77
i 3 133.928571 0.133929 36 99
i 3 133.928571 0.133929 42 59
i 8 133.928571 0.401786 64 76
i 1 134.196429 0.133929 35 99
i 3 134.196429 0.133929 42 72
i 1 134.330357 0.133929 35 85
i 3 134.464286 0.133929 38 105
i 3 134.464286 0.133929 42 59
i 1 134.732143 0.133929 47 74
i 3 134.732143 0.133929 46 52
i 8 134.732143 0.535714 59 78
i 3 135 0.133929 36 106
i 3 135 0.133929 42 59
i 1 135.267857 0.133929 35 99
i 3 135.267857 0.133929 42 72
i 5 135.267857 0.133929 47 68
i 1 135.401786 0.133929 35 77
i 3 135.535714 0.133929 38 101
i 3 135.535714 0.133929 42 59
i 1 135.803571 0.133929 35 82
i 3 135.803571 0.133929 42 72
i 8 135.803571 1.071429 66 83
i 3 136.071429 0.133929 36 101
i 3 136.071429 0.133929 42 59
i 1 136.339286 0.133929 35 99
i 3 136.339286 0.133929 38 65
i 3 136.339286 0.133929 42 72
i 1 136.473214 0.133929 35 85
i 5 136.473214 0.133929 47 59
i 3 136.607143 0.133929 38 108
i 3 136.607143 0.133929 42 59
i 1 136.875 0.133929 47 74
i 3 136.875 0.133929 38 80
i 3 136.875 0.133929 46 57
i 3 137.008929 0.133929 38 49
i 2 137.142857 4.017857 52 51
i 2 137.142857 4.017857 55 51
i 2 137.142857 4.017857 59 51
i 3 137.142857 0.133929 36 108
i 3 137.142857 0.133929 42 59
i 8 137.142857 0.535714 69 82
i 1 137.410714 0.133929 40 99
i 3 137.410714 0.133929 42 72
i 1 137.544643 0.133929 40 77
i 3 137.678571 0.133929 38 102
i 3 137.678571 0.133929 42 59
i 1 137.946429 0.133929 40 82
i 3 137.946429 0.133929 42 72
i 8 137.946429 0.535714 67 78
i 3 138.080357 0.133929 42 40
i 5 138.080357 0.133929 52 78
i 3 138.214286 0.133929 36 99
i 3 138.214286 0.133929 42 59
i 1 138.482143 0.133929 40 99
i 3 138.482143 0.133929 42 72
i 1 138.616071 0.133929 40 85
i 3 138.75 0.133929 38 105
i 3 138.75 0.133929 42 59
i 8 138.75 0.401786 66 85
i 1 139.017857 0.133929 52 74
i 3 139.017857 0.133929 46 52
i 3 139.151786 0.133929 42 43
i 3 139.285714 0.133929 36 106
i 3 139.285714 0.133929 42 59
i 1 139.553571 0.133929 40 99
i 3 139.553571 0.133929 42 72
i 5 139.553571 0.133929 52 69
i 1 139.6875 0.133929 40 77
i 3 139.6875 0.133929 38 43
i 3 139.821429 0.133929 38 101
i 3 139.821429 0.133929 42 59
i 1 140.089286 0.133929 40 82
i 3 140.089286 0.133929 42 72
i 8 140.089286 0.803571 64 75
i 3 140.223214 0.133929 36 69
i 3 140.357143 0.133929 36 101
i 3 140.357143 0.133929 42 59
i 1 140.625 0.133929 40 99
i 3 140.625 0.133929 42 72
i 1 140.758929 0.133929 40 85
i 3 140.758929 0.133929 42 44
i 5 140.758929 0.133929 52 60
i 3 140.892857 0.133929 38 108
i 3 140.892857 0.133929 42 59
i 1 141.160714 0.133929 52 74
i 3 141.160714 0.133929 46 57
i 3 141.294643 0.133929 42 40
i 2 141.428571 4.017857 48 47
i 2 141.428571 4.017857 52 47
i 2 141.428571 4.017857 55 47
i 3 141.428571 0.133929 36 108
i 3 141.428571 0.133929 42 59
i 1 141.696429 0.133929 36 99
i 3 141.696429 0.133929 42 72
i 8 141.696429 0.535714 67 79
i 1 141.830357 0.133929 36 77
i 3 141.964286 0.133929 38 102
i 3 141.964286 0.133929 42 59
i 1 142.232143 0.133929 36 82
i 3 142.232143 0.133929 42 72
i 3 142.366071 0.133929 42 40
i 5 142.366071 0.133929 48 76
i 3 142.5 0.133929 36 99
i 3 142.5 0.133929 42 59
i 8 142.5 0.535714 71 83
i 1 142.767857 0.133929 36 99
i 3 142.767857 0.133929 42 72
i 1 142.901786 0.133929 36 85
i 3 143.035714 0.133929 38 105
i 3 143.035714 0.133929 42 59
i 1 143.303571 0.133929 48 74
i 3 143.303571 0.133929 46 52
i 3 143.4375 0.133929 42 43
i 3 143.571429 0.133929 36 106
i 3 143.571429 0.133929 42 59
i 8 143.571429 0.401786 69 78
i 1 143.839286 0.133929 36 99
i 3 143.839286 0.133929 42 72
i 5 143.839286 0.133929 48 67
i 1 143.973214 0.133929 36 77
i 3 143.973214 0.133929 38 43
i 3 144.107143 0.133929 38 101
i 3 144.107143 0.133929 42 59
i 1 144.375 0.133929 36 82
i 3 144.375 0.133929 42 72
i 3 144.508929 0.133929 36 69
i 3 144.642857 0.133929 36 101
i 3 144.642857 0.133929 42 59
i 8 144.642857 0.803571 67 72
i 1 144.910714 0.133929 36 99
i 3 144.910714 0.133929 42 72
i 1 145.044643 0.133929 36 85
i 3 145.044643 0.133929 42 44
i 5 145.044643 0.133929 48 58
i 3 145.178571 0.133929 38 108
i 3 145.178571 0.133929 42 59
i 1 145.446429 0.133929 48 74
i 3 145.446429 0.133929 46 57
i 3 145.580357 0.133929 42 40
i 2 145.714286 4.017857 45 49
i 2 145.714286 4.017857 48 49
i 2 145.714286 4.017857 52 49
i 3 145.714286 0.133929 36 108
i 3 145.714286 0.133929 42 59
i 1 145.982143 0.133929 33 99
i 3 145.982143 0.133929 42 72
i 8 145.982143 0.535714 64 77
i 1 146.116071 0.133929 33 77
i 3 146.25 0.133929 38 102
i 3 146.25 0.133929 42 59
i 1 146.517857 0.133929 33 82
i 3 146.517857 0.133929 42 72
i 3 146.651786 0.133929 42 40
i 5 146.651786 0.133929 45 78
i 3 146.785714 0.133929 36 99
i 3 146.785714 0.133929 42 59
i 8 146.785714 0.535714 69 82
i 1 147.053571 0.133929 33 99
i 3 147.053571 0.133929 42 72
i 1 147.1875 0.133929 33 85
i 3 147.321429 0.133929 38 105
i 3 147.321429 0.133929 42 59
i 1 147.589286 0.133929 45 74
i 3 147.589286 0.133929 46 52
i 3 147.723214 0.133929 42 43
i 3 147.857143 0.133929 36 106
i 3 147.857143 0.133929 42 59
i 8 147.857143 0.401786 67 75
i 1 148.125 0.133929 33 99
i 3 148.125 0.133929 42 72
i 5 148.125 0.133929 45 69
i 1 148.258929 0.133929 33 77
i 3 148.258929 0.133929 38 43
i 3 148.392857 0.133929 38 101
i 3 148.392857 0.133929 42 59
i 1 148.660714 0.133929 33 82
i 3 148.660714 0.133929 42 72
i 3 148.794643 0.133929 36 69
i 3 148.928571 0.133929 36 101
i 3 148.928571 0.133929 42 59
i 8 148.928571 0.803571 64 72
i 1 149.196429 0.133929 33 99
i 3 149.196429 0.133929 42 72
i 1 149.330357 0.133929 33 85
i 3 149.330357 0.133929 42 44
i 5 149.330357 0.133929 45 60
i 3 149.464286 0.133929 38 108
i 3 149.464286 0.133929 42 59
i 1 149.732143 0.133929 45 74
i 3 149.732143 0.133929 46 57
i 3 149.866071 0.133929 42 40
i 2 150 4.017857 47 49
i 2 150 4.017857 52 49
i 2 150 4.017857 54 49
i 3 150 0.133929 36 108
i 3 150 0.133929 42 59
i 8 150 0.535714 66 82
i 1 150.267857 0.133929 35 99
i 3 150.267857 0.133929 42 72
i 1 150.401786 0.133929 35 77
i 3 150.535714 0.133929 38 102
i 3 150.535714 0.133929 42 59
i 1 150.803571 0.133929 35 82
i 3 150.803571 0.133929 42 72
i 5 150.9375 0.133929 52 85
i 3 151.071429 0.133929 36 99
i 3 151.071429 0.133929 42 59
i 8 151.071429 0.401786 64 76
i 1 151.339286 0.133929 35 99
i 3 151.339286 0.133929 42 72
i 1 151.473214 0.133929 35 85
i 3 151.607143 0.133929 38 105
i 3 151.607143 0.133929 42 59
i 1 151.875 0.133929 47 74
i 3 151.875 0.133929 46 52
i 8 151.875 0.535714 59 78
i 3 152.142857 0.133929 36 106
i 3 152.142857 0.133929 42 59
i 9 152.142857 1.875 64 38
i 1 152.410714 0.133929 35 99
i 3 152.410714 0.133929 42 72
i 1 152.544643 0.133929 35 77
i 3 152.678571 0.133929 38 101
i 3 152.678571 0.133929 42 59
i 1 152.946429 0.133929 35 82
i 3 152.946429 0.133929 42 72
i 8 152.946429 1.071429 66 83
i 5 153.080357 0.133929 52 76
i 3 153.214286 0.133929 36 101
i 3 153.214286 0.133929 42 59
i 1 153.482143 0.133929 35 99
i 3 153.482143 0.133929 38 65
i 3 153.482143 0.133929 42 72
i 5 153.482143 0.133929 52 67
i 1 153.616071 0.133929 35 85
i 3 153.75 0.133929 38 108
i 3 153.75 0.133929 42 59
i 1 154.017857 0.133929 47 74
i 3 154.017857 0.133929 38 80
i 3 154.017857 0.133929 46 57
i 5 154.017857 0.133929 52 85
i 3 154.151786 0.133929 38 49
i 2 154.285714 4.017857 52 51
i 2 154.285714 4.017857 55 51
i 2 154.285714 4.017857 59 51
i 3 154.285714 0.133929 36 108
i 3 154.285714 0.133929 42 59
i 1 154.553571 0.133929 40 99
i 3 154.553571 0.133929 42 72
i 8 154.553571 0.267857 76 85
i 1 154.6875 0.133929 40 77
i 3 154.821429 0.133929 38 102
i 3 154.821429 0.133929 42 59
i 1 155.089286 0.133929 40 82
i 3 155.089286 0.133929 42 72
i 1 155.223214 0.133929 40 73
i 5 155.223214 0.133929 52 78
i 3 155.357143 0.133929 36 99
i 3 155.357143 0.133929 42 59
i 8 155.357143 0.401786 79 78
i 1 155.625 0.133929 40 99
i 3 155.625 0.133929 42 72
i 1 155.758929 0.133929 40 85
i 3 155.892857 0.133929 38 105
i 3 155.892857 0.133929 42 59
i 1 156.160714 0.133929 52 74
i 3 156.160714 0.133929 46 52
i 8 156.160714 0.267857 78 82
i 1 156.294643 0.133929 40 81
i 3 156.428571 0.133929 36 106
i 3 156.428571 0.133929 42 59
i 1 156.696429 0.133929 40 99
i 3 156.696429 0.133929 42 72
i 5 156.696429 0.133929 52 69
i 1 156.830357 0.133929 40 77
i 3 156.964286 0.133929 38 101
i 3 156.964286 0.133929 42 59
i 8 156.964286 1.071429 71 81
i 1 157.232143 0.133929 40 82
i 3 157.232143 0.133929 42 72
i 3 157.5 0.133929 36 101
i 3 157.5 0.133929 42 59
i 1 157.767857 0.133929 40 99
i 3 157.767857 0.133929 42 72
i 1 157.901786 0.133929 40 85
i 5 157.901786 0.133929 52 60
i 3 158.035714 0.133929 38 108
i 3 158.035714 0.133929 42 59
i 1 158.169643 0.133929 40 83
i 1 158.303571 0.133929 52 74
i 3 158.303571 0.133929 46 57
i 2 158.571429 4.017857 48 47
i 2 158.571429 4.017857 52 47
i 2 158.571429 4.017857 55 47
i 3 158.571429 0.133929 36 108
i 3 158.571429 0.133929 42 59
i 1 158.839286 0.133929 36 99
i 3 158.839286 0.133929 42 72
i 8 158.839286 0.535714 67 79
i 1 158.973214 0.133929 36 77
i 3 159.107143 0.133929 38 102
i 3 159.107143 0.133929 42 59
i 1 159.375 0.133929 36 82
i 3 159.375 0.133929 42 72
i 5 159.508929 0.133929 48 76
i 3 159.642857 0.133929 36 99
i 3 159.642857 0.133929 42 59
i 8 159.642857 0.535714 71 83
i 1 159.910714 0.133929 36 99
i 3 159.910714 0.133929 42 72
i 1 160.044643 0.133929 36 85
i 3 160.178571 0.133929 38 105
i 3 160.178571 0.133929 42 59
i 1 160.446429 0.133929 48 74
i 3 160.446429 0.133929 46 52
i 3 160.714286 0.133929 36 106
i 3 160.714286 0.133929 42 59
i 8 160.714286 0.401786 69 78
i 1 160.982143 0.133929 36 99
i 3 160.982143 0.133929 42 72
i 5 160.982143 0.133929 48 67
i 1 161.116071 0.133929 36 77
i 3 161.25 0.133929 38 101
i 3 161.25 0.133929 42 59
i 1 161.517857 0.133929 36 82
i 3 161.517857 0.133929 42 72
i 3 161.785714 0.133929 36 101
i 3 161.785714 0.133929 42 59
i 8 161.785714 0.803571 67 72
i 1 162.053571 0.133929 36 99
i 3 162.053571 0.133929 42 72
i 1 162.1875 0.133929 36 85
i 5 162.1875 0.133929 48 58
i 3 162.321429 0.133929 38 108
i 3 162.321429 0.133929 42 59
i 1 162.589286 0.133929 48 74
i 3 162.589286 0.133929 46 57
i 2 162.857143 4.017857 45 49
i 2 162.857143 4.017857 48 49
i 2 162.857143 4.017857 52 49
i 3 162.857143 0.133929 36 108
i 3 162.857143 0.133929 42 59
i 1 163.125 0.133929 33 99
i 3 163.125 0.133929 42 72
i 8 163.125 0.535714 64 77
i 1 163.258929 0.133929 33 77
i 3 163.392857 0.133929 38 102
i 3 163.392857 0.133929 42 59
i 1 163.660714 0.133929 33 82
i 3 163.660714 0.133929 42 72
i 3 163.794643 0.133929 42 40
i 5 163.794643 0.133929 45 78
i 3 163.928571 0.133929 36 99
i 3 163.928571 0.133929 42 59
i 8 163.928571 0.535714 69 82
i 1 164.196429 0.133929 33 99
i 3 164.196429 0.133929 42 72
i 1 164.330357 0.133929 33 85
i 3 164.464286 0.133929 38 105
i 3 164.464286 0.133929 42 59
i 1 164.732143 0.133929 45 74
i 3 164.732143 0.133929 46 52
i 3 164.866071 0.133929 42 43
i 3 165 0.133929 36 106
i 3 165 0.133929 42 59
i 8 165 0.401786 67 75
i 1 165.267857 0.133929 33 99
i 3 165.267857 0.133929 42 72
i 5 165.267857 0.133929 45 69
i 1 165.401786 0.133929 33 77
i 3 165.401786 0.133929 38 43
i 3 165.535714 0.133929 38 101
i 3 165.535714 0.133929 42 59
i 1 165.803571 0.133929 33 82
i 3 165.803571 0.133929 42 72
i 3 165.9375 0.133929 36 69
i 3 166.071429 0.133929 36 101
i 3 166.071429 0.133929 42 59
i 8 166.071429 0.803571 64 72
i 1 166.339286 0.133929 33 99
i 3 166.339286 0.133929 42 72
i 1 166.473214 0.133929 33 85
i 3 166.473214 0.133929 42 44
i 5 166.473214 0.133929 45 60
i 3 166.607143 0.133929 38 108
i 3 166.607143 0.133929 42 59
i 1 166.875 0.133929 45 74
i 3 166.875 0.133929 46 57
i 3 167.008929 0.133929 42 40
i 2 167.142857 4.017857 47 49
i 2 167.142857 4.017857 52 49
i 2 167.142857 4.017857 54 49
i 3 167.142857 0.133929 36 108
i 3 167.142857 0.133929 42 59
i 8 167.142857 0.535714 66 82
i 1 167.410714 0.133929 35 99
i 3 167.410714 0.133929 42 72
i 1 167.544643 0.133929 35 77
i 3 167.678571 0.133929 38 102
i 3 167.678571 0.133929 42 59
i 1 167.946429 0.133929 35 82
i 3 167.946429 0.133929 42 72
i 5 168.080357 0.133929 47 77
i 3 168.214286 0.133929 36 99
i 3 168.214286 0.133929 42 59
i 8 168.214286 0.401786 64 76
i 1 168.482143 0.133929 35 99
i 3 168.482143 0.133929 42 72
i 1 168.616071 0.133929 35 85
i 3 168.75 0.133929 38 105
i 3 168.75 0.133929 42 59
i 1 169.017857 0.133929 47 74
i 3 169.017857 0.133929 46 52
i 8 169.017857 0.535714 59 78
i 3 169.285714 0.133929 36 106
i 3 169.285714 0.133929 42 59
i 1 169.553571 0.133929 35 99
i 3 169.553571 0.133929 42 72
i 5 169.553571 0.133929 47 68
i 1 169.6875 0.133929 35 77
i 3 169.821429 0.133929 38 101
i 3 169.821429 0.133929 42 59
i 1 170.089286 0.133929 35 82
i 3 170.089286 0.133929 42 72
i 8 170.089286 1.071429 66 83
i 3 170.357143 0.133929 36 101
i 3 170.357143 0.133929 42 59
i 1 170.625 0.133929 35 99
i 3 170.625 0.133929 38 65
i 3 170.625 0.133929 42 72
i 1 170.758929 0.133929 35 85
i 5 170.758929 0.133929 47 59
i 3 170.892857 0.133929 38 108
i 3 170.892857 0.133929 42 59
i 1 171.160714 0.133929 47 74
i 3 171.160714 0.133929 38 80
i 3 171.160714 0.133929 46 57
i 3 171.294643 0.133929 38 49
i 2 171.428571 4.017857 52 51
i 2 171.428571 4.017857 55 51
i 2 171.428571 4.017857 59 51
i 3 171.428571 0.133929 36 108
i 3 171.428571 0.133929 42 59
i 8 171.428571 0.535714 69 82
i 1 171.696429 0.133929 40 99
i 3 171.696429 0.133929 42 72
i 1 171.830357 0.133929 40 77
i 3 171.964286 0.133929 38 102
i 3 171.964286 0.133929 42 59
i 1 172.232143 0.133929 40 82
i 3 172.232143 0.133929 42 72
i 8 172.232143 0.535714 67 78
i 1 172.366071 0.133929 40 73
i 3 172.366071 0.133929 42 40
i 5 172.366071 0.133929 52 78
i 3 172.5 0.133929 36 99
i 3 172.5 0.133929 42 59
i 1 172.767857 0.133929 40 99
i 3 172.767857 0.133929 42 72
i 1 172.901786 0.133929 40 85
i 3 173.035714 0.133929 38 105
i 3 173.035714 0.133929 42 59
i 8 173.035714 0.401786 66 85
i 1 173.303571 0.133929 52 74
i 3 173.303571 0.133929 46 52
i 1 173.4375 0.133929 40 81
i 3 173.4375 0.133929 42 43
i 3 173.571429 0.133929 36 106
i 3 173.571429 0.133929 42 59
i 1 173.839286 0.133929 40 99
i 3 173.839286 0.133929 42 72
i 5 173.839286 0.133929 52 69
i 1 173.973214 0.133929 40 77
i 3 173.973214 0.133929 38 43
i 3 174.107143 0.133929 38 101
i 3 174.107143 0.133929 42 59
i 1 174.375 0.133929 40 82
i 3 174.375 0.133929 42 72
i 8 174.375 0.803571 64 75
i 3 174.508929 0.133929 36 69
i 3 174.642857 0.133929 36 101
i 3 174.642857 0.133929 42 59
i 1 174.910714 0.133929 40 99
i 3 174.910714 0.133929 42 72
i 1 175.044643 0.133929 40 85
i 3 175.044643 0.133929 42 44
i 5 175.044643 0.133929 52 60
i 3 175.178571 0.133929 38 108
i 3 175.178571 0.133929 42 59
i 1 175.3125 0.133929 40 83
i 1 175.446429 0.133929 52 74
i 3 175.446429 0.133929 46 57
i 3 175.580357 0.133929 42 40
i 2 175.714286 4.017857 48 47
i 2 175.714286 4.017857 52 47
i 2 175.714286 4.017857 55 47
i 3 175.714286 0.133929 36 108
i 3 175.714286 0.133929 42 59
i 1 175.982143 0.133929 36 99
i 3 175.982143 0.133929 42 72
i 1 176.116071 0.133929 36 77
i 3 176.25 0.133929 38 102
i 3 176.25 0.133929 42 59
i 1 176.517857 0.133929 36 82
i 3 176.517857 0.133929 42 72
i 3 176.651786 0.133929 42 40
i 5 176.651786 0.133929 48 76
i 3 176.785714 0.133929 36 99
i 3 176.785714 0.133929 42 59
i 1 177.053571 0.133929 36 99
i 3 177.053571 0.133929 42 72
i 1 177.1875 0.133929 36 85
i 3 177.321429 0.133929 38 105
i 3 177.321429 0.133929 42 59
i 1 177.589286 0.133929 48 74
i 3 177.589286 0.133929 46 52
i 3 177.723214 0.133929 42 43
i 3 177.857143 0.133929 36 106
i 3 177.857143 0.133929 42 59
i 1 178.125 0.133929 36 99
i 3 178.125 0.133929 42 72
i 5 178.125 0.133929 48 67
i 1 178.258929 0.133929 36 77
i 3 178.258929 0.133929 38 43
i 3 178.392857 0.133929 38 101
i 3 178.392857 0.133929 42 59
i 1 178.660714 0.133929 36 82
i 3 178.660714 0.133929 42 72
i 3 178.794643 0.133929 36 69
i 3 178.928571 0.133929 36 101
i 3 178.928571 0.133929 42 59
i 1 179.196429 0.133929 36 99
i 3 179.196429 0.133929 42 72
i 1 179.330357 0.133929 36 85
i 3 179.330357 0.133929 42 44
i 5 179.330357 0.133929 48 58
i 3 179.464286 0.133929 38 108
i 3 179.464286 0.133929 42 59
i 1 179.732143 0.133929 48 74
i 3 179.732143 0.133929 46 57
i 3 179.866071 0.133929 42 40
i 2 180 4.017857 45 49
i 2 180 4.017857 48 49
i 2 180 4.017857 52 49
i 3 180 0.133929 36 108
i 3 180 0.133929 42 59
i 1 180.267857 0.133929 33 99
i 3 180.267857 0.133929 42 72
i 8 180.267857 0.535714 64 77
i 1 180.401786 0.133929 33 77
i 3 180.535714 0.133929 38 102
i 3 180.535714 0.133929 42 59
i 1 180.803571 0.133929 33 82
i 3 180.803571 0.133929 42 72
i 3 180.9375 0.133929 42 40
i 5 180.9375 0.133929 45 78
i 3 181.071429 0.133929 36 99
i 3 181.071429 0.133929 42 59
i 8 181.071429 0.535714 69 82
i 1 181.339286 0.133929 33 99
i 3 181.339286 0.133929 42 72
i 1 181.473214 0.133929 33 85
i 3 181.607143 0.133929 38 105
i 3 181.607143 0.133929 42 59
i 1 181.875 0.133929 45 74
i 3 181.875 0.133929 46 52
i 3 182.008929 0.133929 42 43
i 3 182.142857 0.133929 36 106
i 3 182.142857 0.133929 42 59
i 8 182.142857 0.401786 67 75
i 1 182.410714 0.133929 33 99
i 3 182.410714 0.133929 42 72
i 5 182.410714 0.133929 45 69
i 1 182.544643 0.133929 33 77
i 3 182.544643 0.133929 38 43
i 3 182.678571 0.133929 38 101
i 3 182.678571 0.133929 42 59
i 1 182.946429 0.133929 33 82
i 3 182.946429 0.133929 42 72
i 3 183.080357 0.133929 36 69
i 3 183.214286 0.133929 36 101
i 3 183.214286 0.133929 42 59
i 8 183.214286 0.803571 64 72
i 1 183.482143 0.133929 33 99
i 3 183.482143 0.133929 42 72
i 1 183.616071 0.133929 33 85
i 3 183.616071 0.133929 42 44
i 5 183.616071 0.133929 45 60
i 3 183.75 0.133929 38 108
i 3 183.75 0.133929 42 59
i 1 184.017857 0.133929 45 74
i 3 184.017857 0.133929 46 57
i 3 184.151786 0.133929 42 40
i 2 184.285714 4.017857 47 49
i 2 184.285714 4.017857 52 49
i 2 184.285714 4.017857 54 49
i 3 184.285714 0.133929 36 108
i 3 184.285714 0.133929 42 59
i 8 184.285714 0.535714 66 82
i 9 184.285714 4.017857 59 34
i 1 184.553571 0.133929 35 99
i 3 184.553571 0.133929 42 72
i 1 184.6875 0.133929 35 77
i 3 184.821429 0.133929 38 102
i 3 184.821429 0.133929 42 59
i 1 185.089286 0.133929 35 82
i 3 185.089286 0.133929 42 72
i 5 185.223214 0.133929 52 85
i 3 185.357143 0.133929 36 99
i 3 185.357143 0.133929 42 59
i 8 185.357143 0.401786 64 76
i 1 185.625 0.133929 35 99
i 3 185.625 0.133929 42 72
i 1 185.758929 0.133929 35 85
i 3 185.892857 0.133929 38 105
i 3 185.892857 0.133929 42 59
i 1 186.160714 0.133929 47 74
i 3 186.160714 0.133929 46 52
i 8 186.160714 0.535714 59 78
i 3 186.428571 0.133929 36 106
i 3 186.428571 0.133929 42 59
i 1 186.696429 0.133929 35 99
i 3 186.696429 0.133929 42 72
i 1 186.830357 0.133929 35 77
i 3 186.964286 0.133929 38 101
i 3 186.964286 0.133929 42 59
i 1 187.232143 0.133929 35 82
i 3 187.232143 0.133929 42 72
i 8 187.232143 1.071429 66 83
i 5 187.366071 0.133929 52 76
i 3 187.5 0.133929 36 101
i 3 187.5 0.133929 42 59
i 1 187.767857 0.133929 35 99
i 3 187.767857 0.133929 38 65
i 3 187.767857 0.133929 42 72
i 5 187.767857 0.133929 52 67
i 1 187.901786 0.133929 35 85
i 3 188.035714 0.133929 38 108
i 3 188.035714 0.133929 42 59
i 1 188.303571 0.133929 47 74
i 3 188.303571 0.133929 38 80
i 3 188.303571 0.133929 46 57
i 5 188.303571 0.133929 52 85
i 3 188.4375 0.133929 38 49
i 3 188.571429 0.133929 35 83
i 6 188.571429 4.017857 48 71
i 6 188.571429 4.017857 52 71
i 6 188.571429 4.017857 55 71
i 6 188.571429 4.017857 59 71
i 1 188.839286 0.267857 36 62
i 3 189.107143 0.133929 42 34
i 4 189.375 1.071429 76 53
i 7 189.642857 0.803571 64 70
i 1 189.910714 0.267857 36 62
i 3 190.178571 0.133929 38 54
i 3 190.178571 0.133929 42 34
i 3 190.714286 0.133929 35 77
i 1 190.982143 0.267857 36 62
i 3 191.25 0.133929 42 34
i 7 191.25 1.071429 67 65
i 4 191.517857 1.071429 71 44
i 1 192.053571 0.267857 36 62
i 3 192.321429 0.133929 38 57
i 3 192.321429 0.133929 42 34
i 3 192.857143 0.133929 35 66
i 6 192.857143 4.017857 55 68
i 6 192.857143 4.017857 59 68
i 6 192.857143 4.017857 62 68
i 6 192.857143 4.017857 66 68
i 1 193.125 0.267857 31 62
i 3 193.660714 0.133929 42 37
i 7 193.928571 0.803571 62 67
i 1 194.196429 0.267857 31 62
i 4 194.196429 1.071429 74 50
i 3 194.732143 0.133929 42 37
i 1 195.267857 0.267857 31 62
i 7 195.535714 1.071429 59 64
i 3 195.803571 0.133929 42 37
i 1 196.339286 0.267857 31 62
i 4 196.339286 0.669643 78 42
i 3 196.875 0.133929 42 37
i 3 197.142857 0.133929 35 66
i 6 197.142857 4.017857 48 71
i 6 197.142857 4.017857 52 71
i 6 197.142857 4.017857 55 71
i 6 197.142857 4.017857 59 71
i 7 197.142857 0.803571 64 65
i 4 197.678571 1.339286 79 48
i 3 197.946429 0.133929 42 37
i 7 198.214286 0.803571 67 62
i 8 198.214286 1.071429 64 54
i 3 199.017857 0.133929 42 37
i 7 199.285714 0.803571 66 60
i 3 200.089286 0.133929 42 37
i 4 200.089286 1.071429 76 43
i 7 200.357143 0.803571 71 63
i 8 200.357143 0.803571 71 48
i 3 201.160714 0.133929 42 37
i 3 201.428571 0.133929 35 66
i 6 201.428571 4.017857 55 68
i 6 201.428571 4.017857 59 68
i 6 201.428571 4.017857 62 68
i 6 201.428571 4.017857 66 68
i 7 201.428571 0.803571 62 64
i 1 201.696429 0.267857 31 62
i 3 202.232143 0.133929 42 37
i 7 202.5 0.803571 59 61
i 1 202.767857 0.267857 31 62
i 4 202.767857 1.071429 74 50
i 3 203.303571 0.133929 42 37
i 7 203.571429 0.803571 57 58
i 1 203.839286 0.267857 31 62
i 3 204.375 0.133929 42 37
i 7 204.642857 0.803571 55 57
i 1 204.910714 0.267857 31 62
i 4 204.910714 0.669643 78 42
i 3 205.446429 0.133929 42 37
i 3 205.714286 0.133929 35 83
i 6 205.714286 4.017857 48 71
i 6 205.714286 4.017857 52 71
i 6 205.714286 4.017857 55 71
i 6 205.714286 4.017857 59 71
i 1 205.982143 0.267857 36 62
i 3 206.25 0.133929 42 34
i 4 206.517857 1.071429 76 53
i 7 206.785714 1.339286 60 58
i 7 206.785714 1.339286 64 58
i 7 206.785714 1.339286 67 58
i 1 207.053571 0.267857 36 62
i 3 207.321429 0.133929 38 54
i 3 207.321429 0.133929 42 34
i 3 207.857143 0.133929 35 77
i 1 208.125 0.267857 36 62
i 3 208.392857 0.133929 42 34
i 4 208.660714 1.071429 71 44
i 1 209.196429 0.267857 36 62
i 3 209.464286 0.133929 38 57
i 3 209.464286 0.133929 42 34
i 3 210 0.133929 35 66
i 6 210 4.017857 55 68
i 6 210 4.017857 59 68
i 6 210 4.017857 62 68
i 6 210 4.017857 66 68
i 1 210.267857 0.267857 31 62
i 3 210.803571 0.133929 42 37
i 1 211.339286 0.267857 31 62
i 4 211.339286 1.071429 74 50
i 7 211.607143 1.339286 55 59
i 7 211.607143 1.339286 59 59
i 7 211.607143 1.339286 62 59
i 3 211.875 0.133929 42 37
i 1 212.410714 0.267857 31 62
i 3 212.946429 0.133929 42 37
i 1 213.482143 0.267857 31 62
i 4 213.482143 0.669643 78 42
i 3 214.017857 0.133929 42 37
i 3 214.285714 0.133929 35 83
i 6 214.285714 4.017857 52 63
i 6 214.285714 4.017857 55 63
i 6 214.285714 4.017857 59 63
i 6 214.285714 4.017857 62 63
i 1 214.553571 0.267857 40 62
i 3 214.821429 0.133929 42 34
i 8 214.821429 1.071429 67 54
i 1 215.625 0.267857 40 62
i 3 215.892857 0.133929 38 54
i 3 215.892857 0.133929 42 34
i 4 215.892857 1.607143 71 46
i 7 215.892857 2.142857 64 42
i 3 216.428571 0.133929 35 77
i 8 216.428571 0.535714 66 49
i 1 216.696429 0.267857 40 62
i 3 216.964286 0.133929 42 34
i 8 217.5 0.803571 64 46
i 1 217.767857 0.267857 40 62
i 3 218.035714 0.133929 38 57
i 3 218.035714 0.133929 42 34
i 3 218.571429 0.133929 36 85
i 6 218.571429 4.017857 47 62
i 6 218.571429 4.017857 52 62
i 6 218.571429 4.017857 54 62
i 9 218.571429 4.017857 52 20
i 3 218.839286 0.133929 42 60
i 3 219.375 0.133929 42 60
i 3 219.910714 0.133929 42 60
i 3 220.178571 0.133929 38 77
i 3 220.446429 0.133929 42 60
i 3 220.714286 0.133929 36 88
i 3 220.982143 0.133929 42 60
i 4 221.25 1.071429 78 42
i 3 221.517857 0.133929 42 60
i 3 222.053571 0.133929 42 60
i 3 222.321429 0.133929 38 81
i 3 222.589286 0.133929 42 60
i 2 222.857143 4.017857 52 51
i 2 222.857143 4.017857 55 51
i 2 222.857143 4.017857 59 51
i 3 222.857143 0.133929 36 108
i 3 222.857143 0.133929 42 59
i 1 223.125 0.133929 40 99
i 3 223.125 0.133929 42 72
i 8 223.125 0.267857 76 85
i 1 223.258929 0.133929 40 77
i 3 223.392857 0.133929 38 102
i 3 223.392857 0.133929 42 59
i 1 223.660714 0.133929 40 82
i 3 223.660714 0.133929 42 72
i 1 223.794643 0.133929 40 73
i 3 223.794643 0.133929 42 40
i 5 223.794643 0.133929 52 78
i 3 223.928571 0.133929 36 99
i 3 223.928571 0.133929 42 59
i 8 223.928571 0.401786 79 78
i 1 224.196429 0.133929 40 99
i 3 224.196429 0.133929 42 72
i 1 224.330357 0.133929 40 85
i 3 224.464286 0.133929 38 105
i 3 224.464286 0.133929 42 59
i 1 224.732143 0.133929 52 74
i 3 224.732143 0.133929 46 52
i 8 224.732143 0.267857 78 82
i 1 224.866071 0.133929 40 81
i 3 224.866071 0.133929 42 43
i 3 225 0.133929 36 106
i 3 225 0.133929 42 59
i 1 225.267857 0.133929 40 99
i 3 225.267857 0.133929 42 72
i 5 225.267857 0.133929 52 69
i 1 225.401786 0.133929 40 77
i 3 225.401786 0.133929 38 43
i 3 225.535714 0.133929 38 101
i 3 225.535714 0.133929 42 59
i 8 225.535714 1.071429 71 81
i 1 225.803571 0.133929 40 82
i 3 225.803571 0.133929 42 72
i 3 225.9375 0.133929 36 69
i 3 226.071429 0.133929 36 101
i 3 226.071429 0.133929 42 59
i 1 226.339286 0.133929 40 99
i 3 226.339286 0.133929 42 72
i 1 226.473214 0.133929 40 85
i 3 226.473214 0.133929 42 44
i 5 226.473214 0.133929 52 60
i 3 226.607143 0.133929 38 108
i 3 226.607143 0.133929 42 59
i 1 226.741071 0.133929 40 83
i 1 226.875 0.133929 52 74
i 3 226.875 0.133929 46 57
i 3 227.008929 0.133929 42 40
i 3 227.142857 0.133929 36 108
i 3 227.142857 0.133929 42 59
i 6 227.142857 4.017857 48 54
i 6 227.142857 4.017857 52 54
i 6 227.142857 4.017857 55 54
i 6 227.142857 4.017857 59 54
i 1 227.410714 0.133929 36 99
i 3 227.410714 0.133929 42 72
i 8 227.410714 0.535714 67 79
i 1 227.544643 0.133929 36 77
i 3 227.678571 0.133929 38 102
i 3 227.678571 0.133929 42 59
i 1 227.946429 0.133929 36 82
i 3 227.946429 0.133929 42 72
i 3 228.080357 0.133929 42 40
i 5 228.080357 0.133929 48 76
i 3 228.214286 0.133929 36 99
i 3 228.214286 0.133929 42 59
i 8 228.214286 0.535714 71 83
i 1 228.482143 0.133929 36 99
i 3 228.482143 0.133929 42 72
i 1 228.616071 0.133929 36 85
i 3 228.75 0.133929 38 105
i 3 228.75 0.133929 42 59
i 1 229.017857 0.133929 48 74
i 3 229.017857 0.133929 46 52
i 3 229.151786 0.133929 42 43
i 3 229.285714 0.133929 36 106
i 3 229.285714 0.133929 42 59
i 8 229.285714 0.401786 69 78
i 1 229.553571 0.133929 36 99
i 3 229.553571 0.133929 42 72
i 5 229.553571 0.133929 48 67
i 1 229.6875 0.133929 36 77
i 3 229.6875 0.133929 38 43
i 3 229.821429 0.133929 38 101
i 3 229.821429 0.133929 42 59
i 1 230.089286 0.133929 36 82
i 3 230.089286 0.133929 42 72
i 3 230.223214 0.133929 36 69
i 3 230.357143 0.133929 36 101
i 3 230.357143 0.133929 42 59
i 8 230.357143 0.803571 67 72
i 1 230.625 0.133929 36 99
i 3 230.625 0.133929 42 72
i 1 230.758929 0.133929 36 85
i 3 230.758929 0.133929 42 44
i 5 230.758929 0.133929 48 58
i 3 230.892857 0.133929 38 108
i 3 230.892857 0.133929 42 59
i 1 231.160714 0.133929 48 74
i 3 231.160714 0.133929 46 57
i 3 231.294643 0.133929 42 40
i 2 231.428571 4.017857 45 49
i 2 231.428571 4.017857 48 49
i 2 231.428571 4.017857 52 49
i 3 231.428571 0.133929 36 108
i 3 231.428571 0.133929 42 59
i 1 231.696429 0.133929 33 99
i 3 231.696429 0.133929 42 72
i 8 231.696429 0.535714 64 77
i 1 231.830357 0.133929 33 77
i 3 231.964286 0.133929 38 102
i 3 231.964286 0.133929 42 59
i 1 232.232143 0.133929 33 82
i 3 232.232143 0.133929 42 72
i 3 232.366071 0.133929 42 40
i 5 232.366071 0.133929 45 78
i 3 232.5 0.133929 36 99
i 3 232.5 0.133929 42 59
i 8 232.5 0.535714 69 82
i 1 232.767857 0.133929 33 99
i 3 232.767857 0.133929 42 72
i 1 232.901786 0.133929 33 85
i 3 233.035714 0.133929 38 105
i 3 233.035714 0.133929 42 59
i 1 233.303571 0.133929 45 74
i 3 233.303571 0.133929 46 52
i 3 233.4375 0.133929 42 43
i 3 233.571429 0.133929 36 106
i 3 233.571429 0.133929 42 59
i 8 233.571429 0.401786 67 75
i 1 233.839286 0.133929 33 99
i 3 233.839286 0.133929 42 72
i 5 233.839286 0.133929 45 69
i 1 233.973214 0.133929 33 77
i 3 233.973214 0.133929 38 43
i 3 234.107143 0.133929 38 101
i 3 234.107143 0.133929 42 59
i 1 234.375 0.133929 33 82
i 3 234.375 0.133929 42 72
i 3 234.508929 0.133929 36 69
i 3 234.642857 0.133929 36 101
i 3 234.642857 0.133929 42 59
i 8 234.642857 0.803571 64 72
i 1 234.910714 0.133929 33 99
i 3 234.910714 0.133929 42 72
i 1 235.044643 0.133929 33 85
i 3 235.044643 0.133929 42 44
i 5 235.044643 0.133929 45 60
i 3 235.178571 0.133929 38 108
i 3 235.178571 0.133929 42 59
i 1 235.446429 0.133929 45 74
i 3 235.446429 0.133929 46 57
i 3 235.580357 0.133929 42 40
i 2 235.714286 4.017857 47 49
i 2 235.714286 4.017857 52 49
i 2 235.714286 4.017857 54 49
i 3 235.714286 0.133929 36 108
i 3 235.714286 0.133929 42 59
i 8 235.714286 0.535714 66 82
i 1 235.982143 0.133929 35 99
i 3 235.982143 0.133929 42 72
i 1 236.116071 0.133929 35 77
i 3 236.25 0.133929 38 102
i 3 236.25 0.133929 42 59
i 1 236.517857 0.133929 35 82
i 3 236.517857 0.133929 42 72
i 5 236.651786 0.133929 52 85
i 3 236.785714 0.133929 36 99
i 3 236.785714 0.133929 42 59
i 8 236.785714 0.401786 64 76
i 1 237.053571 0.133929 35 99
i 3 237.053571 0.133929 42 72
i 1 237.1875 0.133929 35 85
i 3 237.321429 0.133929 38 105
i 3 237.321429 0.133929 42 59
i 1 237.589286 0.133929 47 74
i 3 237.589286 0.133929 46 52
i 8 237.589286 0.535714 59 78
i 3 237.857143 0.133929 36 106
i 3 237.857143 0.133929 42 59
i 1 238.125 0.133929 35 99
i 3 238.125 0.133929 42 72
i 1 238.258929 0.133929 35 77
i 3 238.392857 0.133929 38 101
i 3 238.392857 0.133929 42 59
i 1 238.660714 0.133929 35 82
i 3 238.660714 0.133929 42 72
i 8 238.660714 1.071429 66 83
i 5 238.794643 0.133929 52 76
i 3 238.928571 0.133929 36 101
i 3 238.928571 0.133929 42 59
i 1 239.196429 0.133929 35 99
i 3 239.196429 0.133929 38 65
i 3 239.196429 0.133929 42 72
i 5 239.196429 0.133929 52 67
i 1 239.330357 0.133929 35 85
i 3 239.464286 0.133929 38 108
i 3 239.464286 0.133929 42 59
i 1 239.732143 0.133929 47 74
i 3 239.732143 0.133929 38 80
i 3 239.732143 0.133929 46 57
i 5 239.732143 0.133929 52 85
i 3 239.866071 0.133929 38 49
i 2 240 4.017857 52 51
i 2 240 4.017857 55 51
i 2 240 4.017857 59 51
i 3 240 0.133929 36 108
i 3 240 0.133929 42 59
i 8 240 0.535714 69 82
i 1 240.267857 0.133929 40 99
i 3 240.267857 0.133929 42 72
i 1 240.401786 0.133929 40 77
i 3 240.535714 0.133929 38 102
i 3 240.535714 0.133929 42 59
i 1 240.803571 0.133929 40 82
i 3 240.803571 0.133929 42 72
i 8 240.803571 0.535714 67 78
i 1 240.9375 0.133929 40 73
i 5 240.9375 0.133929 52 78
i 3 241.071429 0.133929 36 99
i 3 241.071429 0.133929 42 59
i 1 241.339286 0.133929 40 99
i 3 241.339286 0.133929 42 72
i 1 241.473214 0.133929 40 85
i 3 241.607143 0.133929 38 105
i 3 241.607143 0.133929 42 59
i 8 241.607143 0.401786 66 85
i 1 241.875 0.133929 52 74
i 3 241.875 0.133929 46 52
i 1 242.008929 0.133929 40 81
i 3 242.142857 0.133929 36 106
i 3 242.142857 0.133929 42 59
i 1 242.410714 0.133929 40 99
i 3 242.410714 0.133929 42 72
i 5 242.410714 0.133929 52 69
i 1 242.544643 0.133929 40 77
i 3 242.678571 0.133929 38 101
i 3 242.678571 0.133929 42 59
i 1 242.946429 0.133929 40 82
i 3 242.946429 0.133929 42 72
i 8 242.946429 0.803571 64 75
i 3 243.214286 0.133929 36 101
i 3 243.214286 0.133929 42 59
i 1 243.482143 0.133929 40 99
i 3 243.482143 0.133929 42 72
i 1 243.616071 0.133929 40 85
i 5 243.616071 0.133929 52 60
i 3 243.75 0.133929 38 108
i 3 243.75 0.133929 42 59
i 1 243.883929 0.133929 40 83
i 1 244.017857 0.133929 52 74
i 3 244.017857 0.133929 46 57
i 3 244.285714 0.133929 36 108
i 3 244.285714 0.133929 42 59
i 6 244.285714 4.017857 48 54
i 6 244.285714 4.017857 52 54
i 6 244.285714 4.017857 55 54
i 6 244.285714 4.017857 59 54
i 1 244.553571 0.133929 36 99
i 3 244.553571 0.133929 42 72
i 8 244.553571 0.535714 67 79
i 1 244.6875 0.133929 36 77
i 3 244.821429 0.133929 38 102
i 3 244.821429 0.133929 42 59
i 1 245.089286 0.133929 36 82
i 3 245.089286 0.133929 42 72
i 3 245.223214 0.133929 42 40
i 3 245.357143 0.133929 36 99
i 3 245.357143 0.133929 42 59
i 7 245.357143 0.803571 64 70
i 8 245.357143 0.535714 71 83
i 1 245.625 0.133929 36 99
i 3 245.625 0.133929 42 72
i 1 245.758929 0.133929 36 85
i 3 245.892857 0.133929 38 105
i 3 245.892857 0.133929 42 59
i 1 246.160714 0.133929 48 74
i 3 246.160714 0.133929 46 52
i 3 246.294643 0.133929 42 43
i 3 246.428571 0.133929 36 106
i 3 246.428571 0.133929 42 59
i 8 246.428571 0.401786 69 78
i 1 246.696429 0.133929 36 99
i 3 246.696429 0.133929 42 72
i 1 246.830357 0.133929 36 77
i 3 246.830357 0.133929 38 43
i 3 246.964286 0.133929 38 101
i 3 246.964286 0.133929 42 59
i 7 246.964286 1.071429 67 65
i 1 247.232143 0.133929 36 82
i 3 247.232143 0.133929 42 72
i 3 247.366071 0.133929 36 69
i 3 247.5 0.133929 36 101
i 3 247.5 0.133929 42 59
i 8 247.5 0.803571 67 72
i 1 247.767857 0.133929 36 99
i 3 247.767857 0.133929 42 72
i 1 247.901786 0.133929 36 85
i 3 247.901786 0.133929 42 44
i 3 248.035714 0.133929 38 108
i 3 248.035714 0.133929 42 59
i 1 248.303571 0.133929 48 74
i 3 248.303571 0.133929 46 57
i 3 248.4375 0.133929 42 40
i 2 248.571429 4.017857 45 49
i 2 248.571429 4.017857 48 49
i 2 248.571429 4.017857 52 49
i 3 248.571429 0.133929 36 108
i 3 248.571429 0.133929 42 59
i 1 248.839286 0.133929 33 99
i 3 248.839286 0.133929 42 72
i 8 248.839286 0.535714 64 77
i 1 248.973214 0.133929 33 77
i 3 249.107143 0.133929 38 102
i 3 249.107143 0.133929 42 59
i 1 249.375 0.133929 33 82
i 3 249.375 0.133929 42 72
i 3 249.508929 0.133929 42 40
i 5 249.508929 0.133929 45 78
i 3 249.642857 0.133929 36 99
i 3 249.642857 0.133929 42 59
i 8 249.642857 0.535714 69 82
i 1 249.910714 0.133929 33 99
i 3 249.910714 0.133929 42 72
i 1 250.044643 0.133929 33 85
i 3 250.178571 0.133929 38 105
i 3 250.178571 0.133929 42 59
i 1 250.446429 0.133929 45 74
i 3 250.446429 0.133929 46 52
i 3 250.580357 0.133929 42 43
i 3 250.714286 0.133929 36 106
i 3 250.714286 0.133929 42 59
i 8 250.714286 0.401786 67 75
i 1 250.982143 0.133929 33 99
i 3 250.982143 0.133929 42 72
i 5 250.982143 0.133929 45 69
i 1 251.116071 0.133929 33 77
i 3 251.116071 0.133929 38 43
i 3 251.25 0.133929 38 101
i 3 251.25 0.133929 42 59
i 1 251.517857 0.133929 33 82
i 3 251.517857 0.133929 42 72
i 3 251.651786 0.133929 36 69
i 3 251.785714 0.133929 36 101
i 3 251.785714 0.133929 42 59
i 8 251.785714 0.803571 64 72
i 1 252.053571 0.133929 33 99
i 3 252.053571 0.133929 42 72
i 1 252.1875 0.133929 33 85
i 3 252.1875 0.133929 42 44
i 5 252.1875 0.133929 45 60
i 3 252.321429 0.133929 38 108
i 3 252.321429 0.133929 42 59
i 1 252.589286 0.133929 45 74
i 3 252.589286 0.133929 46 57
i 3 252.723214 0.133929 42 40
i 3 252.857143 0.133929 36 108
i 3 252.857143 0.133929 42 59
i 1 253.125 0.133929 35 99
i 3 253.125 0.133929 42 72
i 1 253.258929 0.133929 35 77
i 3 253.392857 0.133929 38 102
i 3 253.392857 0.133929 42 59
i 1 253.660714 0.133929 35 82
i 3 253.660714 0.133929 42 72
i 5 253.794643 0.133929 47 77
i 3 253.928571 0.133929 36 99
i 3 253.928571 0.133929 42 59
i 1 254.196429 0.133929 35 99
i 3 254.196429 0.133929 42 72
i 1 254.330357 0.133929 35 85
i 3 254.464286 0.133929 38 105
i 3 254.464286 0.133929 42 59
i 1 254.732143 0.133929 47 74
i 3 254.732143 0.133929 46 52
i 3 255 0.133929 36 106
i 3 255 0.133929 42 59
i 9 255 1.875 64 38
i 1 255.267857 0.133929 35 99
i 3 255.267857 0.133929 42 72
i 5 255.267857 0.133929 47 68
i 1 255.401786 0.133929 35 77
i 3 255.535714 0.133929 38 101
i 3 255.535714 0.133929 42 59
i 1 255.803571 0.133929 35 82
i 3 255.803571 0.133929 42 72
i 3 256.071429 0.133929 36 101
i 3 256.071429 0.133929 42 59
i 1 256.339286 0.133929 35 99
i 3 256.339286 0.133929 38 65
i 3 256.339286 0.133929 42 72
i 1 256.473214 0.133929 35 85
i 5 256.473214 0.133929 47 59
i 3 256.607143 0.133929 38 108
i 3 256.607143 0.133929 42 59
i 1 256.875 0.133929 47 74
i 3 256.875 0.133929 38 80
i 3 256.875 0.133929 46 57
i 3 257.008929 0.133929 38 49
i 2 257.142857 4.017857 52 51
i 2 257.142857 4.017857 55 51
i 2 257.142857 4.017857 59 51
i 3 257.142857 0.133929 36 108
i 3 257.142857 0.133929 42 59
i 6 257.142857 4.017857 52 63
i 6 257.142857 4.017857 55 63
i 6 257.142857 4.017857 59 63
i 6 257.142857 4.017857 62 63
i 1 257.410714 0.133929 40 99
i 3 257.410714 0.133929 42 72
i 8 257.410714 0.267857 64 86
i 1 257.544643 0.133929 40 77
i 3 257.678571 0.133929 38 102
i 3 257.678571 0.133929 42 59
i 1 257.946429 0.133929 40 82
i 3 257.946429 0.133929 42 72
i 1 258.080357 0.133929 40 73
i 3 258.080357 0.133929 42 40
i 5 258.080357 0.133929 52 78
i 3 258.214286 0.133929 36 99
i 3 258.214286 0.133929 42 59
i 8 258.214286 0.401786 67 76
i 1 258.482143 0.133929 40 99
i 3 258.482143 0.133929 42 72
i 1 258.616071 0.133929 40 85
i 3 258.75 0.133929 38 105
i 3 258.75 0.133929 42 59
i 1 259.017857 0.133929 52 74
i 3 259.017857 0.133929 46 52
i 8 259.017857 0.267857 66 81
i 1 259.151786 0.133929 40 81
i 3 259.151786 0.133929 42 43
i 3 259.285714 0.133929 36 106
i 3 259.285714 0.133929 42 59
i 1 259.553571 0.133929 40 99
i 3 259.553571 0.133929 42 72
i 5 259.553571 0.133929 52 69
i 1 259.6875 0.133929 40 77
i 3 259.6875 0.133929 38 43
i 3 259.821429 0.133929 38 101
i 3 259.821429 0.133929 42 59
i 8 259.821429 1.071429 71 84
i 1 260.089286 0.133929 40 82
i 3 260.089286 0.133929 42 72
i 3 260.223214 0.133929 36 69
i 3 260.357143 0.133929 36 101
i 3 260.357143 0.133929 42 59
i 1 260.625 0.133929 40 99
i 3 260.625 0.133929 42 72
i 1 260.758929 0.133929 40 85
i 3 260.758929 0.133929 42 44
i 5 260.758929 0.133929 52 60
i 3 260.892857 0.133929 38 108
i 3 260.892857 0.133929 42 59
i 1 261.026786 0.133929 40 83
i 1 261.160714 0.133929 52 74
i 3 261.160714 0.133929 46 57
i 3 261.294643 0.133929 42 40
i 3 261.428571 0.133929 36 108
i 3 261.428571 0.133929 42 59
i 6 261.428571 4.017857 48 54
i 6 261.428571 4.017857 52 54
i 6 261.428571 4.017857 55 54
i 6 261.428571 4.017857 59 54
i 1 261.696429 0.133929 36 99
i 3 261.696429 0.133929 42 72
i 8 261.696429 0.535714 67 79
i 1 261.830357 0.133929 36 77
i 3 261.964286 0.133929 38 102
i 3 261.964286 0.133929 42 59
i 1 262.232143 0.133929 36 82
i 3 262.232143 0.133929 42 72
i 4 262.232143 1.071429 76 53
i 3 262.366071 0.133929 42 40
i 5 262.366071 0.133929 48 76
i 3 262.5 0.133929 36 99
i 3 262.5 0.133929 42 59
i 7 262.5 1.339286 60 58
i 7 262.5 1.339286 64 58
i 7 262.5 1.339286 67 58
i 8 262.5 0.535714 71 83
i 1 262.767857 0.133929 36 99
i 3 262.767857 0.133929 42 72
i 1 262.901786 0.133929 36 85
i 3 263.035714 0.133929 38 105
i 3 263.035714 0.133929 42 59
i 1 263.303571 0.133929 48 74
i 3 263.303571 0.133929 46 52
i 3 263.4375 0.133929 42 43
i 3 263.571429 0.133929 36 106
i 3 263.571429 0.133929 42 59
i 8 263.571429 0.401786 69 78
i 1 263.839286 0.133929 36 99
i 3 263.839286 0.133929 42 72
i 5 263.839286 0.133929 48 67
i 1 263.973214 0.133929 36 77
i 3 263.973214 0.133929 38 43
i 3 264.107143 0.133929 38 101
i 3 264.107143 0.133929 42 59
i 1 264.375 0.133929 36 82
i 3 264.375 0.133929 42 72
i 4 264.375 1.071429 71 44
i 3 264.508929 0.133929 36 69
i 3 264.642857 0.133929 36 101
i 3 264.642857 0.133929 42 59
i 8 264.642857 0.803571 67 72
i 1 264.910714 0.133929 36 99
i 3 264.910714 0.133929 42 72
i 1 265.044643 0.133929 36 85
i 3 265.044643 0.133929 42 44
i 5 265.044643 0.133929 48 58
i 3 265.178571 0.133929 38 108
i 3 265.178571 0.133929 42 59
i 1 265.446429 0.133929 48 74
i 3 265.446429 0.133929 46 57
i 3 265.580357 0.133929 42 40
i 2 265.714286 4.017857 45 49
i 2 265.714286 4.017857 48 49
i 2 265.714286 4.017857 52 49
i 3 265.714286 0.133929 36 108
i 3 265.714286 0.133929 42 59
i 1 265.982143 0.133929 33 99
i 3 265.982143 0.133929 42 72
i 8 265.982143 0.535714 64 77
i 1 266.116071 0.133929 33 77
i 3 266.25 0.133929 38 102
i 3 266.25 0.133929 42 59
i 1 266.517857 0.133929 33 82
i 3 266.517857 0.133929 42 72
i 3 266.651786 0.133929 42 40
i 5 266.651786 0.133929 45 78
i 3 266.785714 0.133929 36 99
i 3 266.785714 0.133929 42 59
i 8 266.785714 0.535714 69 82
i 1 267.053571 0.133929 33 99
i 3 267.053571 0.133929 42 72
i 1 267.1875 0.133929 33 85
i 3 267.321429 0.133929 38 105
i 3 267.321429 0.133929 42 59
i 1 267.589286 0.133929 45 74
i 3 267.589286 0.133929 46 52
i 3 267.723214 0.133929 42 43
i 3 267.857143 0.133929 36 106
i 3 267.857143 0.133929 42 59
i 8 267.857143 0.401786 67 75
i 1 268.125 0.133929 33 99
i 3 268.125 0.133929 42 72
i 5 268.125 0.133929 45 69
i 1 268.258929 0.133929 33 77
i 3 268.258929 0.133929 38 43
i 3 268.392857 0.133929 38 101
i 3 268.392857 0.133929 42 59
i 1 268.660714 0.133929 33 82
i 3 268.660714 0.133929 42 72
i 3 268.794643 0.133929 36 69
i 3 268.928571 0.133929 36 101
i 3 268.928571 0.133929 42 59
i 8 268.928571 0.803571 64 72
i 1 269.196429 0.133929 33 99
i 3 269.196429 0.133929 42 72
i 1 269.330357 0.133929 33 85
i 3 269.330357 0.133929 42 44
i 5 269.330357 0.133929 45 60
i 3 269.464286 0.133929 38 108
i 3 269.464286 0.133929 42 59
i 1 269.732143 0.133929 45 74
i 3 269.732143 0.133929 46 57
i 3 269.866071 0.133929 42 40
i 2 270 4.017857 47 49
i 2 270 4.017857 52 49
i 2 270 4.017857 54 49
i 3 270 0.133929 36 108
i 3 270 0.133929 42 59
i 6 270 4.017857 47 62
i 6 270 4.017857 52 62
i 6 270 4.017857 54 62
i 8 270 0.535714 66 82
i 1 270.267857 0.133929 35 99
i 3 270.267857 0.133929 42 72
i 1 270.401786 0.133929 35 77
i 3 270.535714 0.133929 38 102
i 3 270.535714 0.133929 42 59
i 1 270.803571 0.133929 35 82
i 3 270.803571 0.133929 42 72
i 5 270.9375 0.133929 52 85
i 3 271.071429 0.133929 36 99
i 3 271.071429 0.133929 42 59
i 8 271.071429 0.401786 64 76
i 1 271.339286 0.133929 35 99
i 3 271.339286 0.133929 42 72
i 1 271.473214 0.133929 35 85
i 3 271.607143 0.133929 38 105
i 3 271.607143 0.133929 42 59
i 1 271.875 0.133929 47 74
i 3 271.875 0.133929 46 52
i 8 271.875 0.535714 59 78
i 3 272.142857 0.133929 36 106
i 3 272.142857 0.133929 42 59
i 1 272.410714 0.133929 35 99
i 3 272.410714 0.133929 42 72
i 1 272.544643 0.133929 35 77
i 3 272.678571 0.133929 38 101
i 3 272.678571 0.133929 42 59
i 4 272.678571 1.071429 78 42
i 1 272.946429 0.133929 35 82
i 3 272.946429 0.133929 42 72
i 8 272.946429 1.071429 66 83
i 5 273.080357 0.133929 52 76
i 3 273.214286 0.133929 36 101
i 3 273.214286 0.133929 42 59
i 1 273.482143 0.133929 35 99
i 3 273.482143 0.133929 38 65
i 3 273.482143 0.133929 42 72
i 5 273.482143 0.133929 52 67
i 1 273.616071 0.133929 35 85
i 3 273.75 0.133929 38 108
i 3 273.75 0.133929 42 59
i 1 274.017857 0.133929 47 74
i 3 274.017857 0.133929 38 80
i 3 274.017857 0.133929 46 57
i 5 274.017857 0.133929 52 85
i 3 274.151786 0.133929 38 49
i 2 274.285714 4.017857 52 51
i 2 274.285714 4.017857 55 51
i 2 274.285714 4.017857 59 51
i 3 274.285714 0.133929 36 108
i 3 274.285714 0.133929 42 59
i 6 274.285714 4.017857 52 63
i 6 274.285714 4.017857 55 63
i 6 274.285714 4.017857 59 63
i 6 274.285714 4.017857 62 63
i 8 274.285714 0.535714 69 82
i 1 274.553571 0.133929 40 99
i 3 274.553571 0.133929 42 72
i 1 274.6875 0.133929 40 77
i 3 274.821429 0.133929 38 102
i 3 274.821429 0.133929 42 59
i 1 275.089286 0.133929 40 82
i 3 275.089286 0.133929 42 72
i 8 275.089286 0.535714 67 78
i 5 275.223214 0.133929 52 78
i 3 275.357143 0.133929 36 99
i 3 275.357143 0.133929 42 59
i 1 275.625 0.133929 40 99
i 3 275.625 0.133929 42 72
i 1 275.758929 0.133929 40 85
i 3 275.892857 0.133929 38 105
i 3 275.892857 0.133929 42 59
i 8 275.892857 0.401786 66 85
i 1 276.160714 0.133929 52 74
i 3 276.160714 0.133929 46 52
i 3 276.428571 0.133929 36 106
i 3 276.428571 0.133929 42 59
i 1 276.696429 0.133929 40 99
i 3 276.696429 0.133929 42 72
i 5 276.696429 0.133929 52 69
i 1 276.830357 0.133929 40 77
i 3 276.964286 0.133929 38 101
i 3 276.964286 0.133929 42 59
i 1 277.232143 0.133929 40 82
i 3 277.232143 0.133929 42 72
i 8 277.232143 0.803571 64 75
i 3 277.5 0.133929 36 101
i 3 277.5 0.133929 42 59
i 1 277.767857 0.133929 40 99
i 3 277.767857 0.133929 42 72
i 1 277.901786 0.133929 40 85
i 5 277.901786 0.133929 52 60
i 3 278.035714 0.133929 38 108
i 3 278.035714 0.133929 42 59
i 1 278.303571 0.133929 52 74
i 3 278.303571 0.133929 46 57
i 3 278.571429 0.133929 36 108
i 3 278.571429 0.133929 42 59
i 6 278.571429 4.017857 48 54
i 6 278.571429 4.017857 52 54
i 6 278.571429 4.017857 55 54
i 6 278.571429 4.017857 59 54
i 1 278.839286 0.133929 36 99
i 3 278.839286 0.133929 42 72
i 1 278.973214 0.133929 36 77
i 3 279.107143 0.133929 38 102
i 3 279.107143 0.133929 42 59
i 1 279.375 0.133929 36 82
i 3 279.375 0.133929 42 72
i 4 279.375 1.071429 76 53
i 3 279.508929 0.133929 42 40
i 3 279.642857 0.133929 36 99
i 3 279.642857 0.133929 42 59
i 7 279.642857 0.803571 64 70
i 1 279.910714 0.133929 36 99
i 3 279.910714 0.133929 42 72
i 1 280.044643 0.133929 36 85
i 3 280.178571 0.133929 38 105
i 3 280.178571 0.133929 42 59
i 1 280.446429 0.133929 48 74
i 3 280.446429 0.133929 46 52
i 3 280.580357 0.133929 42 43
i 3 280.714286 0.133929 36 106
i 3 280.714286 0.133929 42 59
i 1 280.982143 0.133929 36 99
i 3 280.982143 0.133929 42 72
i 1 281.116071 0.133929 36 77
i 3 281.116071 0.133929 38 43
i 3 281.25 0.133929 38 101
i 3 281.25 0.133929 42 59
i 7 281.25 1.071429 67 65
i 1 281.517857 0.133929 36 82
i 3 281.517857 0.133929 42 72
i 4 281.517857 1.071429 71 44
i 3 281.651786 0.133929 36 69
i 3 281.785714 0.133929 36 101
i 3 281.785714 0.133929 42 59
i 1 282.053571 0.133929 36 99
i 3 282.053571 0.133929 42 72
i 1 282.1875 0.133929 36 85
i 3 282.1875 0.133929 42 44
i 3 282.321429 0.133929 38 108
i 3 282.321429 0.133929 42 59
i 1 282.589286 0.133929 48 74
i 3 282.589286 0.133929 46 57
i 3 282.723214 0.133929 42 40
i 2 282.857143 4.017857 45 49
i 2 282.857143 4.017857 48 49
i 2 282.857143 4.017857 52 49
i 3 282.857143 0.133929 36 108
i 3 282.857143 0.133929 42 59
i 1 283.125 0.133929 33 99
i 3 283.125 0.133929 42 72
i 1 283.258929 0.133929 33 77
i 3 283.392857 0.133929 38 102
i 3 283.392857 0.133929 42 59
i 8 283.392857 1.071429 67 54
i 1 283.660714 0.133929 33 82
i 3 283.660714 0.133929 42 72
i 3 283.794643 0.133929 42 40
i 5 283.794643 0.133929 45 78
i 3 283.928571 0.133929 36 99
i 3 283.928571 0.133929 42 59
i 1 284.196429 0.133929 33 99
i 3 284.196429 0.133929 42 72
i 1 284.330357 0.133929 33 85
i 3 284.464286 0.133929 38 105
i 3 284.464286 0.133929 42 59
i 1 284.732143 0.133929 45 74
i 3 284.732143 0.133929 46 52
i 3 284.866071 0.133929 42 43
i 3 285 0.133929 36 106
i 3 285 0.133929 42 59
i 8 285 0.535714 66 49
i 1 285.267857 0.133929 33 99
i 3 285.267857 0.133929 42 72
i 5 285.267857 0.133929 45 69
i 1 285.401786 0.133929 33 77
i 3 285.401786 0.133929 38 43
i 3 285.535714 0.133929 38 101
i 3 285.535714 0.133929 42 59
i 1 285.803571 0.133929 33 82
i 3 285.803571 0.133929 42 72
i 3 285.9375 0.133929 36 69
i 3 286.071429 0.133929 36 101
i 3 286.071429 0.133929 42 59
i 8 286.071429 0.803571 64 46
i 1 286.339286 0.133929 33 99
i 3 286.339286 0.133929 42 72
i 1 286.473214 0.133929 33 85
i 3 286.473214 0.133929 42 44
i 5 286.473214 0.133929 45 60
i 3 286.607143 0.133929 38 108
i 3 286.607143 0.133929 42 59
i 1 286.875 0.133929 45 74
i 3 286.875 0.133929 46 57
i 3 287.008929 0.133929 42 40
i 3 287.142857 0.133929 36 108
i 3 287.142857 0.133929 42 59
i 1 287.410714 0.133929 35 99
i 3 287.410714 0.133929 42 72
i 1 287.544643 0.133929 35 77
i 3 287.678571 0.133929 38 102
i 3 287.678571 0.133929 42 59
i 1 287.946429 0.133929 35 82
i 3 287.946429 0.133929 42 72
i 5 288.080357 0.133929 47 77
i 3 288.214286 0.133929 36 99
i 3 288.214286 0.133929 42 59
i 1 288.482143 0.133929 35 99
i 3 288.482143 0.133929 42 72
i 1 288.616071 0.133929 35 85
i 3 288.75 0.133929 38 105
i 3 288.75 0.133929 42 59
i 1 289.017857 0.133929 47 74
i 3 289.017857 0.133929 46 52
i 3 289.285714 0.133929 36 106
i 3 289.285714 0.133929 42 59
i 1 289.553571 0.133929 35 99
i 3 289.553571 0.133929 42 72
i 5 289.553571 0.133929 47 68
i 1 289.6875 0.133929 35 77
i 3 289.821429 0.133929 38 101
i 3 289.821429 0.133929 42 59
i 1 290.089286 0.133929 35 82
i 3 290.089286 0.133929 42 72
i 3 290.357143 0.133929 36 101
i 3 290.357143 0.133929 42 59
i 1 290.625 0.133929 35 99
i 3 290.625 0.133929 38 65
i 3 290.625 0.133929 42 72
i 1 290.758929 0.133929 35 85
i 5 290.758929 0.133929 47 59
i 3 290.892857 0.133929 38 108
i 3 290.892857 0.133929 42 59
i 1 291.160714 0.133929 47 74
i 3 291.160714 0.133929 38 80
i 3 291.160714 0.133929 46 57
i 3 291.294643 0.133929 38 49
i 2 291.428571 4.017857 52 51
i 2 291.428571 4.017857 55 51
i 2 291.428571 4.017857 59 51
i 3 291.428571 0.133929 36 108
i 3 291.428571 0.133929 42 59
i 1 291.696429 0.133929 40 99
i 3 291.696429 0.133929 42 72
i 8 291.696429 0.267857 64 86
i 1 291.830357 0.133929 40 77
i 3 291.964286 0.133929 38 102
i 3 291.964286 0.133929 42 59
i 1 292.232143 0.133929 40 82
i 3 292.232143 0.133929 42 72
i 3 292.5 0.133929 36 99
i 3 292.5 0.133929 42 59
i 8 292.5 0.401786 67 76
i 1 292.767857 0.133929 40 99
i 3 292.767857 0.133929 42 72
i 1 292.901786 0.133929 40 85
i 5 292.901786 0.133929 52 60
i 3 293.035714 0.133929 38 105
i 3 293.035714 0.133929 42 59
i 1 293.303571 0.133929 52 74
i 3 293.303571 0.133929 46 52
i 8 293.303571 0.267857 66 81
i 3 293.571429 0.133929 36 106
i 3 293.571429 0.133929 42 59
i 1 293.839286 0.133929 40 99
i 3 293.839286 0.133929 42 72
i 1 293.973214 0.133929 40 77
i 3 294.107143 0.133929 38 101
i 3 294.107143 0.133929 42 59
i 8 294.107143 1.071429 71 84
i 1 294.375 0.133929 40 82
i 3 294.375 0.133929 42 72
i 3 294.642857 0.133929 36 101
i 3 294.642857 0.133929 42 59
i 1 294.910714 0.133929 40 99
i 3 294.910714 0.133929 42 72
i 1 295.044643 0.133929 40 85
i 5 295.044643 0.133929 52 51
i 3 295.178571 0.133929 38 108
i 3 295.178571 0.133929 42 59
i 1 295.446429 0.133929 52 74
i 3 295.446429 0.133929 46 57
i 3 295.714286 0.133929 36 108
i 3 295.714286 0.133929 42 59
i 6 295.714286 4.017857 48 54
i 6 295.714286 4.017857 52 54
i 6 295.714286 4.017857 55 54
i 6 295.714286 4.017857 59 54
i 1 295.982143 0.133929 36 99
i 3 295.982143 0.133929 42 72
i 1 296.116071 0.133929 36 77
i 3 296.25 0.133929 38 102
i 3 296.25 0.133929 42 59
i 1 296.517857 0.133929 36 82
i 3 296.517857 0.133929 42 72
i 3 296.785714 0.133929 36 99
i 3 296.785714 0.133929 42 59
i 7 296.785714 0.803571 64 70
i 1 297.053571 0.133929 36 99
i 3 297.053571 0.133929 42 72
i 1 297.1875 0.133929 36 85
i 3 297.321429 0.133929 38 105
i 3 297.321429 0.133929 42 59
i 1 297.589286 0.133929 48 74
i 3 297.589286 0.133929 46 52
i 3 297.857143 0.133929 36 106
i 3 297.857143 0.133929 42 59
i 1 298.125 0.133929 36 99
i 3 298.125 0.133929 42 72
i 1 298.258929 0.133929 36 77
i 3 298.392857 0.133929 38 101
i 3 298.392857 0.133929 42 59
i 7 298.392857 1.071429 67 65
i 1 298.660714 0.133929 36 82
i 3 298.660714 0.133929 42 72
i 3 298.928571 0.133929 36 101
i 3 298.928571 0.133929 42 59
i 1 299.196429 0.133929 36 99
i 3 299.196429 0.133929 42 72
i 1 299.330357 0.133929 36 85
i 3 299.464286 0.133929 38 108
i 3 299.464286 0.133929 42 59
i 1 299.732143 0.133929 48 74
i 3 299.732143 0.133929 46 57
i 2 300 4.017857 45 49
i 2 300 4.017857 48 49
i 2 300 4.017857 52 49
i 3 300 0.133929 36 108
i 3 300 0.133929 42 59
i 1 300.267857 0.133929 33 99
i 3 300.267857 0.133929 42 72
i 8 300.267857 0.535714 64 77
i 1 300.401786 0.133929 33 77
i 3 300.535714 0.133929 38 102
i 3 300.535714 0.133929 42 59
i 1 300.803571 0.133929 33 82
i 3 300.803571 0.133929 42 72
i 5 300.9375 0.133929 45 78
i 3 301.071429 0.133929 36 99
i 3 301.071429 0.133929 42 59
i 8 301.071429 0.535714 69 82
i 1 301.339286 0.133929 33 99
i 3 301.339286 0.133929 42 72
i 1 301.473214 0.133929 33 85
i 3 301.607143 0.133929 38 105
i 3 301.607143 0.133929 42 59
i 1 301.875 0.133929 45 74
i 3 301.875 0.133929 46 52
i 3 302.142857 0.133929 36 106
i 3 302.142857 0.133929 42 59
i 8 302.142857 0.401786 67 75
i 1 302.410714 0.133929 33 99
i 3 302.410714 0.133929 42 72
i 5 302.410714 0.133929 45 69
i 1 302.544643 0.133929 33 77
i 3 302.678571 0.133929 38 101
i 3 302.678571 0.133929 42 59
i 1 302.946429 0.133929 33 82
i 3 302.946429 0.133929 42 72
i 3 303.214286 0.133929 36 101
i 3 303.214286 0.133929 42 59
i 8 303.214286 0.803571 64 72
i 1 303.482143 0.133929 33 99
i 3 303.482143 0.133929 42 72
i 1 303.616071 0.133929 33 85
i 5 303.616071 0.133929 45 60
i 3 303.75 0.133929 38 108
i 3 303.75 0.133929 42 59
i 1 304.017857 0.133929 45 74
i 3 304.017857 0.133929 46 57
i 2 304.285714 4.017857 47 49
i 2 304.285714 4.017857 52 49
i 2 304.285714 4.017857 54 49
i 3 304.285714 0.133929 36 108
i 3 304.285714 0.133929 42 59
i 8 304.285714 0.535714 66 82
i 9 304.285714 4.017857 52 20
i 1 304.553571 0.133929 35 99
i 3 304.553571 0.133929 42 72
i 1 304.6875 0.133929 35 77
i 3 304.821429 0.133929 38 102
i 3 304.821429 0.133929 42 59
i 1 305.089286 0.133929 35 82
i 3 305.089286 0.133929 42 72
i 5 305.223214 0.133929 47 77
i 3 305.357143 0.133929 36 99
i 3 305.357143 0.133929 42 59
i 8 305.357143 0.401786 64 76
i 1 305.625 0.133929 35 99
i 3 305.625 0.133929 42 72
i 1 305.758929 0.133929 35 85
i 3 305.892857 0.133929 38 105
i 3 305.892857 0.133929 42 59
i 1 306.160714 0.133929 47 74
i 3 306.160714 0.133929 46 52
i 8 306.160714 0.535714 59 78
i 3 306.428571 0.133929 36 106
i 3 306.428571 0.133929 42 59
i 1 306.696429 0.133929 35 99
i 3 306.696429 0.133929 42 72
i 5 306.696429 0.133929 47 68
i 1 306.830357 0.133929 35 77
i 3 306.964286 0.133929 38 101
i 3 306.964286 0.133929 42 59
i 1 307.232143 0.133929 35 82
i 3 307.232143 0.133929 42 72
i 8 307.232143 1.071429 66 83
i 3 307.5 0.133929 36 101
i 3 307.5 0.133929 42 59
i 1 307.767857 0.133929 35 99
i 3 307.767857 0.133929 38 65
i 3 307.767857 0.133929 42 72
i 1 307.901786 0.133929 35 85
i 5 307.901786 0.133929 47 59
i 3 308.035714 0.133929 38 108
i 3 308.035714 0.133929 42 59
i 1 308.303571 0.133929 47 74
i 3 308.303571 0.133929 38 80
i 3 308.303571 0.133929 46 57
i 3 308.4375 0.133929 38 49
i 2 308.571429 4.017857 52 37
i 2 308.571429 4.017857 55 37
i 2 308.571429 4.017857 59 37
i 2 308.571429 4.017857 62 37
i 3 308.571429 0.133929 35 83
i 6 308.571429 4.017857 52 48
i 6 308.571429 4.017857 55 48
i 6 308.571429 4.017857 59 48
i 6 308.571429 4.017857 62 48
i 1 308.839286 0.267857 40 62
i 3 309.107143 0.133929 42 34
i 8 309.107143 1.071429 67 54
i 1 309.910714 0.267857 40 62
i 3 310.178571 0.133929 38 54
i 3 310.178571 0.133929 42 34
i 4 310.178571 1.607143 71 46
i 7 310.178571 2.142857 64 42
i 3 310.714286 0.133929 35 77
i 8 310.714286 0.535714 66 49
i 1 310.982143 0.267857 40 62
i 3 311.25 0.133929 42 34
i 8 311.785714 0.803571 64 46
i 1 312.053571 0.267857 40 62
i 3 312.321429 0.133929 38 57
i 3 312.321429 0.133929 42 34
i 3 312.857143 0.133929 35 83
i 6 312.857143 4.017857 48 54
i 6 312.857143 4.017857 52 54
i 6 312.857143 4.017857 55 54
i 6 312.857143 4.017857 59 54
i 1 313.125 0.267857 36 62
i 3 313.392857 0.133929 42 34
i 1 314.196429 0.267857 36 62
i 3 314.464286 0.133929 38 54
i 3 314.464286 0.133929 42 34
i 3 315 0.133929 35 77
i 1 315.267857 0.267857 36 62
i 3 315.535714 0.133929 42 34
i 1 316.339286 0.267857 36 62
i 3 316.607143 0.133929 38 57
i 3 316.607143 0.133929 42 34
i 2 317.142857 4.017857 52 32
i 2 317.142857 4.017857 54 32
i 2 317.142857 4.017857 59 32
i 3 317.142857 0.133929 35 66
i 5 317.142857 0.133929 52 44
i 6 317.142857 4.017857 55 51
i 6 317.142857 4.017857 59 51
i 6 317.142857 4.017857 62 51
i 6 317.142857 4.017857 66 51
i 1 317.410714 0.267857 40 62
i 3 317.946429 0.133929 42 37
i 7 318.214286 2.142857 55 38
i 7 318.214286 2.142857 59 38
i 7 318.214286 2.142857 62 38
i 8 318.214286 1.071429 64 54
i 1 318.482143 0.267857 40 62
i 4 318.75 1.607143 74 39
i 3 319.017857 0.133929 42 37
i 1 319.553571 0.267857 40 62
i 3 320.089286 0.133929 42 37
i 8 320.357143 0.803571 71 48
i 1 320.625 0.267857 40 62
i 3 321.160714 0.133929 42 37
i 3 321.428571 0.133929 35 52
i 6 321.428571 4.017857 52 48
i 6 321.428571 4.017857 55 48
i 6 321.428571 4.017857 59 48
i 6 321.428571 4.017857 62 48
i 3 321.964286 0.133929 42 30
i 3 323.035714 0.133929 42 25
i 2 325.714286 4.017857 52 37
i 2 325.714286 4.017857 55 37
i 2 325.714286 4.017857 59 37
i 2 325.714286 4.017857 62 37
i 6 325.714286 4.017857 48 54
i 6 325.714286 4.017857 52 54
i 6 325.714286 4.017857 55 54
i 6 325.714286 4.017857 59 54
i 8 326.25 1.071429 67 54
i 4 326.517857 1.071429 76 53
i 7 327.321429 2.142857 64 42
i 8 327.857143 0.535714 66 49
i 4 328.660714 1.071429 71 44
i 8 328.928571 0.803571 64 46
i 6 330 4.017857 55 51
i 6 330 4.017857 59 51
i 6 330 4.017857 62 51
i 6 330 4.017857 66 51
i 7 331.071429 2.142857 55 38
i 7 331.071429 2.142857 59 38
i 7 331.071429 2.142857 62 38
i 4 331.607143 1.607143 74 39
i 6 334.285714 4.017857 52 48
i 6 334.285714 4.017857 55 48
i 6 334.285714 4.017857 59 48
i 6 334.285714 4.017857 62 48
i 4 335.892857 1.607143 71 46
i 7 335.892857 2.142857 64 42
i 6 342.857143 4.017857 52 48
i 6 342.857143 4.017857 55 48
i 6 342.857143 4.017857 59 48
i 6 342.857143 4.017857 62 48
i 4 343.928571 2.142857 78 34
i 6 347.142857 4.151786 52 37
i 6 347.142857 4.151786 55 37
i 6 347.142857 4.151786 59 37
i 6 347.142857 4.151786 62 37
i 4 349.821429 1.339286 78 29
f 0 362
</CsScore>
</CsoundSynthesizer>