<!--
Performance: The End of the Summer
Description: 112 BPM | E minor | 168 bars | 6:00 including decay. Dark wave: a cold industrial pulse interrupted by warm strings and brass. 0:00 Clouds; 0:34 Machinery; 1:43 First sunlight; 2:00 Clouds return; 3:09 Open sky; 3:43 Warmth within the machine; 4:51 Unwinding; 5:26 A little warmth survives. Finite Pad Looper arrangement, Repeat off. Final four bars reserved for tails.
Created: 2026-09-16T19:03:34.281469+00:00

This CSD was created with Orchestron.
Design instruments visually and hear ideas take shape.
Build expressive performances with sequencers, arpeggiators, live controls, and flexible audio routing.
Export portable Csound projects for rendering, sharing, and further sound design.

GitHub: https://github.com/thomassresearch/orchestron
-->
<CsoundSynthesizer>
<CsOptions>
-d -W -f -o The_End_of_the_Summer.wav -F The_End_of_the_Summer.mid
</CsOptions>
<CsInstruments>
sr = 48000
ksmps = 1
nchnls = 2
0dbfs = 1.0
opcode vcs_mixer_ramp, a, ki
 setksmps 1
 kTarget, iInitial xin
 kValue init iInitial
 kPrevious init iInitial
 kRemaining init 0
 if kTarget != kPrevious then
  kRemaining = 0.02
  kPrevious = kTarget
 endif
 if kRemaining > 0 then
  kValue = kValue + (kTarget - kValue) / max(1, kRemaining * kr)
  kRemaining = max(0, kRemaining - 1 / kr)
 else
  kValue = kTarget
 endif
 aValue interp kValue
 if timeinstk() == 1 then
  aValue = iInitial
 endif
 xout aValue
endop
; Mixer routing: patch, strip and route instruments execute in signal-flow order.
chnset 0.28183829312644537, "__vcs_mixer_strip_7cc44eb19abccf91739a7239_gain"
chnset 1, "__vcs_mixer_strip_7cc44eb19abccf91739a7239_left"
chnset 1, "__vcs_mixer_strip_7cc44eb19abccf91739a7239_right"
chnset 1, "__vcs_mixer_strip_7cc44eb19abccf91739a7239_mute"
chnset 0.3981071705534972, "__vcs_mixer_strip_441349e1ec2f7fd0aa17267b_gain"
chnset 1, "__vcs_mixer_strip_441349e1ec2f7fd0aa17267b_left"
chnset 1, "__vcs_mixer_strip_441349e1ec2f7fd0aa17267b_right"
chnset 1, "__vcs_mixer_strip_441349e1ec2f7fd0aa17267b_mute"
chnset 0.19952623149688797, "__vcs_mixer_strip_69a5a5c217c582a0ca581019_gain"
chnset 1, "__vcs_mixer_strip_69a5a5c217c582a0ca581019_left"
chnset 0.88, "__vcs_mixer_strip_69a5a5c217c582a0ca581019_right"
chnset 1, "__vcs_mixer_strip_69a5a5c217c582a0ca581019_mute"
chnset 0.3981071705534972, "__vcs_mixer_strip_15fa97b5a488542761982797_gain"
chnset 1, "__vcs_mixer_strip_15fa97b5a488542761982797_left"
chnset 1, "__vcs_mixer_strip_15fa97b5a488542761982797_right"
chnset 1, "__vcs_mixer_strip_15fa97b5a488542761982797_mute"
chnset 1, "__vcs_mixer_strip_3cb8201e7ff1e7777446032e_gain"
chnset 1, "__vcs_mixer_strip_3cb8201e7ff1e7777446032e_left"
chnset 0.92000000000000004, "__vcs_mixer_strip_3cb8201e7ff1e7777446032e_right"
chnset 1, "__vcs_mixer_strip_3cb8201e7ff1e7777446032e_mute"
chnset 0.89125093813374556, "__vcs_mixer_strip_921a95e8b614f668981d9eee_gain"
chnset 1, "__vcs_mixer_strip_921a95e8b614f668981d9eee_left"
chnset 1, "__vcs_mixer_strip_921a95e8b614f668981d9eee_right"
chnset 1, "__vcs_mixer_strip_921a95e8b614f668981d9eee_mute"
chnset 1, "__vcs_mixer_strip_4357ddb2013f8c1bae14ef67_gain"
chnset 0.87, "__vcs_mixer_strip_4357ddb2013f8c1bae14ef67_left"
chnset 1, "__vcs_mixer_strip_4357ddb2013f8c1bae14ef67_right"
chnset 1, "__vcs_mixer_strip_4357ddb2013f8c1bae14ef67_mute"
chnset 0.25118864315095801, "__vcs_mixer_strip_5187e59d9b00ec8dfc6ace45_gain"
chnset 0.84999999999999998, "__vcs_mixer_strip_5187e59d9b00ec8dfc6ace45_left"
chnset 1, "__vcs_mixer_strip_5187e59d9b00ec8dfc6ace45_right"
chnset 1, "__vcs_mixer_strip_5187e59d9b00ec8dfc6ace45_mute"
chnset 0.15848931924611134, "__vcs_mixer_strip_e5e72beb4e3c6926d3dc9e3e_gain"
chnset 1, "__vcs_mixer_strip_e5e72beb4e3c6926d3dc9e3e_left"
chnset 1, "__vcs_mixer_strip_e5e72beb4e3c6926d3dc9e3e_right"
chnset 1, "__vcs_mixer_strip_e5e72beb4e3c6926d3dc9e3e_mute"
chnset 0.63095734448019325, "__vcs_mixer_strip_b5c7638620f2f38a657a5790_gain"
chnset 1, "__vcs_mixer_strip_b5c7638620f2f38a657a5790_left"
chnset 1, "__vcs_mixer_strip_b5c7638620f2f38a657a5790_right"
chnset 1, "__vcs_mixer_strip_b5c7638620f2f38a657a5790_mute"
chnset 1, "__vcs_mixer_route_83b8456f5a6ccf61bd09771f_gain"
chnset 1, "__vcs_mixer_route_83b8456f5a6ccf61bd09771f_post"
chnset 1, "__vcs_mixer_route_83b8456f5a6ccf61bd09771f_pan"
chnset 1, "__vcs_mixer_route_b5f389b4e240e65eb88e717c_gain"
chnset 1, "__vcs_mixer_route_b5f389b4e240e65eb88e717c_post"
chnset 1, "__vcs_mixer_route_b5f389b4e240e65eb88e717c_pan"
chnset 1, "__vcs_mixer_route_3e8014902b44dfaf5918f0cb_gain"
chnset 1, "__vcs_mixer_route_3e8014902b44dfaf5918f0cb_post"
chnset 1, "__vcs_mixer_route_3e8014902b44dfaf5918f0cb_pan"
chnset 1, "__vcs_mixer_route_c99934ba5158b7053b82b3c7_gain"
chnset 1, "__vcs_mixer_route_c99934ba5158b7053b82b3c7_post"
chnset 1, "__vcs_mixer_route_c99934ba5158b7053b82b3c7_pan"
chnset 1, "__vcs_mixer_route_1d60c1873f7c84bee9eada4e_gain"
chnset 1, "__vcs_mixer_route_1d60c1873f7c84bee9eada4e_post"
chnset 1, "__vcs_mixer_route_1d60c1873f7c84bee9eada4e_pan"
chnset 1, "__vcs_mixer_route_51517161fc68e6e3eeac9206_gain"
chnset 1, "__vcs_mixer_route_51517161fc68e6e3eeac9206_post"
chnset 1, "__vcs_mixer_route_51517161fc68e6e3eeac9206_pan"
chnset 1, "__vcs_mixer_route_5c765a9573cccf11ec260943_gain"
chnset 1, "__vcs_mixer_route_5c765a9573cccf11ec260943_post"
chnset 1, "__vcs_mixer_route_5c765a9573cccf11ec260943_pan"
chnset 1, "__vcs_mixer_route_aca770adf6d5aa1d37b31081_gain"
chnset 1, "__vcs_mixer_route_aca770adf6d5aa1d37b31081_post"
chnset 1, "__vcs_mixer_route_aca770adf6d5aa1d37b31081_pan"
chnset 1, "__vcs_mixer_route_6ef9be26494bffae34fdfd29_gain"
chnset 1, "__vcs_mixer_route_6ef9be26494bffae34fdfd29_post"
chnset 1, "__vcs_mixer_route_6ef9be26494bffae34fdfd29_pan"
chnset 1, "__vcs_mixer_route_43f837ee6d4c255b17854c22_gain"
chnset 1, "__vcs_mixer_route_43f837ee6d4c255b17854c22_post"
chnset 1, "__vcs_mixer_route_43f837ee6d4c255b17854c22_pan"
chnset 1, "__vcs_mixer_route_c01b8e240438f78a8824cfd3_gain"
chnset 1, "__vcs_mixer_route_c01b8e240438f78a8824cfd3_post"
chnset 1, "__vcs_mixer_route_c01b8e240438f78a8824cfd3_pan"
chnset 1, "__vcs_mixer_route_1a360e0bf12680fcccccf68a_gain"
chnset 1, "__vcs_mixer_route_1a360e0bf12680fcccccf68a_post"
chnset 1, "__vcs_mixer_route_1a360e0bf12680fcccccf68a_pan"
chnset 1, "__vcs_mixer_route_3bf52259f3a75a40898bd370_gain"
chnset 1, "__vcs_mixer_route_3bf52259f3a75a40898bd370_post"
chnset 1, "__vcs_mixer_route_3bf52259f3a75a40898bd370_pan"
chnset 1, "__vcs_mixer_route_95085945e8b7aaf31960266c_gain"
chnset 1, "__vcs_mixer_route_95085945e8b7aaf31960266c_post"
chnset 1, "__vcs_mixer_route_95085945e8b7aaf31960266c_pan"
chnset 1, "__vcs_mixer_route_7d9706dbf4b80041a7bac944_gain"
chnset 1, "__vcs_mixer_route_7d9706dbf4b80041a7bac944_post"
chnset 1, "__vcs_mixer_route_7d9706dbf4b80041a7bac944_pan"
chnset 1, "__vcs_mixer_route_5471588a628d780162691603_gain"
chnset 1, "__vcs_mixer_route_5471588a628d780162691603_post"
chnset 1, "__vcs_mixer_route_5471588a628d780162691603_pan"
chnset 1, "__vcs_mixer_route_215dfad6ea4278df9c5b5929_gain"
chnset 1, "__vcs_mixer_route_215dfad6ea4278df9c5b5929_post"
chnset 1, "__vcs_mixer_route_215dfad6ea4278df9c5b5929_pan"
chnset 1, "__vcs_mixer_route_7ccdeae3e4931ae57c24ee42_gain"
chnset 1, "__vcs_mixer_route_7ccdeae3e4931ae57c24ee42_post"
chnset 1, "__vcs_mixer_route_7ccdeae3e4931ae57c24ee42_pan"
chnset 1, "__vcs_mixer_route_ebe4d00ca1570557781dee01_gain"
chnset 1, "__vcs_mixer_route_ebe4d00ca1570557781dee01_post"
chnset 1, "__vcs_mixer_route_ebe4d00ca1570557781dee01_pan"
chnset 1, "__vcs_mixer_route_208ab40923d5bf707587f01b_gain"
chnset 1, "__vcs_mixer_route_208ab40923d5bf707587f01b_post"
chnset 1, "__vcs_mixer_route_208ab40923d5bf707587f01b_pan"
massign 0, 0
massign 10, 3
massign 1, 1
massign 2, 5
massign 3, 2
massign 4, 8
massign 5, 6
massign 6, 7
massign 7, 4
massign 8, 9
chnset 1, "__vcs_perf_c47136601b6ea4e6370e270f9091838a70a71eaf9ef19a1000a71c57c70ca657"
chnset 1, "__vcs_perf_ad3c93d48fb5770da355be457ab89395386f05f9c5d130d292997b1e0d7d8c35"
chnset 0.5, "__vcs_perf_eab19a28d880be28fa5d086db1ac0c2039558b54d61d0c2c3b147dadb7c011cd"
chnset 2, "__vcs_perf_a647f3b1a6eef979fd4b84ef7e00100e16030190a47530e1e8b14be603e6a934"
connect "vcs_mix_4f507889dae17bb5de425c56", "left", "vcs_mix_233b9a10d13cb7345fe0ac51", "p_360f84035942243c6a36537a"
connect "vcs_mix_4f507889dae17bb5de425c56", "right", "vcs_mix_233b9a10d13cb7345fe0ac51", "p_27042f4e6eca7d0b2a7ee402"
chnset 0.65000000000000002, "__vcs_perf_3a3412564c51b46a1b2b5932e893c5377f697dde5eae688cc584ccdfcb58fea3"
chnset 0.0030000000000000001, "__vcs_perf_01cfe3facecca6f98f75a7d657f6b72de14cbcb96689449b53aa2ae1a2a7c2a4"
chnset 0.089999999999999997, "__vcs_perf_8aec72c06cb403170c8ac63a0d5a94d557081def0437f1a9d96c5b04d0361dfb"
chnset 1.7, "__vcs_perf_6333461785375abfa3e1e56d0c4e5251693489c7f876994084fb955d2e46bb7f"
chnset 0.044999999999999998, "__vcs_perf_efbeab3b8275658b2b792cc65c6d372a9e0d68e5688f983cd2727a48127bf431"
chnset 0.28000000000000003, "__vcs_perf_a1a8c8efcf62954b467a2b3f810241abdcb02d8b13aee6af47a82e95ddd85faa"
chnset 600, "__vcs_perf_176a9d6c90e45f3a5c879b4295e6221cb45d64776c1f57ce4ab80488b1189302"
connect "vcs_mix_33dc83ab9904e9526f7091d6", "left", "vcs_mix_d69e2b115c3aedc5f5e51463", "p_360f84035942243c6a36537a"
connect "vcs_mix_33dc83ab9904e9526f7091d6", "right", "vcs_mix_d69e2b115c3aedc5f5e51463", "p_27042f4e6eca7d0b2a7ee402"
chnset 0.0030000000000000001, "__vcs_perf_a175d18a9bfcdf60ae5c73352c3c40605b50ce1572548d8c5583537d7da998bf"
chnset 2.6000000000000001, "__vcs_perf_537c2b19d48f44e1e424e723788277a9281b9d43b761511324aca7e27c725a8f"
chnset 0.16, "__vcs_perf_41701256ec3711e8d169d6e04dc8984eebafdf6fec36817d76642ead9de79f94"
chnset 2.2000000000000002, "__vcs_perf_72ff4df4af243629f02ebf152735801f63433bb25c6eb1115e4f7c731c835bac"
chnset 0.20000000000000001, "__vcs_perf_af6123d7fa41370276ec9390d19919a421a3408261eddb7c22e2abdc0f7fac87"
chnset 0.14999999999999999, "__vcs_perf_300ce86c7a2a5bf21b93f4f78df99ae98603f3ab81a9e81f8b444dcae1cb7a8f"
chnset 0.080000000000000002, "__vcs_perf_78be482781265d240aa9c90b6cd369403569b19994d084ea9a9d84042e0029b3"
connect "vcs_mix_40643c4521cf1547a72d6c19", "left", "vcs_mix_d128d928004c9323f776f93a", "p_360f84035942243c6a36537a"
connect "vcs_mix_40643c4521cf1547a72d6c19", "right", "vcs_mix_d128d928004c9323f776f93a", "p_27042f4e6eca7d0b2a7ee402"
chnset 1.3999999999999999, "__vcs_perf_3c456691c46e0004e9f68642bf628b78230761b885805d730fdaba837aba84c6"
chnset 0.25, "__vcs_perf_c9b8a10bc7395e56c4f1e58b78ee975bc85395a8cfe4ee24559391e90b63d4ba"
chnset 0.13, "__vcs_perf_6972386ce10da486d8150798b5fd31dd6370b22fa8ca9f84aaa59c2622d09633"
chnset 0.55000000000000004, "__vcs_perf_135d781e2454b4e48599806b742e6e89762c5b1d5594a01c44baf7c3c5f7461f"
chnset 2.3999999999999999, "__vcs_perf_81eaa4a2bc2176bb0c4d870fa86fa96c4e691060bf41e4ce9778ffd6ad1a66ce"
chnset 0.28000000000000003, "__vcs_perf_e4492eb704bc9e3de2c33e65258c0cafca515039a9524b5e12d8010bd143066f"
chnset 750, "__vcs_perf_3352e2f8d65a84dfe6f573916ccef49d7f2c55e840e5aafac7d5a9046bafda8b"
connect "vcs_mix_2caaf50d4b3b53e2f4ee2efb", "left", "vcs_mix_96411e998269110c17432444", "p_360f84035942243c6a36537a"
connect "vcs_mix_2caaf50d4b3b53e2f4ee2efb", "right", "vcs_mix_96411e998269110c17432444", "p_27042f4e6eca7d0b2a7ee402"
chnset 0.01, "__vcs_perf_2693177ded5b3704bc870384173a72470fa3a13e6144717854f4ac738b76f410"
chnset 0.20000000000000001, "__vcs_perf_fa8a70d97431f3f6f5fce3a5432ef703e1b598ea68a3d5e09b6c1ecedf441a6e"
chnset 6, "__vcs_perf_789e61ba750aee5900aaa96e284eb96bdc9cb40bb441ce6d2fdb57b52575c586"
chnset 0.14999999999999999, "__vcs_perf_0294b3b47f66a9344cca1a5a51883b7e317cc1b65ecb77149d574ea73b0b5164"
chnset 0.22, "__vcs_perf_efd680873290a7110225cf770c00597f7560977a50b17fa760838a8cf73e0277"
chnset 1800, "__vcs_perf_b18357a98b0c231b8a2e7613ff04e4358d691722ebe869470e9a694fda744a9e"
chnset 4, "__vcs_perf_3dfb949bdf5981a798b597953f83889a8d82fded009fbb9ac6bc96de1f879192"
connect "vcs_mix_b9e4b05138bfb5ddfecff5e1", "left", "vcs_mix_8a252033ed35df6ff80fdae8", "p_360f84035942243c6a36537a"
connect "vcs_mix_b9e4b05138bfb5ddfecff5e1", "right", "vcs_mix_8a252033ed35df6ff80fdae8", "p_27042f4e6eca7d0b2a7ee402"
chnset 0.90000000000000002, "__vcs_perf_622518ee3862adc8b3f17f9f476cb2f2ffea4a9a674789344b4157b98214220f"
chnset 0.59999999999999998, "__vcs_perf_51f0147aa9651daa68390eeaf615c4143ee60381a2140a2072b442729ae89563"
chnset 8, "__vcs_perf_2d271b61eb8a76a4b00bfc63dca62a85d5e34c2f874d9217297884a5b9933dd4"
chnset 3, "__vcs_perf_14dbd30ed863c0239c6d1025f30671a2a5cabbd34ffe8b3938f26fe92b47035c"
chnset 0.22, "__vcs_perf_82b6576be193ba69f5e97deb72fe5b2c1c990f4a4058aec23336e3f002cc2dc7"
chnset 2300, "__vcs_perf_6095aa39c8df8873ec5f19f8b9ceb8601aeb7c970a46922ba5394f7ce22edf83"
connect "vcs_mix_b91f7fd7965b2dad388bba2b", "left", "vcs_mix_ac92f39f17c2687b02e604f4", "p_360f84035942243c6a36537a"
connect "vcs_mix_b91f7fd7965b2dad388bba2b", "right", "vcs_mix_ac92f39f17c2687b02e604f4", "p_27042f4e6eca7d0b2a7ee402"
chnset 0.089999999999999997, "__vcs_perf_86cc378af9041d5294c29fb180a2a447071c085191121fb86d925c5c920f83d4"
chnset 4, "__vcs_perf_7bfe3a3bce6abc89f529fe690548d1de6d37a6906f707c07a5732e196818788f"
chnset 0.65000000000000002, "__vcs_perf_82ba3acdefcc6460f500231c4626a68f7f1d91c9601a5cfddd7f510d6801f9bf"
chnset 1400, "__vcs_perf_99772fabed33c9193cc02a44d6d6f674521a18473e8e5a8cc3f5250477373958"
chnset 0.80000000000000004, "__vcs_perf_4fecc0c9b25b5fa647de6c824a65b6a7adb98a15406d418b5dd1c4ddcb954d76"
chnset 0.17999999999999999, "__vcs_perf_64c2b17f354e4038455ce71c6c7c49230ef5af9c620e4541d59a4cc898d10b48"
chnset 950, "__vcs_perf_d959aaca533b2b7656b57cacc21119939ad9308c4925af04cec1940da7079c69"
connect "vcs_mix_91d317b8f793206966758b36", "left", "vcs_mix_c5cc5b5de6f0d6ab45b331f7", "p_360f84035942243c6a36537a"
connect "vcs_mix_91d317b8f793206966758b36", "right", "vcs_mix_c5cc5b5de6f0d6ab45b331f7", "p_27042f4e6eca7d0b2a7ee402"
chnset 0.0030000000000000001, "__vcs_perf_7bed4733f2cf30ab8ececa1d061911d769efcf74c6a49d1363352814d8091472"
chnset 2, "__vcs_perf_4255b4799c2baaaf696d06577c5498543050bfad2e3c9df38feb483a5ce61527"
chnset 0.69999999999999996, "__vcs_perf_c9a8118403c5574b0b1d67f4efeae02fab27ff5b77321aa79b10229307175559"
chnset 2, "__vcs_perf_9d08305573089857d94b349a6d4a4d1065452491475f587164539f8b97c99b81"
chnset 1.5, "__vcs_perf_aad91d389043ff39f61e83a540ef1ff51ba1b339b9a30ff2cb86fbb90071bdfb"
chnset 0.29999999999999999, "__vcs_perf_bc7d83397c1478f832e5730a3fadc9b5b8f3ab7080c0f65681c43415706500a4"
chnset 4200, "__vcs_perf_b46a371f9eccb05e777dad1449cbe3ec085a046adde92c0acc50c8aee0494010"
connect "vcs_mix_c0bf79aa1787b85d72e90369", "left", "vcs_mix_3fb9b3909cb149df8c692155", "p_360f84035942243c6a36537a"
connect "vcs_mix_c0bf79aa1787b85d72e90369", "right", "vcs_mix_3fb9b3909cb149df8c692155", "p_27042f4e6eca7d0b2a7ee402"
chnset 0.80000000000000004, "__vcs_perf_cb7fe217f51092eabaf2b7e443277b31ad0bebfeac4f31e14ec648ac482e838c"
chnset 1000, "__vcs_perf_fef2b0c230c35dfb2d5c49ddf3168e31bce090e1dd122fe32e3705f8d0d670bc"
chnset 0.29999999999999999, "__vcs_perf_760f28410509b22de02893ffd96a9dc3b5fd6652ddc31ce462a827853871ec61"
chnset 0.14999999999999999, "__vcs_perf_580886d291fd5f84198c055bfe90349487f8b28ebe0eaacbc5f2c5d62078aed8"
chnset 2.5, "__vcs_perf_a9715bcb9e537a012079e8c1fae8e7c69106df97e14681c5583532445934cfea"
chnset 0.34999999999999998, "__vcs_perf_5a94f773f39f1a4865b25302f4f87693ed0ba505352f39638a974aecad3d977c"
chnset 0.59999999999999998, "__vcs_perf_d0026d433be3faabd992ea1dbca7ead5727b4816009a9f1ee44c1aecf507da2f"
connect "vcs_mix_1dc1baf55c97903a3ec0b1d9", "left", "vcs_mix_e1d7e481eb08ca2b9fc71c78", "p_360f84035942243c6a36537a"
connect "vcs_mix_1dc1baf55c97903a3ec0b1d9", "right", "vcs_mix_e1d7e481eb08ca2b9fc71c78", "p_27042f4e6eca7d0b2a7ee402"
connect "vcs_mix_63254fa67083d5eed1f09ece", "__vcs_direct_e0ee8bb50685e05fa0f47ed0_left", "vcs_mix_0644eeee2942927583ef32ed", "p_2336acbd28828ab05deafe52"
connect "vcs_mix_63254fa67083d5eed1f09ece", "__vcs_direct_e0ee8bb50685e05fa0f47ed0_right", "vcs_mix_0644eeee2942927583ef32ed", "p_2a250433534f9aea9d512171"
connect "vcs_mix_233b9a10d13cb7345fe0ac51", "pre_p_360f84035942243c6a36537a", "vcs_mix_776a9ca62745889b1ae2494d", "pre"
connect "vcs_mix_233b9a10d13cb7345fe0ac51", "post_p_360f84035942243c6a36537a", "vcs_mix_776a9ca62745889b1ae2494d", "post"
connect "vcs_mix_776a9ca62745889b1ae2494d", "out", "vcs_mix_63254fa67083d5eed1f09ece", "left"
connect "vcs_mix_233b9a10d13cb7345fe0ac51", "pre_p_27042f4e6eca7d0b2a7ee402", "vcs_mix_38e2e3dd71d7c951b8ee623c", "pre"
connect "vcs_mix_233b9a10d13cb7345fe0ac51", "post_p_27042f4e6eca7d0b2a7ee402", "vcs_mix_38e2e3dd71d7c951b8ee623c", "post"
connect "vcs_mix_38e2e3dd71d7c951b8ee623c", "out", "vcs_mix_63254fa67083d5eed1f09ece", "right"
connect "vcs_mix_d69e2b115c3aedc5f5e51463", "pre_p_360f84035942243c6a36537a", "vcs_mix_bf77b782450578498a75e856", "pre"
connect "vcs_mix_d69e2b115c3aedc5f5e51463", "post_p_360f84035942243c6a36537a", "vcs_mix_bf77b782450578498a75e856", "post"
connect "vcs_mix_bf77b782450578498a75e856", "out", "vcs_mix_63254fa67083d5eed1f09ece", "left"
connect "vcs_mix_d69e2b115c3aedc5f5e51463", "pre_p_27042f4e6eca7d0b2a7ee402", "vcs_mix_7d28de53beb30deccc25fc17", "pre"
connect "vcs_mix_d69e2b115c3aedc5f5e51463", "post_p_27042f4e6eca7d0b2a7ee402", "vcs_mix_7d28de53beb30deccc25fc17", "post"
connect "vcs_mix_7d28de53beb30deccc25fc17", "out", "vcs_mix_63254fa67083d5eed1f09ece", "right"
connect "vcs_mix_d128d928004c9323f776f93a", "pre_p_360f84035942243c6a36537a", "vcs_mix_725f6223d9072d1bb2e23c76", "pre"
connect "vcs_mix_d128d928004c9323f776f93a", "post_p_360f84035942243c6a36537a", "vcs_mix_725f6223d9072d1bb2e23c76", "post"
connect "vcs_mix_725f6223d9072d1bb2e23c76", "out", "vcs_mix_63254fa67083d5eed1f09ece", "left"
connect "vcs_mix_d128d928004c9323f776f93a", "pre_p_27042f4e6eca7d0b2a7ee402", "vcs_mix_d04fd17777bbf3b8af8783a5", "pre"
connect "vcs_mix_d128d928004c9323f776f93a", "post_p_27042f4e6eca7d0b2a7ee402", "vcs_mix_d04fd17777bbf3b8af8783a5", "post"
connect "vcs_mix_d04fd17777bbf3b8af8783a5", "out", "vcs_mix_63254fa67083d5eed1f09ece", "right"
connect "vcs_mix_96411e998269110c17432444", "pre_p_360f84035942243c6a36537a", "vcs_mix_b99cad66f5a693384ddaaa91", "pre"
connect "vcs_mix_96411e998269110c17432444", "post_p_360f84035942243c6a36537a", "vcs_mix_b99cad66f5a693384ddaaa91", "post"
connect "vcs_mix_b99cad66f5a693384ddaaa91", "out", "vcs_mix_63254fa67083d5eed1f09ece", "left"
connect "vcs_mix_96411e998269110c17432444", "pre_p_27042f4e6eca7d0b2a7ee402", "vcs_mix_bf6f81fb9ed80577ae278764", "pre"
connect "vcs_mix_96411e998269110c17432444", "post_p_27042f4e6eca7d0b2a7ee402", "vcs_mix_bf6f81fb9ed80577ae278764", "post"
connect "vcs_mix_bf6f81fb9ed80577ae278764", "out", "vcs_mix_63254fa67083d5eed1f09ece", "right"
connect "vcs_mix_8a252033ed35df6ff80fdae8", "pre_p_360f84035942243c6a36537a", "vcs_mix_72eedbbbd4d867877d198844", "pre"
connect "vcs_mix_8a252033ed35df6ff80fdae8", "post_p_360f84035942243c6a36537a", "vcs_mix_72eedbbbd4d867877d198844", "post"
connect "vcs_mix_72eedbbbd4d867877d198844", "out", "vcs_mix_63254fa67083d5eed1f09ece", "left"
connect "vcs_mix_8a252033ed35df6ff80fdae8", "pre_p_27042f4e6eca7d0b2a7ee402", "vcs_mix_bf26ce664958883e5fa5077a", "pre"
connect "vcs_mix_8a252033ed35df6ff80fdae8", "post_p_27042f4e6eca7d0b2a7ee402", "vcs_mix_bf26ce664958883e5fa5077a", "post"
connect "vcs_mix_bf26ce664958883e5fa5077a", "out", "vcs_mix_63254fa67083d5eed1f09ece", "right"
connect "vcs_mix_ac92f39f17c2687b02e604f4", "pre_p_360f84035942243c6a36537a", "vcs_mix_9f8ea62d9094b1ee06064c74", "pre"
connect "vcs_mix_ac92f39f17c2687b02e604f4", "post_p_360f84035942243c6a36537a", "vcs_mix_9f8ea62d9094b1ee06064c74", "post"
connect "vcs_mix_9f8ea62d9094b1ee06064c74", "out", "vcs_mix_63254fa67083d5eed1f09ece", "left"
connect "vcs_mix_ac92f39f17c2687b02e604f4", "pre_p_27042f4e6eca7d0b2a7ee402", "vcs_mix_ab29dbdb974d3cf3720ccde1", "pre"
connect "vcs_mix_ac92f39f17c2687b02e604f4", "post_p_27042f4e6eca7d0b2a7ee402", "vcs_mix_ab29dbdb974d3cf3720ccde1", "post"
connect "vcs_mix_ab29dbdb974d3cf3720ccde1", "out", "vcs_mix_63254fa67083d5eed1f09ece", "right"
connect "vcs_mix_c5cc5b5de6f0d6ab45b331f7", "pre_p_360f84035942243c6a36537a", "vcs_mix_a0bf5a6e682d1681b8c6dcab", "pre"
connect "vcs_mix_c5cc5b5de6f0d6ab45b331f7", "post_p_360f84035942243c6a36537a", "vcs_mix_a0bf5a6e682d1681b8c6dcab", "post"
connect "vcs_mix_a0bf5a6e682d1681b8c6dcab", "out", "vcs_mix_63254fa67083d5eed1f09ece", "left"
connect "vcs_mix_c5cc5b5de6f0d6ab45b331f7", "pre_p_27042f4e6eca7d0b2a7ee402", "vcs_mix_5e006bf5e9b69c39e6038e0c", "pre"
connect "vcs_mix_c5cc5b5de6f0d6ab45b331f7", "post_p_27042f4e6eca7d0b2a7ee402", "vcs_mix_5e006bf5e9b69c39e6038e0c", "post"
connect "vcs_mix_5e006bf5e9b69c39e6038e0c", "out", "vcs_mix_63254fa67083d5eed1f09ece", "right"
connect "vcs_mix_3fb9b3909cb149df8c692155", "pre_p_360f84035942243c6a36537a", "vcs_mix_7a9040b07366a0daa7dc6894", "pre"
connect "vcs_mix_3fb9b3909cb149df8c692155", "post_p_360f84035942243c6a36537a", "vcs_mix_7a9040b07366a0daa7dc6894", "post"
connect "vcs_mix_7a9040b07366a0daa7dc6894", "out", "vcs_mix_63254fa67083d5eed1f09ece", "left"
connect "vcs_mix_3fb9b3909cb149df8c692155", "pre_p_27042f4e6eca7d0b2a7ee402", "vcs_mix_898dca64f18bed88c536cb6b", "pre"
connect "vcs_mix_3fb9b3909cb149df8c692155", "post_p_27042f4e6eca7d0b2a7ee402", "vcs_mix_898dca64f18bed88c536cb6b", "post"
connect "vcs_mix_898dca64f18bed88c536cb6b", "out", "vcs_mix_63254fa67083d5eed1f09ece", "right"
connect "vcs_mix_e1d7e481eb08ca2b9fc71c78", "pre_p_360f84035942243c6a36537a", "vcs_mix_e07cbf7b561e14be9651d6d0", "pre"
connect "vcs_mix_e1d7e481eb08ca2b9fc71c78", "post_p_360f84035942243c6a36537a", "vcs_mix_e07cbf7b561e14be9651d6d0", "post"
connect "vcs_mix_e07cbf7b561e14be9651d6d0", "out", "vcs_mix_63254fa67083d5eed1f09ece", "left"
connect "vcs_mix_e1d7e481eb08ca2b9fc71c78", "pre_p_27042f4e6eca7d0b2a7ee402", "vcs_mix_9fa67706cd4495d936a25713", "pre"
connect "vcs_mix_e1d7e481eb08ca2b9fc71c78", "post_p_27042f4e6eca7d0b2a7ee402", "vcs_mix_9fa67706cd4495d936a25713", "post"
connect "vcs_mix_9fa67706cd4495d936a25713", "out", "vcs_mix_63254fa67083d5eed1f09ece", "right"
connect "vcs_mix_0644eeee2942927583ef32ed", "pre_p_2336acbd28828ab05deafe52", "vcs_mix_ec8b1641891924a3e102560a", "pre"
connect "vcs_mix_0644eeee2942927583ef32ed", "post_p_2336acbd28828ab05deafe52", "vcs_mix_ec8b1641891924a3e102560a", "post"
connect "vcs_mix_ec8b1641891924a3e102560a", "out", "vcs_mix_9cea1be1f8255375a6cf7b93", "left"
connect "vcs_mix_0644eeee2942927583ef32ed", "pre_p_2a250433534f9aea9d512171", "vcs_mix_5f16b779ade2ce91f307ff35", "pre"
connect "vcs_mix_0644eeee2942927583ef32ed", "post_p_2a250433534f9aea9d512171", "vcs_mix_5f16b779ade2ce91f307ff35", "post"
connect "vcs_mix_5f16b779ade2ce91f307ff35", "out", "vcs_mix_9cea1be1f8255375a6cf7b93", "right"
; Continuous patches and mixer stages start with alwayson; note instruments start from MIDI/score events.
alwayson "vcs_mix_d69e2b115c3aedc5f5e51463"
alwayson "vcs_mix_bf77b782450578498a75e856"
alwayson "vcs_mix_7d28de53beb30deccc25fc17"
alwayson "vcs_mix_96411e998269110c17432444"
alwayson "vcs_mix_b99cad66f5a693384ddaaa91"
alwayson "vcs_mix_bf6f81fb9ed80577ae278764"
alwayson "vcs_mix_233b9a10d13cb7345fe0ac51"
alwayson "vcs_mix_776a9ca62745889b1ae2494d"
alwayson "vcs_mix_38e2e3dd71d7c951b8ee623c"
alwayson "vcs_mix_3fb9b3909cb149df8c692155"
alwayson "vcs_mix_7a9040b07366a0daa7dc6894"
alwayson "vcs_mix_898dca64f18bed88c536cb6b"
alwayson "vcs_mix_d128d928004c9323f776f93a"
alwayson "vcs_mix_725f6223d9072d1bb2e23c76"
alwayson "vcs_mix_d04fd17777bbf3b8af8783a5"
alwayson "vcs_mix_ac92f39f17c2687b02e604f4"
alwayson "vcs_mix_9f8ea62d9094b1ee06064c74"
alwayson "vcs_mix_ab29dbdb974d3cf3720ccde1"
alwayson "vcs_mix_c5cc5b5de6f0d6ab45b331f7"
alwayson "vcs_mix_a0bf5a6e682d1681b8c6dcab"
alwayson "vcs_mix_5e006bf5e9b69c39e6038e0c"
alwayson "vcs_mix_8a252033ed35df6ff80fdae8"
alwayson "vcs_mix_72eedbbbd4d867877d198844"
alwayson "vcs_mix_bf26ce664958883e5fa5077a"
alwayson "vcs_mix_e1d7e481eb08ca2b9fc71c78"
alwayson "vcs_mix_e07cbf7b561e14be9651d6d0"
alwayson "vcs_mix_9fa67706cd4495d936a25713"
alwayson "vcs_mix_63254fa67083d5eed1f09ece"
alwayson "vcs_mix_0644eeee2942927583ef32ed"
alwayson "vcs_mix_ec8b1641891924a3e102560a"
alwayson "vcs_mix_5f16b779ade2ce91f307ff35"
alwayson "vcs_mix_9cea1be1f8255375a6cf7b93"
; mixer stage patch:bass
; patch:d6a771a3-056b-4a69-9ddc-0abaed75603b name:EBM DW — Sequencer Bass channel:1 always_on:false
; instance:bass csound:vcs_mix_33dc83ab9904e9526f7091d6
; description: Lean dry pulse/saw bass for short external sixteenth-note sequences. Velocity changes filter brightness; no built-in sequencer. Suggested MIDI 28–60. Velocity-sensitive; settings apply to new notes. Motion rates are Hz; echoes are fixed time. Route Stereo Output through the mixer to Master.
; trigger: MIDI channel 1 / score notes; score instrument number: 1
instr vcs_mix_33dc83ab9904e9526f7091d6
 i_ctl_accent_iout_10 chnget "__vcs_perf_3a3412564c51b46a1b2b5932e893c5377f697dde5eae688cc584ccdfcb58fea3"
 i_ctl_attack_iout_5 chnget "__vcs_perf_01cfe3facecca6f98f75a7d657f6b72de14cbcb96689449b53aa2ae1a2a7c2a4"
 i_ctl_decay_iout_9 chnget "__vcs_perf_8aec72c06cb403170c8ac63a0d5a94d557081def0437f1a9d96c5b04d0361dfb"
 i_ctl_drive_iout_11 chnget "__vcs_perf_6333461785375abfa3e1e56d0c4e5251693489c7f876994084fb955d2e46bb7f"
 i_ctl_release_iout_6 chnget "__vcs_perf_efbeab3b8275658b2b792cc65c6d372a9e0d68e5688f983cd2727a48127bf431"
 i_ctl_resonance_iout_8 chnget "__vcs_perf_a1a8c8efcf62954b467a2b3f810241abdcb02d8b13aee6af47a82e95ddd85faa"
 i_ctl_tone_iout_7 chnget "__vcs_perf_176a9d6c90e45f3a5c879b4295e6221cb45d64776c1f57ce4ab80488b1189302"
 ; node:env_sustain_const opcode:const_i
 i_env_sustain_const_iout_4 = 0.08
 ; node:pitch_cpsmidi opcode:cpsmidi
 i_pitch_cpsmidi_kfreq_1 cpsmidi
 ; node:pulse_gain opcode:const_k
 k_pulse_gain_kout_3 = 0.15
 ; node:saw_a_gain opcode:const_k
 k_saw_a_gain_kout_5 = 0.09
 ; node:velocity_scale_const opcode:const_i
 i_velocity_scale_const_iout_2 = 1.0
 ; node:filter_decay_envelope opcode:linseg
 k_filter_decay_envelope_kenv_7 linseg 1, i_ctl_decay_iout_9, 0
 ; node:amp_madsr opcode:madsr
 k_amp_madsr_kenv_1 madsr i_ctl_attack_iout_5, i_ctl_decay_iout_9, i_env_sustain_const_iout_4, i_ctl_release_iout_6, 0, -1
 ; node:velocity_ampmidi opcode:ampmidi
 i_velocity_ampmidi_iamp_3 ampmidi i_velocity_scale_const_iout_2
 ; node:amp_velocity_envelope opcode:k_mul
 k_amp_velocity_envelope_kout_2 = (i_velocity_ampmidi_iamp_3) * (k_amp_madsr_kenv_1)
 ; node:pulse_amp opcode:k_mul
 k_pulse_amp_kout_4 = (k_amp_velocity_envelope_kout_2) * (k_pulse_gain_kout_3)
 ; node:saw_a_amp opcode:k_mul
 k_saw_a_amp_kout_6 = (k_amp_velocity_envelope_kout_2) * (k_saw_a_gain_kout_5)
 ; node:pulse_vco2 opcode:vco2
 a_pulse_vco2_asig_1 vco2 k_pulse_amp_kout_4, i_pitch_cpsmidi_kfreq_1, 2, 0.5, 0, 0.5
 ; node:saw_a_vco2 opcode:vco2
 a_saw_a_vco2_asig_2 vco2 k_saw_a_amp_kout_6, (i_pitch_cpsmidi_kfreq_1 * 0.9965), 0, 0.5, 0, 0.5
 ; node:source_sum opcode:mix2
 a_source_sum_aout_5 = ((a_pulse_vco2_asig_1 + a_saw_a_vco2_asig_2)) + (0)
 ; node:voice_filter opcode:moogladder2
 a_voice_filter_aout_6 moogladder2 a_source_sum_aout_5, (i_ctl_tone_iout_7 + ((2600 * k_filter_decay_envelope_kenv_7) * ((.2 + ((.8 * i_velocity_ampmidi_iamp_3) * i_ctl_accent_iout_10))))), i_ctl_resonance_iout_8
 ; node:saturation opcode:distort1
 a_saturation_aout_7 distort1 a_voice_filter_aout_6, (i_ctl_drive_iout_11 * 3), (1 / ((1 + (.55 * ((i_ctl_drive_iout_11 - 1)))))), 0, 0, 1
 ; node:dc_filter opcode:butterhp
 a_dc_filter_aout_8 butterhp a_saturation_aout_7, 22, 0
 ; node:output_pan2 opcode:pan2
 a_output_pan2_aleft_3, a_output_pan2_aright_4 pan2 (a_dc_filter_aout_8 * 0.58), 0.5, 0
 ; node:output_left opcode:outleta
 outleta "left", a_output_pan2_aleft_3
 ; node:output_right opcode:outleta
 outleta "right", a_output_pan2_aright_4
endin

; mixer stage patch:clouds
; patch:1c823ae5-f5f5-4cbf-ac3b-4ca883fb6b68 name:EBM DW — Dark PWM Pad channel:3 always_on:false
; instance:clouds csound:vcs_mix_2caaf50d4b3b53e2f4ee2efb
; description: Shadowy triangle/pulse pad with slow PWM and filter movement, chorus and restrained reverb. Suggested MIDI 43–79. Velocity-sensitive; settings apply to new notes. Motion rates are Hz; echoes are fixed time. Route Stereo Output through the mixer to Master.
; trigger: MIDI channel 3 / score notes; score instrument number: 2
instr vcs_mix_2caaf50d4b3b53e2f4ee2efb
 ; node:chorus_left_lfo opcode:lfo
 k_chorus_left_lfo_kout_8 lfo 1, 0.23, 0
 ; node:chorus_right_lfo opcode:lfo
 k_chorus_right_lfo_kout_9 lfo 1, 0.31, 0
 i_ctl_attack_iout_6 chnget "__vcs_perf_3c456691c46e0004e9f68642bf628b78230761b885805d730fdaba837aba84c6"
 i_ctl_motion_depth_iout_10 chnget "__vcs_perf_c9b8a10bc7395e56c4f1e58b78ee975bc85395a8cfe4ee24559391e90b63d4ba"
 i_ctl_motion_rate_iout_11 chnget "__vcs_perf_6972386ce10da486d8150798b5fd31dd6370b22fa8ca9f84aaa59c2622d09633"
 i_ctl_pulse_blend_iout_9 chnget "__vcs_perf_135d781e2454b4e48599806b742e6e89762c5b1d5594a01c44baf7c3c5f7461f"
 i_ctl_release_iout_7 chnget "__vcs_perf_81eaa4a2bc2176bb0c4d870fa86fa96c4e691060bf41e4ce9778ffd6ad1a66ce"
 i_ctl_space_iout_12 chnget "__vcs_perf_e4492eb704bc9e3de2c33e65258c0cafca515039a9524b5e12d8010bd143066f"
 i_ctl_tone_iout_8 chnget "__vcs_perf_3352e2f8d65a84dfe6f573916ccef49d7f2c55e840e5aafac7d5a9046bafda8b"
 ; node:env_decay_const opcode:const_i
 i_env_decay_const_iout_4 = 2.0
 ; node:env_sustain_const opcode:const_i
 i_env_sustain_const_iout_5 = 0.75
 ; node:pitch_cpsmidi opcode:cpsmidi
 i_pitch_cpsmidi_kfreq_1 cpsmidi
 ; node:pulse_gain opcode:const_k
 k_pulse_gain_kout_5 = 0.15
 ; node:triangle_gain opcode:const_k
 k_triangle_gain_kout_3 = 0.2
 ; node:velocity_scale_const opcode:const_i
 i_velocity_scale_const_iout_2 = 1.0
 ; node:motion_lfo opcode:lfo
 k_motion_lfo_kout_7 lfo 1, i_ctl_motion_rate_iout_11, 0
 ; node:effect_tail opcode:xtratim
 xtratim (i_ctl_release_iout_7 + 10.0)
 ; node:audio_ctl_space_iout opcode:k_to_a
 a_audio_ctl_space_iout_aout_12 interp i_ctl_space_iout_12
 ; node:amp_madsr opcode:madsr
 k_amp_madsr_kenv_1 madsr i_ctl_attack_iout_6, i_env_decay_const_iout_4, i_env_sustain_const_iout_5, i_ctl_release_iout_7, 0, -1
 ; node:velocity_ampmidi opcode:ampmidi
 i_velocity_ampmidi_iamp_3 ampmidi i_velocity_scale_const_iout_2
 ; node:amp_velocity_envelope opcode:k_mul
 k_amp_velocity_envelope_kout_2 = (i_velocity_ampmidi_iamp_3) * (k_amp_madsr_kenv_1)
 ; node:pulse_amp opcode:k_mul
 k_pulse_amp_kout_6 = ((k_amp_velocity_envelope_kout_2 * i_ctl_pulse_blend_iout_9)) * (k_pulse_gain_kout_5)
 ; node:triangle_amp opcode:k_mul
 k_triangle_amp_kout_4 = ((k_amp_velocity_envelope_kout_2 * ((1 - (.6 * i_ctl_pulse_blend_iout_9))))) * (k_triangle_gain_kout_3)
 ; node:pulse_vco2 opcode:vco2
 a_pulse_vco2_asig_2 vco2 k_pulse_amp_kout_6, i_pitch_cpsmidi_kfreq_1, 2, (.5 + ((.2 * i_ctl_motion_depth_iout_10) * k_motion_lfo_kout_7)), 0, 0.5
 ; node:triangle_vco2 opcode:vco2
 a_triangle_vco2_asig_1 vco2 k_triangle_amp_kout_4, i_pitch_cpsmidi_kfreq_1, 12, 0.5, 0, 0.5
 ; node:source_sum opcode:mix2
 a_source_sum_aout_5 = ((a_triangle_vco2_asig_1 + a_pulse_vco2_asig_2)) + (0)
 ; node:voice_filter opcode:moogladder2
 a_voice_filter_aout_6 moogladder2 a_source_sum_aout_5, (i_ctl_tone_iout_8 * ((1 + ((.45 * i_ctl_motion_depth_iout_10) * k_motion_lfo_kout_7)))), 0.18
 ; node:dc_filter opcode:butterhp
 a_dc_filter_aout_7 butterhp a_voice_filter_aout_6, 22, 0
 ; node:output_pan2 opcode:pan2
 a_output_pan2_aleft_3, a_output_pan2_aright_4 pan2 a_dc_filter_aout_7, 0.5, 0
 ; node:chorus_left opcode:vdelay3
 a_chorus_left_aout_8 vdelay3 a_output_pan2_aleft_3, (14 + (3 * k_chorus_left_lfo_kout_8)), 35
 ; node:chorus_right opcode:vdelay3
 a_chorus_right_aout_15 vdelay3 a_output_pan2_aright_4, (19 + (3 * k_chorus_right_lfo_kout_9)), 35
 ; node:chorus_mix_left opcode:mix2
 a_chorus_mix_left_aout_9 = (((a_output_pan2_aleft_3 * 0.9125) + (a_chorus_left_aout_8 * 0.175))) + (0)
 ; node:chorus_mix_right opcode:mix2
 a_chorus_mix_right_aout_16 = (((a_output_pan2_aright_4 * 0.9125) + (a_chorus_right_aout_15 * 0.175))) + (0)
 ; node:room_predelay_left opcode:delay
 a_room_predelay_left_aout_10 delay a_chorus_mix_left_aout_9, 0.017, 0
 ; node:room_predelay_right opcode:delay
 a_room_predelay_right_aout_17 delay a_chorus_mix_right_aout_16, 0.029, 0
 ; node:room_left opcode:reverb2
 a_room_left_aout_11 reverb2 a_room_predelay_left_aout_10, 2.5, 0.45, 0
 ; node:room_right opcode:reverb2
 a_room_right_aout_18 reverb2 a_room_predelay_right_aout_17, 2.325, 0.45, 0
 ; node:room_mix_left opcode:mix2
 a_room_mix_left_aout_13 = ((a_chorus_mix_left_aout_9 + (a_audio_ctl_space_iout_aout_12 * a_room_left_aout_11))) + (0)
 ; node:room_mix_right opcode:mix2
 a_room_mix_right_aout_19 = ((a_chorus_mix_right_aout_16 + (a_audio_ctl_space_iout_aout_12 * a_room_right_aout_18))) + (0)
 ; node:final_level_left opcode:mix2
 a_final_level_left_aout_14 = ((a_room_mix_left_aout_13 * 0.5)) + (0)
 ; node:final_level_right opcode:mix2
 a_final_level_right_aout_20 = ((a_room_mix_right_aout_19 * 0.5)) + (0)
 ; node:output_left opcode:outleta
 outleta "left", a_final_level_left_aout_14
 ; node:output_right opcode:outleta
 outleta "right", a_final_level_right_aout_20
endin

; mixer stage patch:drums
; patch:979b006c-d2a5-47c1-836c-9f3f30453ddf name:Analog Drumkit channel:10 always_on:false
; instance:drums csound:vcs_mix_4f507889dae17bb5de425c56
; description: Five velocity-sensitive analog synthesis voices selected by MIDI notnum through Switch. MIDI notenum 35: Bass drum (pitch-swept sine + click); 36: Bass drum distorted (saturated sine + click); 46: Hi-hat open (700 ms); 42: Hi-hat closed (85 ms); 38: Snare (two sine resonances + filtered noise). Hats use six inharmonic square oscillators plus noise. One-shot decays survive short MIDI note-offs. Silent default; stereo output; no samples. GM bass-drum slot 36 is used for the distorted variation.
; trigger: MIDI channel 10 / score notes; score instrument number: 3
instr vcs_mix_4f507889dae17bb5de425c56
 ; node:note opcode:notnum
 i_note_inote_1 notnum
 ; node:velocity_scale opcode:const_i
 i_velocity_scale_iout_2 = 1
 ; node:velocity opcode:ampmidi
 i_velocity_iamp_3 ampmidi i_velocity_scale_iout_2
 ; node:kit opcode:Switch
 if (i_note_inote_1) == 35.0 then
   ; case:bass_drum Bass drum
   i_9da04da0_dadc_4020_888b_dec37077e0bc_iout_6 chnget "__vcs_perf_c47136601b6ea4e6370e270f9091838a70a71eaf9ef19a1000a71c57c70ca657"
   ; node:bass_drum_click_env opcode:expseg
   k_bass_drum_click_env_kenv_4 expseg 1, 0.012, 0.0001
   ; node:bass_drum_decay opcode:expseg
   k_bass_drum_decay_kenv_2 expseg 1, 0.129, 0.16, 0.301, 0.0001
   ; node:bass_drum_gate opcode:linseg
   k_bass_drum_gate_kenv_1 linseg 0, 0.001, 1, 0.421, 1, 0.008, 0
   ; node:bass_drum_pitch opcode:expseg
   k_bass_drum_pitch_kenv_3 expseg 165, 0.026, 57, 0.2, 46
   ; node:bass_drum_tail opcode:xtratim
   xtratim 0.455
   ; node:bass_drum_click opcode:noise
   a_bass_drum_click_aout_4 noise (k_bass_drum_click_env_kenv_4 * 0.14), 0
   ; node:bass_drum_amplitude opcode:upsamp
   a_bass_drum_amplitude_aout_7 upsamp (((k_bass_drum_decay_kenv_2 * k_bass_drum_gate_kenv_1) * i_velocity_iamp_3) * 0.52)
   ; node:bass_drum_tone opcode:oscili
   a_bass_drum_tone_asig_3 oscili 1, (k_bass_drum_pitch_kenv_3 * i_9da04da0_dadc_4020_888b_dec37077e0bc_iout_6), -1
   ; node:bass_drum_click_filter opcode:butterbp
   a_bass_drum_click_filter_aout_5 butterbp a_bass_drum_click_aout_4, 2200, 2500, 0
   ; node:bass_drum_mix opcode:mix2
   a_bass_drum_mix_aout_6 = (a_bass_drum_tone_asig_3) + (a_bass_drum_click_filter_aout_5)
   ; node:bass_drum_pan opcode:pan2
   a_bass_drum_pan_aleft_8, a_bass_drum_pan_aright_9 pan2 (a_bass_drum_mix_aout_6 * a_bass_drum_amplitude_aout_7), 0.5, 0
   a_kit_left_1 = a_bass_drum_pan_aleft_8
   a_kit_right_2 = a_bass_drum_pan_aright_9
 elseif (i_note_inote_1) == 36.0 then
   ; case:bass_drum_distorted Bass drum distorted
   i_1a9be505_b7fe_4d12_a783_60346b810c6a_iout_7 chnget "__vcs_perf_ad3c93d48fb5770da355be457ab89395386f05f9c5d130d292997b1e0d7d8c35"
   i_460f9e29_fa38_4055_8f7b_c9f7d7ebe7aa_iout_5 chnget "__vcs_perf_eab19a28d880be28fa5d086db1ac0c2039558b54d61d0c2c3b147dadb7c011cd"
   ; node:bass_drum_distorted_click_env opcode:expseg
   k_bass_drum_distorted_click_env_kenv_8 expseg 1, 0.012, 0.0001
   ; node:bass_drum_distorted_decay opcode:expseg
   k_bass_drum_distorted_decay_kenv_6 expseg 1, 0.108, 0.16, 0.252, 0.0001
   ; node:bass_drum_distorted_gate opcode:linseg
   k_bass_drum_distorted_gate_kenv_5 linseg 0, 0.001, 1, 0.351, 1, 0.008, 0
   ; node:bass_drum_distorted_pitch opcode:expseg
   k_bass_drum_distorted_pitch_kenv_7 expseg 190, 0.026, 57, 0.2, 49
   ; node:bass_drum_distorted_tail opcode:xtratim
   xtratim 0.385
   i_ddccf62d_f9e6_49f3_a0dc_f438c7783415_iout_4 chnget "__vcs_perf_a647f3b1a6eef979fd4b84ef7e00100e16030190a47530e1e8b14be603e6a934"
   ; node:bass_drum_distorted_click opcode:noise
   a_bass_drum_distorted_click_aout_11 noise (k_bass_drum_distorted_click_env_kenv_8 * 0.14), 0
   ; node:bass_drum_distorted_amplitude opcode:upsamp
   a_bass_drum_distorted_amplitude_aout_17 upsamp (((k_bass_drum_distorted_decay_kenv_6 * k_bass_drum_distorted_gate_kenv_5) * i_velocity_iamp_3) * 0.47)
   ; node:bass_drum_distorted_tone opcode:oscili
   a_bass_drum_distorted_tone_asig_10 oscili 1, (k_bass_drum_distorted_pitch_kenv_7 * i_1a9be505_b7fe_4d12_a783_60346b810c6a_iout_7), -1
   ; node:bass_drum_distorted_click_filter opcode:butterbp
   a_bass_drum_distorted_click_filter_aout_12 butterbp a_bass_drum_distorted_click_aout_11, 2200, 2500, 0
   ; node:bass_drum_distorted_mix opcode:mix2
   a_bass_drum_distorted_mix_aout_13 = (a_bass_drum_distorted_tone_asig_10) + (a_bass_drum_distorted_click_filter_aout_12)
   ; node:bass_drum_distorted_drive opcode:distort1
   a_bass_drum_distorted_drive_aout_14 distort1 a_bass_drum_distorted_mix_aout_13, i_ddccf62d_f9e6_49f3_a0dc_f438c7783415_iout_4, i_460f9e29_fa38_4055_8f7b_c9f7d7ebe7aa_iout_5, 0, 0, 1
   ; node:bass_drum_distorted_lowpass opcode:butterlp
   a_bass_drum_distorted_lowpass_aout_15 butterlp a_bass_drum_distorted_drive_aout_14, 3800, 0
   ; node:bass_drum_distorted_dc_filter opcode:butterhp
   a_bass_drum_distorted_dc_filter_aout_16 butterhp a_bass_drum_distorted_lowpass_aout_15, 22, 0
   ; node:bass_drum_distorted_pan opcode:pan2
   a_bass_drum_distorted_pan_aleft_18, a_bass_drum_distorted_pan_aright_19 pan2 (a_bass_drum_distorted_dc_filter_aout_16 * a_bass_drum_distorted_amplitude_aout_17), 0.5, 0
   a_kit_left_1 = a_bass_drum_distorted_pan_aleft_18
   a_kit_right_2 = a_bass_drum_distorted_pan_aright_19
 elseif (i_note_inote_1) == 46.0 then
   ; case:hihat_open Hi-hat open
   ; node:hihat_open_air opcode:noise
   a_hihat_open_air_aout_26 noise 0.24, 0
   ; node:hihat_open_decay opcode:expseg
   k_hihat_open_decay_kenv_10 expseg 1, 0.21, 0.16, 0.48999999999999994, 0.0001
   ; node:hihat_open_gate opcode:linseg
   k_hihat_open_gate_kenv_9 linseg 0, 0.001, 1, 0.691, 1, 0.008, 0
   ; node:hihat_open_metal_1 opcode:vco2
   a_hihat_open_metal_1_asig_20 vco2 0.16, 205.3, 2, 0.5, 0.137, 0.5
   ; node:hihat_open_metal_2 opcode:vco2
   a_hihat_open_metal_2_asig_21 vco2 0.16, 304.4, 2, 0.5, 0.274, 0.5
   ; node:hihat_open_metal_3 opcode:vco2
   a_hihat_open_metal_3_asig_22 vco2 0.16, 369.6, 2, 0.5, 0.41100000000000003, 0.5
   ; node:hihat_open_metal_4 opcode:vco2
   a_hihat_open_metal_4_asig_23 vco2 0.16, 522.7, 2, 0.5, 0.548, 0.5
   ; node:hihat_open_metal_5 opcode:vco2
   a_hihat_open_metal_5_asig_24 vco2 0.16, 540.5, 2, 0.5, 0.685, 0.5
   ; node:hihat_open_metal_6 opcode:vco2
   a_hihat_open_metal_6_asig_25 vco2 0.16, 800, 2, 0.5, 0.8220000000000001, 0.5
   ; node:hihat_open_tail opcode:xtratim
   xtratim 0.725
   ; node:hihat_open_amplitude opcode:upsamp
   a_hihat_open_amplitude_aout_29 upsamp (((k_hihat_open_decay_kenv_10 * k_hihat_open_gate_kenv_9) * i_velocity_iamp_3) * 0.75)
   ; node:hihat_open_highpass opcode:butterhp
   a_hihat_open_highpass_aout_27 butterhp ((((((a_hihat_open_metal_1_asig_20 + a_hihat_open_metal_2_asig_21) + a_hihat_open_metal_3_asig_22) + a_hihat_open_metal_4_asig_23) + a_hihat_open_metal_5_asig_24) + a_hihat_open_metal_6_asig_25) + a_hihat_open_air_aout_26), 6500, 0
   ; node:hihat_open_lowpass opcode:butterlp
   a_hihat_open_lowpass_aout_28 butterlp a_hihat_open_highpass_aout_27, 12500, 0
   ; node:hihat_open_pan opcode:pan2
   a_hihat_open_pan_aleft_30, a_hihat_open_pan_aright_31 pan2 (a_hihat_open_lowpass_aout_28 * a_hihat_open_amplitude_aout_29), 0.55, 0
   a_kit_left_1 = a_hihat_open_pan_aleft_30
   a_kit_right_2 = a_hihat_open_pan_aright_31
 elseif (i_note_inote_1) == 42.0 then
   ; case:hihat_closed Hi-hat closed
   ; node:hihat_closed_air opcode:noise
   a_hihat_closed_air_aout_38 noise 0.24, 0
   ; node:hihat_closed_decay opcode:expseg
   k_hihat_closed_decay_kenv_12 expseg 1, 0.025500000000000002, 0.16, 0.0595, 0.0001
   ; node:hihat_closed_gate opcode:linseg
   k_hihat_closed_gate_kenv_11 linseg 0, 0.001, 1, 0.07600000000000001, 1, 0.008, 0
   ; node:hihat_closed_metal_1 opcode:vco2
   a_hihat_closed_metal_1_asig_32 vco2 0.16, 205.3, 2, 0.5, 0.137, 0.5
   ; node:hihat_closed_metal_2 opcode:vco2
   a_hihat_closed_metal_2_asig_33 vco2 0.16, 304.4, 2, 0.5, 0.274, 0.5
   ; node:hihat_closed_metal_3 opcode:vco2
   a_hihat_closed_metal_3_asig_34 vco2 0.16, 369.6, 2, 0.5, 0.41100000000000003, 0.5
   ; node:hihat_closed_metal_4 opcode:vco2
   a_hihat_closed_metal_4_asig_35 vco2 0.16, 522.7, 2, 0.5, 0.548, 0.5
   ; node:hihat_closed_metal_5 opcode:vco2
   a_hihat_closed_metal_5_asig_36 vco2 0.16, 540.5, 2, 0.5, 0.685, 0.5
   ; node:hihat_closed_metal_6 opcode:vco2
   a_hihat_closed_metal_6_asig_37 vco2 0.16, 800, 2, 0.5, 0.8220000000000001, 0.5
   ; node:hihat_closed_tail opcode:xtratim
   xtratim 0.11000000000000001
   ; node:hihat_closed_amplitude opcode:upsamp
   a_hihat_closed_amplitude_aout_41 upsamp (((k_hihat_closed_decay_kenv_12 * k_hihat_closed_gate_kenv_11) * i_velocity_iamp_3) * 0.75)
   ; node:hihat_closed_highpass opcode:butterhp
   a_hihat_closed_highpass_aout_39 butterhp ((((((a_hihat_closed_metal_1_asig_32 + a_hihat_closed_metal_2_asig_33) + a_hihat_closed_metal_3_asig_34) + a_hihat_closed_metal_4_asig_35) + a_hihat_closed_metal_5_asig_36) + a_hihat_closed_metal_6_asig_37) + a_hihat_closed_air_aout_38), 6500, 0
   ; node:hihat_closed_lowpass opcode:butterlp
   a_hihat_closed_lowpass_aout_40 butterlp a_hihat_closed_highpass_aout_39, 12500, 0
   ; node:hihat_closed_pan opcode:pan2
   a_hihat_closed_pan_aleft_42, a_hihat_closed_pan_aright_43 pan2 (a_hihat_closed_lowpass_aout_40 * a_hihat_closed_amplitude_aout_41), 0.55, 0
   a_kit_left_1 = a_hihat_closed_pan_aleft_42
   a_kit_right_2 = a_hihat_closed_pan_aright_43
 elseif (i_note_inote_1) == 38.0 then
   ; case:snare Snare
   ; node:snare_body_decay opcode:expseg
   k_snare_body_decay_kenv_15 expseg 1, 0.1, 0.0001
   ; node:snare_decay opcode:expseg
   k_snare_decay_kenv_14 expseg 1, 0.075, 0.16, 0.175, 0.0001
   ; node:snare_gate opcode:linseg
   k_snare_gate_kenv_13 linseg 0, 0.001, 1, 0.241, 1, 0.008, 0
   ; node:snare_pitch opcode:expseg
   k_snare_pitch_kenv_16 expseg 250, 0.018, 185
   ; node:snare_tail opcode:xtratim
   xtratim 0.275
   ; node:snare_wires opcode:noise
   a_snare_wires_aout_46 noise 1, 0
   ; node:snare_overtone opcode:oscili
   a_snare_overtone_asig_45 oscili (k_snare_body_decay_kenv_15 * 0.28), 330, -1
   ; node:snare_amplitude opcode:upsamp
   a_snare_amplitude_aout_50 upsamp (((k_snare_decay_kenv_14 * k_snare_gate_kenv_13) * i_velocity_iamp_3) * 0.42)
   ; node:snare_body opcode:oscili
   a_snare_body_asig_44 oscili (k_snare_body_decay_kenv_15 * 0.7), k_snare_pitch_kenv_16, -1
   ; node:snare_highpass opcode:butterhp
   a_snare_highpass_aout_47 butterhp a_snare_wires_aout_46, 1100, 0
   ; node:snare_lowpass opcode:butterlp
   a_snare_lowpass_aout_48 butterlp a_snare_highpass_aout_47, 8500, 0
   ; node:snare_mix opcode:mix2
   a_snare_mix_aout_49 = ((a_snare_body_asig_44 + a_snare_overtone_asig_45)) + (a_snare_lowpass_aout_48)
   ; node:snare_pan opcode:pan2
   a_snare_pan_aleft_51, a_snare_pan_aright_52 pan2 (a_snare_mix_aout_49 * a_snare_amplitude_aout_50), 0.5, 0
   a_kit_left_1 = a_snare_pan_aleft_51
   a_kit_right_2 = a_snare_pan_aright_52
 else
   ; case:default Default
   a_kit_left_1 = 0
   a_kit_right_2 = 0
 endif
 a_output_left_asignal_53 = (a_kit_left_1 * 3)
 a_output_right_asignal_54 = (a_kit_right_2 * 3)
 ; node:output_left opcode:outleta
 outleta "left", a_output_left_asignal_53
 ; node:output_right opcode:outleta
 outleta "right", a_output_right_asignal_54
endin

; mixer stage patch:glints
; patch:fac3faea-086f-448c-9581-8692bc30cca1 name:EBM DW — Glass Bell channel:7 always_on:false
; instance:glints csound:vcs_mix_c0bf79aa1787b85d72e90369
; description: Cold glass bell with an inharmonic two-operator FM strike, decaying brightness and dark echoes/reverb. Suggested MIDI 48–88. Velocity-sensitive; settings apply to new notes. Motion rates are Hz; echoes are fixed time. Route Stereo Output through the mixer to Master.
; trigger: MIDI channel 7 / score notes; score instrument number: 4
instr vcs_mix_c0bf79aa1787b85d72e90369
 i_ctl_attack_iout_5 chnget "__vcs_perf_7bed4733f2cf30ab8ececa1d061911d769efcf74c6a49d1363352814d8091472"
 i_ctl_decay_iout_9 chnget "__vcs_perf_4255b4799c2baaaf696d06577c5498543050bfad2e3c9df38feb483a5ce61527"
 i_ctl_fm_depth_iout_8 chnget "__vcs_perf_c9a8118403c5574b0b1d67f4efeae02fab27ff5b77321aa79b10229307175559"
 i_ctl_ratio_iout_7 chnget "__vcs_perf_9d08305573089857d94b349a6d4a4d1065452491475f587164539f8b97c99b81"
 i_ctl_release_iout_6 chnget "__vcs_perf_aad91d389043ff39f61e83a540ef1ff51ba1b339b9a30ff2cb86fbb90071bdfb"
 i_ctl_space_iout_11 chnget "__vcs_perf_bc7d83397c1478f832e5730a3fadc9b5b8f3ab7080c0f65681c43415706500a4"
 i_ctl_tone_iout_10 chnget "__vcs_perf_b46a371f9eccb05e777dad1449cbe3ec085a046adde92c0acc50c8aee0494010"
 ; node:env_sustain_const opcode:const_i
 i_env_sustain_const_iout_4 = 0.0
 ; node:fm_gain opcode:const_k
 k_fm_gain_kout_3 = 0.18
 ; node:pitch_cpsmidi opcode:cpsmidi
 i_pitch_cpsmidi_kfreq_1 cpsmidi
 ; node:velocity_scale_const opcode:const_i
 i_velocity_scale_const_iout_2 = 1.0
 ; node:fm_decay_envelope opcode:linseg
 k_fm_decay_envelope_kenv_5 linseg 1, i_ctl_decay_iout_9, 0
 ; node:effect_tail opcode:xtratim
 xtratim (i_ctl_release_iout_6 + 8.8)
 ; node:audio_ctl_space_iout opcode:k_to_a
 a_audio_ctl_space_iout_aout_12 interp i_ctl_space_iout_11
 ; node:amp_madsr opcode:madsr
 k_amp_madsr_kenv_1 madsr i_ctl_attack_iout_5, i_ctl_decay_iout_9, i_env_sustain_const_iout_4, i_ctl_release_iout_6, 0, -1
 ; node:velocity_ampmidi opcode:ampmidi
 i_velocity_ampmidi_iamp_3 ampmidi i_velocity_scale_const_iout_2
 ; node:amp_velocity_envelope opcode:k_mul
 k_amp_velocity_envelope_kout_2 = (i_velocity_ampmidi_iamp_3) * (k_amp_madsr_kenv_1)
 ; node:fm_amp opcode:k_mul
 k_fm_amp_kout_4 = (k_amp_velocity_envelope_kout_2) * (k_fm_gain_kout_3)
 ; node:fm_foscili opcode:foscili
 a_fm_foscili_asig_1 foscili k_fm_amp_kout_4, i_pitch_cpsmidi_kfreq_1, 1, i_ctl_ratio_iout_7, (i_ctl_fm_depth_iout_8 * ((.04 + (.96 * k_fm_decay_envelope_kenv_5)))), 1, 0
 ; node:voice_filter opcode:moogladder2
 a_voice_filter_aout_4 moogladder2 a_fm_foscili_asig_1, i_ctl_tone_iout_10, 0.18
 ; node:dc_filter opcode:butterhp
 a_dc_filter_aout_5 butterhp a_voice_filter_aout_4, 22, 0
 ; node:output_pan2 opcode:pan2
 a_output_pan2_aleft_2, a_output_pan2_aright_3 pan2 a_dc_filter_aout_5, 0.5, 0
 ; node:echo_left_1 opcode:delay
 a_echo_left_1_aout_6 delay a_output_pan2_aleft_2, 0.27, 0
 ; node:echo_left_2 opcode:delay
 a_echo_left_2_aout_8 delay a_output_pan2_aleft_2, 0.54, 0
 ; node:echo_left_3 opcode:delay
 a_echo_left_3_aout_10 delay a_output_pan2_aleft_2, 0.81, 0
 ; node:echo_right_1 opcode:delay
 a_echo_right_1_aout_18 delay a_output_pan2_aright_3, 0.36, 0
 ; node:echo_right_2 opcode:delay
 a_echo_right_2_aout_20 delay a_output_pan2_aright_3, 0.72, 0
 ; node:echo_right_3 opcode:delay
 a_echo_right_3_aout_22 delay a_output_pan2_aright_3, 1.08, 0
 ; node:echo_tone_left_1 opcode:butterlp
 a_echo_tone_left_1_aout_7 butterlp a_echo_left_1_aout_6, 2900, 0
 ; node:echo_tone_left_2 opcode:butterlp
 a_echo_tone_left_2_aout_9 butterlp a_echo_left_2_aout_8, 2400, 0
 ; node:echo_tone_left_3 opcode:butterlp
 a_echo_tone_left_3_aout_11 butterlp a_echo_left_3_aout_10, 1900, 0
 ; node:echo_tone_right_1 opcode:butterlp
 a_echo_tone_right_1_aout_19 butterlp a_echo_right_1_aout_18, 2900, 0
 ; node:echo_tone_right_2 opcode:butterlp
 a_echo_tone_right_2_aout_21 butterlp a_echo_right_2_aout_20, 2400, 0
 ; node:echo_tone_right_3 opcode:butterlp
 a_echo_tone_right_3_aout_23 butterlp a_echo_right_3_aout_22, 1900, 0
 ; node:echo_mix_left opcode:mix2
 a_echo_mix_left_aout_13 = ((a_output_pan2_aleft_2 + (a_audio_ctl_space_iout_aout_12 * ((((.5 * a_echo_tone_left_1_aout_7) + (.25 * a_echo_tone_left_2_aout_9)) + (.125 * a_echo_tone_left_3_aout_11)))))) + (0)
 ; node:echo_mix_right opcode:mix2
 a_echo_mix_right_aout_24 = ((a_output_pan2_aright_3 + (a_audio_ctl_space_iout_aout_12 * ((((.5 * a_echo_tone_right_1_aout_19) + (.25 * a_echo_tone_right_2_aout_21)) + (.125 * a_echo_tone_right_3_aout_23)))))) + (0)
 ; node:room_predelay_left opcode:delay
 a_room_predelay_left_aout_14 delay a_echo_mix_left_aout_13, 0.017, 0
 ; node:room_predelay_right opcode:delay
 a_room_predelay_right_aout_25 delay a_echo_mix_right_aout_24, 0.029, 0
 ; node:room_left opcode:reverb2
 a_room_left_aout_15 reverb2 a_room_predelay_left_aout_14, 2.2, 0.45, 0
 ; node:room_right opcode:reverb2
 a_room_right_aout_26 reverb2 a_room_predelay_right_aout_25, 2.0460000000000003, 0.45, 0
 ; node:room_mix_left opcode:mix2
 a_room_mix_left_aout_16 = ((a_echo_mix_left_aout_13 + (a_audio_ctl_space_iout_aout_12 * a_room_left_aout_15))) + (0)
 ; node:room_mix_right opcode:mix2
 a_room_mix_right_aout_27 = ((a_echo_mix_right_aout_24 + (a_audio_ctl_space_iout_aout_12 * a_room_right_aout_26))) + (0)
 ; node:final_level_left opcode:mix2
 a_final_level_left_aout_17 = ((a_room_mix_left_aout_16 * 0.65)) + (0)
 ; node:final_level_right opcode:mix2
 a_final_level_right_aout_28 = ((a_room_mix_right_aout_27 * 0.65)) + (0)
 ; node:output_left opcode:outleta
 outleta "left", a_final_level_left_aout_17
 ; node:output_right opcode:outleta
 outleta "right", a_final_level_right_aout_28
endin

; mixer stage patch:strikes
; patch:8602f55b-cd7f-4f32-bd8e-c01f998288ec name:EBM DW — Industrial Stab channel:2 always_on:false
; instance:strikes csound:vcs_mix_40643c4521cf1547a72d6c19
; description: Pitched metallic FM strike with a separate short noise transient, distortion and compact room ambience. Suggested MIDI 36–84. Velocity-sensitive; settings apply to new notes. Motion rates are Hz; echoes are fixed time. Route Stereo Output through the mixer to Master.
; trigger: MIDI channel 2 / score notes; score instrument number: 5
instr vcs_mix_40643c4521cf1547a72d6c19
 ; node:air_gain opcode:const_k
 k_air_gain_kout_5 = 0.14
 i_ctl_attack_iout_5 chnget "__vcs_perf_a175d18a9bfcdf60ae5c73352c3c40605b50ce1572548d8c5583537d7da998bf"
 i_ctl_clang_iout_7 chnget "__vcs_perf_537c2b19d48f44e1e424e723788277a9281b9d43b761511324aca7e27c725a8f"
 i_ctl_decay_iout_9 chnget "__vcs_perf_41701256ec3711e8d169d6e04dc8984eebafdf6fec36817d76642ead9de79f94"
 i_ctl_drive_iout_10 chnget "__vcs_perf_72ff4df4af243629f02ebf152735801f63433bb25c6eb1115e4f7c731c835bac"
 i_ctl_noise_iout_8 chnget "__vcs_perf_af6123d7fa41370276ec9390d19919a421a3408261eddb7c22e2abdc0f7fac87"
 i_ctl_release_iout_6 chnget "__vcs_perf_300ce86c7a2a5bf21b93f4f78df99ae98603f3ab81a9e81f8b444dcae1cb7a8f"
 i_ctl_space_iout_11 chnget "__vcs_perf_78be482781265d240aa9c90b6cd369403569b19994d084ea9a9d84042e0029b3"
 ; node:env_sustain_const opcode:const_i
 i_env_sustain_const_iout_4 = 0.0
 ; node:fm_gain opcode:const_k
 k_fm_gain_kout_3 = 0.17
 ; node:noise_transient opcode:linseg
 k_noise_transient_kenv_8 linseg 1, 0.055, 0
 ; node:pitch_cpsmidi opcode:cpsmidi
 i_pitch_cpsmidi_kfreq_1 cpsmidi
 ; node:velocity_scale_const opcode:const_i
 i_velocity_scale_const_iout_2 = 1.0
 ; node:fm_decay_envelope opcode:linseg
 k_fm_decay_envelope_kenv_7 linseg 1, i_ctl_decay_iout_9, 0
 ; node:effect_tail opcode:xtratim
 xtratim (i_ctl_release_iout_6 + 2.6)
 ; node:audio_ctl_space_iout opcode:k_to_a
 a_audio_ctl_space_iout_aout_11 interp i_ctl_space_iout_11
 ; node:amp_madsr opcode:madsr
 k_amp_madsr_kenv_1 madsr i_ctl_attack_iout_5, i_ctl_decay_iout_9, i_env_sustain_const_iout_4, i_ctl_release_iout_6, 0, -1
 ; node:velocity_ampmidi opcode:ampmidi
 i_velocity_ampmidi_iamp_3 ampmidi i_velocity_scale_const_iout_2
 ; node:amp_velocity_envelope opcode:k_mul
 k_amp_velocity_envelope_kout_2 = (i_velocity_ampmidi_iamp_3) * (k_amp_madsr_kenv_1)
 ; node:fm_amp opcode:k_mul
 k_fm_amp_kout_4 = (k_amp_velocity_envelope_kout_2) * (k_fm_gain_kout_3)
 ; node:air_amp opcode:k_mul
 k_air_amp_kout_6 = (((k_amp_velocity_envelope_kout_2 * i_ctl_noise_iout_8) * k_noise_transient_kenv_8)) * (k_air_gain_kout_5)
 ; node:fm_foscili opcode:foscili
 a_fm_foscili_asig_1 foscili k_fm_amp_kout_4, i_pitch_cpsmidi_kfreq_1, 1, 3.17, (i_ctl_clang_iout_7 * ((.04 + (.96 * k_fm_decay_envelope_kenv_7)))), 1, 0
 ; node:air_noise opcode:noise
 a_air_noise_aout_2 noise k_air_amp_kout_6, 0
 ; node:source_sum opcode:mix2
 a_source_sum_aout_5 = ((a_fm_foscili_asig_1 + a_air_noise_aout_2)) + (0)
 ; node:voice_filter opcode:moogladder2
 a_voice_filter_aout_6 moogladder2 a_source_sum_aout_5, 6500, 0.18
 ; node:saturation opcode:distort1
 a_saturation_aout_7 distort1 a_voice_filter_aout_6, (i_ctl_drive_iout_10 * 3), (1 / ((1 + (.55 * ((i_ctl_drive_iout_10 - 1)))))), 0, 0, 1
 ; node:dc_filter opcode:butterhp
 a_dc_filter_aout_8 butterhp a_saturation_aout_7, 22, 0
 ; node:output_pan2 opcode:pan2
 a_output_pan2_aleft_3, a_output_pan2_aright_4 pan2 a_dc_filter_aout_8, 0.5, 0
 ; node:room_predelay_left opcode:delay
 a_room_predelay_left_aout_9 delay a_output_pan2_aleft_3, 0.017, 0
 ; node:room_predelay_right opcode:delay
 a_room_predelay_right_aout_14 delay a_output_pan2_aright_4, 0.029, 0
 ; node:room_left opcode:reverb2
 a_room_left_aout_10 reverb2 a_room_predelay_left_aout_9, 0.65, 0.45, 0
 ; node:room_right opcode:reverb2
 a_room_right_aout_15 reverb2 a_room_predelay_right_aout_14, 0.6045, 0.45, 0
 ; node:room_mix_left opcode:mix2
 a_room_mix_left_aout_12 = ((a_output_pan2_aleft_3 + (a_audio_ctl_space_iout_aout_11 * a_room_left_aout_10))) + (0)
 ; node:room_mix_right opcode:mix2
 a_room_mix_right_aout_16 = ((a_output_pan2_aright_4 + (a_audio_ctl_space_iout_aout_11 * a_room_right_aout_15))) + (0)
 ; node:final_level_left opcode:mix2
 a_final_level_left_aout_13 = ((a_room_mix_left_aout_12 * 0.65)) + (0)
 ; node:final_level_right opcode:mix2
 a_final_level_right_aout_17 = ((a_room_mix_right_aout_16 * 0.65)) + (0)
 ; node:output_left opcode:outleta
 outleta "left", a_final_level_left_aout_13
 ; node:output_right opcode:outleta
 outleta "right", a_final_level_right_aout_17
endin

; mixer stage patch:sunlight
; patch:41eb999e-9cc4-4380-8086-3da9fdbcebd4 name:EBM DW — String Ensemble channel:5 always_on:false
; instance:sunlight csound:vcs_mix_b91f7fd7965b2dad388bba2b
; description: Melancholic three-layer string ensemble with independent stereo chorus movement and dark reverb. Suggested MIDI 43–84. Velocity-sensitive; settings apply to new notes. Motion rates are Hz; echoes are fixed time. Route Stereo Output through the mixer to Master.
; trigger: MIDI channel 5 / score notes; score instrument number: 6
instr vcs_mix_b91f7fd7965b2dad388bba2b
 ; node:chorus_left_lfo opcode:lfo
 k_chorus_left_lfo_kout_9 lfo 1, 0.23, 0
 ; node:chorus_right_lfo opcode:lfo
 k_chorus_right_lfo_kout_10 lfo 1, 0.31, 0
 i_ctl_attack_iout_6 chnget "__vcs_perf_622518ee3862adc8b3f17f9f476cb2f2ffea4a9a674789344b4157b98214220f"
 i_ctl_chorus_iout_10 chnget "__vcs_perf_51f0147aa9651daa68390eeaf615c4143ee60381a2140a2072b442729ae89563"
 i_ctl_detune_iout_9 chnget "__vcs_perf_2d271b61eb8a76a4b00bfc63dca62a85d5e34c2f874d9217297884a5b9933dd4"
 i_ctl_release_iout_7 chnget "__vcs_perf_14dbd30ed863c0239c6d1025f30671a2a5cabbd34ffe8b3938f26fe92b47035c"
 i_ctl_reverb_iout_11 chnget "__vcs_perf_82b6576be193ba69f5e97deb72fe5b2c1c990f4a4058aec23336e3f002cc2dc7"
 i_ctl_tone_iout_8 chnget "__vcs_perf_6095aa39c8df8873ec5f19f8b9ceb8601aeb7c970a46922ba5394f7ce22edf83"
 ; node:env_decay_const opcode:const_i
 i_env_decay_const_iout_4 = 1.2
 ; node:env_sustain_const opcode:const_i
 i_env_sustain_const_iout_5 = 0.8
 ; node:pitch_cpsmidi opcode:cpsmidi
 i_pitch_cpsmidi_kfreq_1 cpsmidi
 ; node:pulse_gain opcode:const_k
 k_pulse_gain_kout_7 = 0.065
 ; node:saw_a_gain opcode:const_k
 k_saw_a_gain_kout_3 = 0.09
 ; node:saw_b_gain opcode:const_k
 k_saw_b_gain_kout_5 = 0.09
 ; node:velocity_scale_const opcode:const_i
 i_velocity_scale_const_iout_2 = 1.0
 ; node:audio_ctl_chorus_iout opcode:k_to_a
 a_audio_ctl_chorus_iout_aout_10 interp i_ctl_chorus_iout_10
 ; node:effect_tail opcode:xtratim
 xtratim (i_ctl_release_iout_7 + 9.2)
 ; node:audio_ctl_reverb_iout opcode:k_to_a
 a_audio_ctl_reverb_iout_aout_14 interp i_ctl_reverb_iout_11
 ; node:amp_madsr opcode:madsr
 k_amp_madsr_kenv_1 madsr i_ctl_attack_iout_6, i_env_decay_const_iout_4, i_env_sustain_const_iout_5, i_ctl_release_iout_7, 0, -1
 ; node:velocity_ampmidi opcode:ampmidi
 i_velocity_ampmidi_iamp_3 ampmidi i_velocity_scale_const_iout_2
 ; node:amp_velocity_envelope opcode:k_mul
 k_amp_velocity_envelope_kout_2 = (i_velocity_ampmidi_iamp_3) * (k_amp_madsr_kenv_1)
 ; node:saw_a_amp opcode:k_mul
 k_saw_a_amp_kout_4 = (k_amp_velocity_envelope_kout_2) * (k_saw_a_gain_kout_3)
 ; node:saw_b_amp opcode:k_mul
 k_saw_b_amp_kout_6 = (k_amp_velocity_envelope_kout_2) * (k_saw_b_gain_kout_5)
 ; node:pulse_amp opcode:k_mul
 k_pulse_amp_kout_8 = (k_amp_velocity_envelope_kout_2) * (k_pulse_gain_kout_7)
 ; node:saw_a_vco2 opcode:vco2
 a_saw_a_vco2_asig_1 vco2 k_saw_a_amp_kout_4, (i_pitch_cpsmidi_kfreq_1 * ((1 + (((-1) * i_ctl_detune_iout_9) * 0.0005777895)))), 0, 0.5, 0, 0.5
 ; node:saw_b_vco2 opcode:vco2
 a_saw_b_vco2_asig_2 vco2 k_saw_b_amp_kout_6, (i_pitch_cpsmidi_kfreq_1 * ((1 + ((1 * i_ctl_detune_iout_9) * 0.0005777895)))), 0, 0.5, 0, 0.5
 ; node:pulse_vco2 opcode:vco2
 a_pulse_vco2_asig_3 vco2 k_pulse_amp_kout_8, i_pitch_cpsmidi_kfreq_1, 2, 0.5, 0, 0.5
 ; node:source_sum opcode:mix2
 a_source_sum_aout_6 = (((a_saw_a_vco2_asig_1 + a_saw_b_vco2_asig_2) + a_pulse_vco2_asig_3)) + (0)
 ; node:voice_filter opcode:moogladder2
 a_voice_filter_aout_7 moogladder2 a_source_sum_aout_6, i_ctl_tone_iout_8, 0.18
 ; node:dc_filter opcode:butterhp
 a_dc_filter_aout_8 butterhp a_voice_filter_aout_7, 22, 0
 ; node:output_pan2 opcode:pan2
 a_output_pan2_aleft_4, a_output_pan2_aright_5 pan2 a_dc_filter_aout_8, 0.5, 0
 ; node:chorus_left opcode:vdelay3
 a_chorus_left_aout_9 vdelay3 a_output_pan2_aleft_4, (14 + (3 * k_chorus_left_lfo_kout_9)), 35
 ; node:chorus_right opcode:vdelay3
 a_chorus_right_aout_17 vdelay3 a_output_pan2_aright_5, (19 + (3 * k_chorus_right_lfo_kout_10)), 35
 ; node:chorus_mix_left opcode:mix2
 a_chorus_mix_left_aout_11 = (((a_output_pan2_aleft_4 * ((1 - (.25 * a_audio_ctl_chorus_iout_aout_10)))) + ((a_chorus_left_aout_9 * .5) * a_audio_ctl_chorus_iout_aout_10))) + (0)
 ; node:chorus_mix_right opcode:mix2
 a_chorus_mix_right_aout_18 = (((a_output_pan2_aright_5 * ((1 - (.25 * a_audio_ctl_chorus_iout_aout_10)))) + ((a_chorus_right_aout_17 * .5) * a_audio_ctl_chorus_iout_aout_10))) + (0)
 ; node:room_predelay_left opcode:delay
 a_room_predelay_left_aout_12 delay a_chorus_mix_left_aout_11, 0.017, 0
 ; node:room_predelay_right opcode:delay
 a_room_predelay_right_aout_19 delay a_chorus_mix_right_aout_18, 0.029, 0
 ; node:room_left opcode:reverb2
 a_room_left_aout_13 reverb2 a_room_predelay_left_aout_12, 2.3, 0.45, 0
 ; node:room_right opcode:reverb2
 a_room_right_aout_20 reverb2 a_room_predelay_right_aout_19, 2.139, 0.45, 0
 ; node:room_mix_left opcode:mix2
 a_room_mix_left_aout_15 = ((a_chorus_mix_left_aout_11 + (a_audio_ctl_reverb_iout_aout_14 * a_room_left_aout_13))) + (0)
 ; node:room_mix_right opcode:mix2
 a_room_mix_right_aout_21 = ((a_chorus_mix_right_aout_18 + (a_audio_ctl_reverb_iout_aout_14 * a_room_right_aout_20))) + (0)
 ; node:final_level_left opcode:mix2
 a_final_level_left_aout_16 = ((a_room_mix_left_aout_15 * 0.45)) + (0)
 ; node:final_level_right opcode:mix2
 a_final_level_right_aout_22 = ((a_room_mix_right_aout_21 * 0.45)) + (0)
 ; node:output_left opcode:outleta
 outleta "left", a_final_level_left_aout_16
 ; node:output_right opcode:outleta
 outleta "right", a_final_level_right_aout_22
endin

; mixer stage patch:sunrays
; patch:612db40c-e83f-4d26-a447-b2efd391ff0d name:EBM DW — Analog Brass channel:6 always_on:false
; instance:sunrays csound:vcs_mix_91d317b8f793206966758b36
; description: Dramatic saw brass with a separate opening filter envelope and a quiet room tail. Suggested MIDI 43–79. Velocity-sensitive; settings apply to new notes. Motion rates are Hz; echoes are fixed time. Route Stereo Output through the mixer to Master.
; trigger: MIDI channel 6 / score notes; score instrument number: 7
instr vcs_mix_91d317b8f793206966758b36
 i_ctl_attack_iout_6 chnget "__vcs_perf_86cc378af9041d5294c29fb180a2a447071c085191121fb86d925c5c920f83d4"
 i_ctl_detune_iout_11 chnget "__vcs_perf_7bfe3a3bce6abc89f529fe690548d1de6d37a6906f707c07a5732e196818788f"
 i_ctl_filter_decay_iout_10 chnget "__vcs_perf_82ba3acdefcc6460f500231c4626a68f7f1d91c9601a5cfddd7f510d6801f9bf"
 i_ctl_filter_envelope_iout_9 chnget "__vcs_perf_99772fabed33c9193cc02a44d6d6f674521a18473e8e5a8cc3f5250477373958"
 i_ctl_release_iout_7 chnget "__vcs_perf_4fecc0c9b25b5fa647de6c824a65b6a7adb98a15406d418b5dd1c4ddcb954d76"
 i_ctl_space_iout_12 chnget "__vcs_perf_64c2b17f354e4038455ce71c6c7c49230ef5af9c620e4541d59a4cc898d10b48"
 i_ctl_tone_iout_8 chnget "__vcs_perf_d959aaca533b2b7656b57cacc21119939ad9308c4925af04cec1940da7079c69"
 ; node:env_decay_const opcode:const_i
 i_env_decay_const_iout_4 = 0.3
 ; node:env_sustain_const opcode:const_i
 i_env_sustain_const_iout_5 = 0.6
 ; node:pitch_cpsmidi opcode:cpsmidi
 i_pitch_cpsmidi_kfreq_1 cpsmidi
 ; node:saw_a_gain opcode:const_k
 k_saw_a_gain_kout_3 = 0.12
 ; node:saw_b_gain opcode:const_k
 k_saw_b_gain_kout_5 = 0.12
 ; node:velocity_scale_const opcode:const_i
 i_velocity_scale_const_iout_2 = 1.0
 ; node:filter_decay_envelope opcode:linseg
 k_filter_decay_envelope_kenv_7 linseg 0, .015, 1, i_ctl_filter_decay_iout_10, 0.12
 ; node:effect_tail opcode:xtratim
 xtratim (i_ctl_release_iout_7 + 3.2)
 ; node:audio_ctl_space_iout opcode:k_to_a
 a_audio_ctl_space_iout_aout_10 interp i_ctl_space_iout_12
 ; node:amp_madsr opcode:madsr
 k_amp_madsr_kenv_1 madsr i_ctl_attack_iout_6, i_env_decay_const_iout_4, i_env_sustain_const_iout_5, i_ctl_release_iout_7, 0, -1
 ; node:velocity_ampmidi opcode:ampmidi
 i_velocity_ampmidi_iamp_3 ampmidi i_velocity_scale_const_iout_2
 ; node:amp_velocity_envelope opcode:k_mul
 k_amp_velocity_envelope_kout_2 = (i_velocity_ampmidi_iamp_3) * (k_amp_madsr_kenv_1)
 ; node:saw_a_amp opcode:k_mul
 k_saw_a_amp_kout_4 = (k_amp_velocity_envelope_kout_2) * (k_saw_a_gain_kout_3)
 ; node:saw_b_amp opcode:k_mul
 k_saw_b_amp_kout_6 = (k_amp_velocity_envelope_kout_2) * (k_saw_b_gain_kout_5)
 ; node:saw_a_vco2 opcode:vco2
 a_saw_a_vco2_asig_1 vco2 k_saw_a_amp_kout_4, (i_pitch_cpsmidi_kfreq_1 * ((1 + (((-1) * i_ctl_detune_iout_11) * 0.0005777895)))), 0, 0.5, 0, 0.5
 ; node:saw_b_vco2 opcode:vco2
 a_saw_b_vco2_asig_2 vco2 k_saw_b_amp_kout_6, (i_pitch_cpsmidi_kfreq_1 * ((1 + ((1 * i_ctl_detune_iout_11) * 0.0005777895)))), 0, 0.5, 0, 0.5
 ; node:source_sum opcode:mix2
 a_source_sum_aout_5 = ((a_saw_a_vco2_asig_1 + a_saw_b_vco2_asig_2)) + (0)
 ; node:voice_filter opcode:moogladder2
 a_voice_filter_aout_6 moogladder2 a_source_sum_aout_5, (i_ctl_tone_iout_8 + (i_ctl_filter_envelope_iout_9 * k_filter_decay_envelope_kenv_7)), 0.18
 ; node:dc_filter opcode:butterhp
 a_dc_filter_aout_7 butterhp a_voice_filter_aout_6, 22, 0
 ; node:output_pan2 opcode:pan2
 a_output_pan2_aleft_3, a_output_pan2_aright_4 pan2 a_dc_filter_aout_7, 0.5, 0
 ; node:room_predelay_left opcode:delay
 a_room_predelay_left_aout_8 delay a_output_pan2_aleft_3, 0.017, 0
 ; node:room_predelay_right opcode:delay
 a_room_predelay_right_aout_13 delay a_output_pan2_aright_4, 0.029, 0
 ; node:room_left opcode:reverb2
 a_room_left_aout_9 reverb2 a_room_predelay_left_aout_8, 0.8, 0.45, 0
 ; node:room_right opcode:reverb2
 a_room_right_aout_14 reverb2 a_room_predelay_right_aout_13, 0.7440000000000001, 0.45, 0
 ; node:room_mix_left opcode:mix2
 a_room_mix_left_aout_11 = ((a_output_pan2_aleft_3 + (a_audio_ctl_space_iout_aout_10 * a_room_left_aout_9))) + (0)
 ; node:room_mix_right opcode:mix2
 a_room_mix_right_aout_15 = ((a_output_pan2_aright_4 + (a_audio_ctl_space_iout_aout_10 * a_room_right_aout_14))) + (0)
 ; node:final_level_left opcode:mix2
 a_final_level_left_aout_12 = ((a_room_mix_left_aout_11 * 0.65)) + (0)
 ; node:final_level_right opcode:mix2
 a_final_level_right_aout_16 = ((a_room_mix_right_aout_15 * 0.65)) + (0)
 ; node:output_left opcode:outleta
 outleta "left", a_final_level_left_aout_12
 ; node:output_right opcode:outleta
 outleta "right", a_final_level_right_aout_16
endin

; mixer stage patch:theme
; patch:fd59788a-4a07-4515-8ef6-977fe69ec569 name:EBM DW — Dark Saw Lead channel:4 always_on:false
; instance:theme csound:vcs_mix_b9e4b05138bfb5ddfecff5e1
; description: Cold expressive saw lead with modest detune, subtle vibrato, animated stereo chorus and quiet filtered echoes. Suggested MIDI 48–84. Velocity-sensitive; settings apply to new notes. Motion rates are Hz; echoes are fixed time. Route Stereo Output through the mixer to Master.
; trigger: MIDI channel 4 / score notes; score instrument number: 8
instr vcs_mix_b9e4b05138bfb5ddfecff5e1
 ; node:chorus_left_lfo opcode:lfo
 k_chorus_left_lfo_kout_9 lfo 1, 0.23, 0
 ; node:chorus_right_lfo opcode:lfo
 k_chorus_right_lfo_kout_10 lfo 1, 0.31, 0
 i_ctl_attack_iout_6 chnget "__vcs_perf_2693177ded5b3704bc870384173a72470fa3a13e6144717854f4ac738b76f410"
 i_ctl_chorus_iout_11 chnget "__vcs_perf_fa8a70d97431f3f6f5fce3a5432ef703e1b598ea68a3d5e09b6c1ecedf441a6e"
 i_ctl_detune_iout_9 chnget "__vcs_perf_789e61ba750aee5900aaa96e284eb96bdc9cb40bb441ce6d2fdb57b52575c586"
 i_ctl_echo_iout_12 chnget "__vcs_perf_0294b3b47f66a9344cca1a5a51883b7e317cc1b65ecb77149d574ea73b0b5164"
 i_ctl_release_iout_7 chnget "__vcs_perf_efd680873290a7110225cf770c00597f7560977a50b17fa760838a8cf73e0277"
 i_ctl_tone_iout_8 chnget "__vcs_perf_b18357a98b0c231b8a2e7613ff04e4358d691722ebe869470e9a694fda744a9e"
 i_ctl_vibrato_iout_10 chnget "__vcs_perf_3dfb949bdf5981a798b597953f83889a8d82fded009fbb9ac6bc96de1f879192"
 ; node:env_decay_const opcode:const_i
 i_env_decay_const_iout_4 = 0.25
 ; node:env_sustain_const opcode:const_i
 i_env_sustain_const_iout_5 = 0.65
 ; node:pitch_cpsmidi opcode:cpsmidi
 i_pitch_cpsmidi_kfreq_1 cpsmidi
 ; node:saw_a_gain opcode:const_k
 k_saw_a_gain_kout_3 = 0.12
 ; node:saw_b_gain opcode:const_k
 k_saw_b_gain_kout_5 = 0.12
 ; node:velocity_scale_const opcode:const_i
 i_velocity_scale_const_iout_2 = 1.0
 ; node:vibrato_lfo opcode:lfo
 k_vibrato_lfo_kout_7 lfo 1, 5.2, 0
 ; node:audio_ctl_chorus_iout opcode:k_to_a
 a_audio_ctl_chorus_iout_aout_9 interp i_ctl_chorus_iout_11
 ; node:audio_ctl_echo_iout opcode:k_to_a
 a_audio_ctl_echo_iout_aout_17 interp i_ctl_echo_iout_12
 ; node:effect_tail opcode:xtratim
 xtratim (i_ctl_release_iout_7 + 2)
 ; node:amp_madsr opcode:madsr
 k_amp_madsr_kenv_1 madsr i_ctl_attack_iout_6, i_env_decay_const_iout_4, i_env_sustain_const_iout_5, i_ctl_release_iout_7, 0, -1
 ; node:velocity_ampmidi opcode:ampmidi
 i_velocity_ampmidi_iamp_3 ampmidi i_velocity_scale_const_iout_2
 ; node:vibrato_depth opcode:k_mul
 k_vibrato_depth_kout_8 = ((k_vibrato_lfo_kout_7 * i_ctl_vibrato_iout_10)) * (1)
 ; node:amp_velocity_envelope opcode:k_mul
 k_amp_velocity_envelope_kout_2 = (i_velocity_ampmidi_iamp_3) * (k_amp_madsr_kenv_1)
 ; node:saw_a_amp opcode:k_mul
 k_saw_a_amp_kout_4 = (k_amp_velocity_envelope_kout_2) * (k_saw_a_gain_kout_3)
 ; node:saw_b_amp opcode:k_mul
 k_saw_b_amp_kout_6 = (k_amp_velocity_envelope_kout_2) * (k_saw_b_gain_kout_5)
 ; node:saw_a_vco2 opcode:vco2
 a_saw_a_vco2_asig_1 vco2 k_saw_a_amp_kout_4, ((i_pitch_cpsmidi_kfreq_1 * ((1 + (((-1) * i_ctl_detune_iout_9) * 0.0005777895)))) * ((1 + (k_vibrato_depth_kout_8 * 0.0005777895)))), 0, 0.5, 0, 0.5
 ; node:saw_b_vco2 opcode:vco2
 a_saw_b_vco2_asig_2 vco2 k_saw_b_amp_kout_6, ((i_pitch_cpsmidi_kfreq_1 * ((1 + ((1 * i_ctl_detune_iout_9) * 0.0005777895)))) * ((1 + (k_vibrato_depth_kout_8 * 0.0005777895)))), 0, 0.5, 0, 0.5
 ; node:source_sum opcode:mix2
 a_source_sum_aout_5 = ((a_saw_a_vco2_asig_1 + a_saw_b_vco2_asig_2)) + (0)
 ; node:voice_filter opcode:moogladder2
 a_voice_filter_aout_6 moogladder2 a_source_sum_aout_5, i_ctl_tone_iout_8, 0.18
 ; node:dc_filter opcode:butterhp
 a_dc_filter_aout_7 butterhp a_voice_filter_aout_6, 22, 0
 ; node:output_pan2 opcode:pan2
 a_output_pan2_aleft_3, a_output_pan2_aright_4 pan2 a_dc_filter_aout_7, 0.5, 0
 ; node:chorus_left opcode:vdelay3
 a_chorus_left_aout_8 vdelay3 a_output_pan2_aleft_3, (14 + (3 * k_chorus_left_lfo_kout_9)), 35
 ; node:chorus_right opcode:vdelay3
 a_chorus_right_aout_20 vdelay3 a_output_pan2_aright_4, (19 + (3 * k_chorus_right_lfo_kout_10)), 35
 ; node:chorus_mix_left opcode:mix2
 a_chorus_mix_left_aout_10 = (((a_output_pan2_aleft_3 * ((1 - (.25 * a_audio_ctl_chorus_iout_aout_9)))) + ((a_chorus_left_aout_8 * .5) * a_audio_ctl_chorus_iout_aout_9))) + (0)
 ; node:chorus_mix_right opcode:mix2
 a_chorus_mix_right_aout_21 = (((a_output_pan2_aright_4 * ((1 - (.25 * a_audio_ctl_chorus_iout_aout_9)))) + ((a_chorus_right_aout_20 * .5) * a_audio_ctl_chorus_iout_aout_9))) + (0)
 ; node:echo_left_1 opcode:delay
 a_echo_left_1_aout_11 delay a_chorus_mix_left_aout_10, 0.27, 0
 ; node:echo_left_2 opcode:delay
 a_echo_left_2_aout_13 delay a_chorus_mix_left_aout_10, 0.54, 0
 ; node:echo_left_3 opcode:delay
 a_echo_left_3_aout_15 delay a_chorus_mix_left_aout_10, 0.81, 0
 ; node:echo_right_1 opcode:delay
 a_echo_right_1_aout_22 delay a_chorus_mix_right_aout_21, 0.36, 0
 ; node:echo_right_2 opcode:delay
 a_echo_right_2_aout_24 delay a_chorus_mix_right_aout_21, 0.72, 0
 ; node:echo_right_3 opcode:delay
 a_echo_right_3_aout_26 delay a_chorus_mix_right_aout_21, 1.08, 0
 ; node:echo_tone_left_1 opcode:butterlp
 a_echo_tone_left_1_aout_12 butterlp a_echo_left_1_aout_11, 2900, 0
 ; node:echo_tone_left_2 opcode:butterlp
 a_echo_tone_left_2_aout_14 butterlp a_echo_left_2_aout_13, 2400, 0
 ; node:echo_tone_left_3 opcode:butterlp
 a_echo_tone_left_3_aout_16 butterlp a_echo_left_3_aout_15, 1900, 0
 ; node:echo_tone_right_1 opcode:butterlp
 a_echo_tone_right_1_aout_23 butterlp a_echo_right_1_aout_22, 2900, 0
 ; node:echo_tone_right_2 opcode:butterlp
 a_echo_tone_right_2_aout_25 butterlp a_echo_right_2_aout_24, 2400, 0
 ; node:echo_tone_right_3 opcode:butterlp
 a_echo_tone_right_3_aout_27 butterlp a_echo_right_3_aout_26, 1900, 0
 ; node:echo_mix_left opcode:mix2
 a_echo_mix_left_aout_18 = ((a_chorus_mix_left_aout_10 + (a_audio_ctl_echo_iout_aout_17 * ((((.5 * a_echo_tone_left_1_aout_12) + (.25 * a_echo_tone_left_2_aout_14)) + (.125 * a_echo_tone_left_3_aout_16)))))) + (0)
 ; node:echo_mix_right opcode:mix2
 a_echo_mix_right_aout_28 = ((a_chorus_mix_right_aout_21 + (a_audio_ctl_echo_iout_aout_17 * ((((.5 * a_echo_tone_right_1_aout_23) + (.25 * a_echo_tone_right_2_aout_25)) + (.125 * a_echo_tone_right_3_aout_27)))))) + (0)
 ; node:final_level_left opcode:mix2
 a_final_level_left_aout_19 = ((a_echo_mix_left_aout_18 * 0.75)) + (0)
 ; node:final_level_right opcode:mix2
 a_final_level_right_aout_29 = ((a_echo_mix_right_aout_28 * 0.75)) + (0)
 ; node:output_left opcode:outleta
 outleta "left", a_final_level_left_aout_19
 ; node:output_right opcode:outleta
 outleta "right", a_final_level_right_aout_29
endin

; mixer stage patch:weather
; patch:e77f6354-8a77-4473-850c-91758ee210d0 name:EBM DW — Noise Metal FX channel:8 always_on:false
; instance:weather csound:vcs_mix_1dc1baf55c97903a3ec0b1d9
; description: Sustained mechanical noise/FM texture with slow spectral sweeps and dark ambience. Note pitch controls the metal layer. Suggested MIDI 36–79. Velocity-sensitive; settings apply to new notes. Motion rates are Hz; echoes are fixed time. Route Stereo Output through the mixer to Master.
; trigger: MIDI channel 8 / score notes; score instrument number: 9
instr vcs_mix_1dc1baf55c97903a3ec0b1d9
 ; node:air_gain opcode:const_k
 k_air_gain_kout_5 = 0.18
 i_ctl_attack_iout_6 chnget "__vcs_perf_cb7fe217f51092eabaf2b7e443277b31ad0bebfeac4f31e14ec648ac482e838c"
 i_ctl_color_iout_9 chnget "__vcs_perf_fef2b0c230c35dfb2d5c49ddf3168e31bce090e1dd122fe32e3705f8d0d670bc"
 i_ctl_metal_blend_iout_8 chnget "__vcs_perf_760f28410509b22de02893ffd96a9dc3b5fd6652ddc31ce462a827853871ec61"
 i_ctl_motion_rate_iout_11 chnget "__vcs_perf_580886d291fd5f84198c055bfe90349487f8b28ebe0eaacbc5f2c5d62078aed8"
 i_ctl_release_iout_7 chnget "__vcs_perf_a9715bcb9e537a012079e8c1fae8e7c69106df97e14681c5583532445934cfea"
 i_ctl_space_iout_12 chnget "__vcs_perf_5a94f773f39f1a4865b25302f4f87693ed0ba505352f39638a974aecad3d977c"
 i_ctl_sweep_depth_iout_10 chnget "__vcs_perf_d0026d433be3faabd992ea1dbca7ead5727b4816009a9f1ee44c1aecf507da2f"
 ; node:env_decay_const opcode:const_i
 i_env_decay_const_iout_4 = 1.0
 ; node:env_sustain_const opcode:const_i
 i_env_sustain_const_iout_5 = 0.7
 ; node:fm_gain opcode:const_k
 k_fm_gain_kout_3 = 0.16
 ; node:pitch_cpsmidi opcode:cpsmidi
 i_pitch_cpsmidi_kfreq_1 cpsmidi
 ; node:velocity_scale_const opcode:const_i
 i_velocity_scale_const_iout_2 = 1.0
 ; node:motion_lfo opcode:lfo
 k_motion_lfo_kout_7 lfo 1, i_ctl_motion_rate_iout_11, 0
 ; node:effect_tail opcode:xtratim
 xtratim (i_ctl_release_iout_7 + 10.8)
 ; node:audio_ctl_space_iout opcode:k_to_a
 a_audio_ctl_space_iout_aout_14 interp i_ctl_space_iout_12
 ; node:amp_madsr opcode:madsr
 k_amp_madsr_kenv_1 madsr i_ctl_attack_iout_6, i_env_decay_const_iout_4, i_env_sustain_const_iout_5, i_ctl_release_iout_7, 0, -1
 ; node:velocity_ampmidi opcode:ampmidi
 i_velocity_ampmidi_iamp_3 ampmidi i_velocity_scale_const_iout_2
 ; node:amp_velocity_envelope opcode:k_mul
 k_amp_velocity_envelope_kout_2 = (i_velocity_ampmidi_iamp_3) * (k_amp_madsr_kenv_1)
 ; node:fm_amp opcode:k_mul
 k_fm_amp_kout_4 = ((k_amp_velocity_envelope_kout_2 * i_ctl_metal_blend_iout_8)) * (k_fm_gain_kout_3)
 ; node:air_amp opcode:k_mul
 k_air_amp_kout_6 = ((k_amp_velocity_envelope_kout_2 * ((1 - i_ctl_metal_blend_iout_8)))) * (k_air_gain_kout_5)
 ; node:fm_foscili opcode:foscili
 a_fm_foscili_asig_1 foscili k_fm_amp_kout_4, i_pitch_cpsmidi_kfreq_1, 1, 2.718, (2.5 + ((1.5 * i_ctl_sweep_depth_iout_10) * k_motion_lfo_kout_7)), 1, 0
 ; node:air_noise opcode:noise
 a_air_noise_aout_2 noise k_air_amp_kout_6, 0
 ; node:source_sum opcode:mix2
 a_source_sum_aout_5 = ((a_fm_foscili_asig_1 + a_air_noise_aout_2)) + (0)
 ; node:voice_filter opcode:moogladder2
 a_voice_filter_aout_6 moogladder2 a_source_sum_aout_5, (i_ctl_color_iout_9 * ((1 + ((.65 * i_ctl_sweep_depth_iout_10) * k_motion_lfo_kout_7)))), 0.18
 ; node:dc_filter opcode:butterhp
 a_dc_filter_aout_7 butterhp a_voice_filter_aout_6, 22, 0
 ; node:output_pan2 opcode:pan2
 a_output_pan2_aleft_3, a_output_pan2_aright_4 pan2 a_dc_filter_aout_7, 0.5, 0
 ; node:echo_left_1 opcode:delay
 a_echo_left_1_aout_8 delay a_output_pan2_aleft_3, 0.27, 0
 ; node:echo_left_2 opcode:delay
 a_echo_left_2_aout_10 delay a_output_pan2_aleft_3, 0.54, 0
 ; node:echo_left_3 opcode:delay
 a_echo_left_3_aout_12 delay a_output_pan2_aleft_3, 0.81, 0
 ; node:echo_right_1 opcode:delay
 a_echo_right_1_aout_20 delay a_output_pan2_aright_4, 0.36, 0
 ; node:echo_right_2 opcode:delay
 a_echo_right_2_aout_22 delay a_output_pan2_aright_4, 0.72, 0
 ; node:echo_right_3 opcode:delay
 a_echo_right_3_aout_24 delay a_output_pan2_aright_4, 1.08, 0
 ; node:echo_tone_left_1 opcode:butterlp
 a_echo_tone_left_1_aout_9 butterlp a_echo_left_1_aout_8, 2900, 0
 ; node:echo_tone_left_2 opcode:butterlp
 a_echo_tone_left_2_aout_11 butterlp a_echo_left_2_aout_10, 2400, 0
 ; node:echo_tone_left_3 opcode:butterlp
 a_echo_tone_left_3_aout_13 butterlp a_echo_left_3_aout_12, 1900, 0
 ; node:echo_tone_right_1 opcode:butterlp
 a_echo_tone_right_1_aout_21 butterlp a_echo_right_1_aout_20, 2900, 0
 ; node:echo_tone_right_2 opcode:butterlp
 a_echo_tone_right_2_aout_23 butterlp a_echo_right_2_aout_22, 2400, 0
 ; node:echo_tone_right_3 opcode:butterlp
 a_echo_tone_right_3_aout_25 butterlp a_echo_right_3_aout_24, 1900, 0
 ; node:echo_mix_left opcode:mix2
 a_echo_mix_left_aout_15 = ((a_output_pan2_aleft_3 + (a_audio_ctl_space_iout_aout_14 * ((((.5 * a_echo_tone_left_1_aout_9) + (.25 * a_echo_tone_left_2_aout_11)) + (.125 * a_echo_tone_left_3_aout_13)))))) + (0)
 ; node:echo_mix_right opcode:mix2
 a_echo_mix_right_aout_26 = ((a_output_pan2_aright_4 + (a_audio_ctl_space_iout_aout_14 * ((((.5 * a_echo_tone_right_1_aout_21) + (.25 * a_echo_tone_right_2_aout_23)) + (.125 * a_echo_tone_right_3_aout_25)))))) + (0)
 ; node:room_predelay_left opcode:delay
 a_room_predelay_left_aout_16 delay a_echo_mix_left_aout_15, 0.017, 0
 ; node:room_predelay_right opcode:delay
 a_room_predelay_right_aout_27 delay a_echo_mix_right_aout_26, 0.029, 0
 ; node:room_left opcode:reverb2
 a_room_left_aout_17 reverb2 a_room_predelay_left_aout_16, 2.7, 0.45, 0
 ; node:room_right opcode:reverb2
 a_room_right_aout_28 reverb2 a_room_predelay_right_aout_27, 2.511, 0.45, 0
 ; node:room_mix_left opcode:mix2
 a_room_mix_left_aout_18 = ((a_echo_mix_left_aout_15 + (a_audio_ctl_space_iout_aout_14 * a_room_left_aout_17))) + (0)
 ; node:room_mix_right opcode:mix2
 a_room_mix_right_aout_29 = ((a_echo_mix_right_aout_26 + (a_audio_ctl_space_iout_aout_14 * a_room_right_aout_28))) + (0)
 ; node:final_level_left opcode:mix2
 a_final_level_left_aout_19 = ((a_room_mix_left_aout_18 * 0.6)) + (0)
 ; node:final_level_right opcode:mix2
 a_final_level_right_aout_30 = ((a_room_mix_right_aout_29 * 0.6)) + (0)
 ; node:output_left opcode:outleta
 outleta "left", a_final_level_left_aout_19
 ; node:output_right opcode:outleta
 outleta "right", a_final_level_right_aout_30
endin

; mixer stage strip:bass
; mixer strip: EBM DW — Sequencer Bass [bass]
; initial gain: -8 dB; balance/pan: 0; mute: false; solo: false
; Voices and insert returns sum before the strip; pre taps precede balance/fader, post taps follow them.
instr vcs_mix_d69e2b115c3aedc5f5e51463
 k_meter metro 15
 k_gain chnget "__vcs_mixer_strip_441349e1ec2f7fd0aa17267b_gain"
 a_gain vcs_mixer_ramp k_gain, 0.3981071705534972
 k_left chnget "__vcs_mixer_strip_441349e1ec2f7fd0aa17267b_left"
 a_left vcs_mixer_ramp k_left, 1
 k_right chnget "__vcs_mixer_strip_441349e1ec2f7fd0aa17267b_right"
 a_right vcs_mixer_ramp k_right, 1
 k_mute chnget "__vcs_mixer_strip_441349e1ec2f7fd0aa17267b_mute"
 a_mute vcs_mixer_ramp k_mute, 1
 a_p_360f84035942243c6a36537a inleta "p_360f84035942243c6a36537a"
 a_p_360f84035942243c6a36537a_post = a_p_360f84035942243c6a36537a * a_gain * a_left
 a_p_27042f4e6eca7d0b2a7ee402 inleta "p_27042f4e6eca7d0b2a7ee402"
 a_p_27042f4e6eca7d0b2a7ee402_post = a_p_27042f4e6eca7d0b2a7ee402 * a_gain * a_right
 a_meter_left = a_p_360f84035942243c6a36537a_post * a_mute
 a_meter_right = a_p_27042f4e6eca7d0b2a7ee402_post * a_mute
 k_peakL max_k a_meter_left, k_meter, 1
 k_rmsL rms a_meter_left
 chnset k_peakL / 1.0, "__vcs_mixer_meter_441349e1ec2f7fd0aa17267b_peakL"
 chnset k_rmsL / 1.0, "__vcs_mixer_meter_441349e1ec2f7fd0aa17267b_rmsL"
 k_peakR max_k a_meter_right, k_meter, 1
 k_rmsR rms a_meter_right
 chnset k_peakR / 1.0, "__vcs_mixer_meter_441349e1ec2f7fd0aa17267b_peakR"
 chnset k_rmsR / 1.0, "__vcs_mixer_meter_441349e1ec2f7fd0aa17267b_rmsR"
 outleta "pre_p_360f84035942243c6a36537a", a_p_360f84035942243c6a36537a
 outleta "post_p_360f84035942243c6a36537a", a_p_360f84035942243c6a36537a_post
 outleta "pre_p_27042f4e6eca7d0b2a7ee402", a_p_27042f4e6eca7d0b2a7ee402
 outleta "post_p_27042f4e6eca7d0b2a7ee402", a_p_27042f4e6eca7d0b2a7ee402_post
endin

; mixer stage route:bass-to-master-left
; audio route:bass-to-master-left kind:main
; from: EBM DW — Sequencer Bass [bass] port:left stage:strip -> Master [$master] port:left stage:input
; tap: post-fader; initial route gain: 0 dB; source mute and mixer solo gate this route.
instr vcs_mix_bf77b782450578498a75e856
 k_post chnget "__vcs_mixer_route_3e8014902b44dfaf5918f0cb_post"
 a_post vcs_mixer_ramp k_post, 1
 k_pan chnget "__vcs_mixer_route_3e8014902b44dfaf5918f0cb_pan"
 a_pan vcs_mixer_ramp k_pan, 1
 a_pre inleta "pre"
 a_post_signal inleta "post"
 a_signal = a_pre * (1 - a_post) + a_post_signal * a_post * a_pan
 k_send chnget "__vcs_mixer_route_3e8014902b44dfaf5918f0cb_gain"
 a_send vcs_mixer_ramp k_send, 1
 a_route_output = a_signal * a_send
 outleta "out", a_route_output
endin

; mixer stage route:bass-to-master-right
; audio route:bass-to-master-right kind:main
; from: EBM DW — Sequencer Bass [bass] port:right stage:strip -> Master [$master] port:right stage:input
; tap: post-fader; initial route gain: 0 dB; source mute and mixer solo gate this route.
instr vcs_mix_7d28de53beb30deccc25fc17
 k_post chnget "__vcs_mixer_route_c99934ba5158b7053b82b3c7_post"
 a_post vcs_mixer_ramp k_post, 1
 k_pan chnget "__vcs_mixer_route_c99934ba5158b7053b82b3c7_pan"
 a_pan vcs_mixer_ramp k_pan, 1
 a_pre inleta "pre"
 a_post_signal inleta "post"
 a_signal = a_pre * (1 - a_post) + a_post_signal * a_post * a_pan
 k_send chnget "__vcs_mixer_route_c99934ba5158b7053b82b3c7_gain"
 a_send vcs_mixer_ramp k_send, 1
 a_route_output = a_signal * a_send
 outleta "out", a_route_output
endin

; mixer stage strip:clouds
; mixer strip: EBM DW — Dark PWM Pad [clouds]
; initial gain: -8 dB; balance/pan: 0; mute: false; solo: false
; Voices and insert returns sum before the strip; pre taps precede balance/fader, post taps follow them.
instr vcs_mix_96411e998269110c17432444
 k_meter metro 15
 k_gain chnget "__vcs_mixer_strip_15fa97b5a488542761982797_gain"
 a_gain vcs_mixer_ramp k_gain, 0.3981071705534972
 k_left chnget "__vcs_mixer_strip_15fa97b5a488542761982797_left"
 a_left vcs_mixer_ramp k_left, 1
 k_right chnget "__vcs_mixer_strip_15fa97b5a488542761982797_right"
 a_right vcs_mixer_ramp k_right, 1
 k_mute chnget "__vcs_mixer_strip_15fa97b5a488542761982797_mute"
 a_mute vcs_mixer_ramp k_mute, 1
 a_p_360f84035942243c6a36537a inleta "p_360f84035942243c6a36537a"
 a_p_360f84035942243c6a36537a_post = a_p_360f84035942243c6a36537a * a_gain * a_left
 a_p_27042f4e6eca7d0b2a7ee402 inleta "p_27042f4e6eca7d0b2a7ee402"
 a_p_27042f4e6eca7d0b2a7ee402_post = a_p_27042f4e6eca7d0b2a7ee402 * a_gain * a_right
 a_meter_left = a_p_360f84035942243c6a36537a_post * a_mute
 a_meter_right = a_p_27042f4e6eca7d0b2a7ee402_post * a_mute
 k_peakL max_k a_meter_left, k_meter, 1
 k_rmsL rms a_meter_left
 chnset k_peakL / 1.0, "__vcs_mixer_meter_15fa97b5a488542761982797_peakL"
 chnset k_rmsL / 1.0, "__vcs_mixer_meter_15fa97b5a488542761982797_rmsL"
 k_peakR max_k a_meter_right, k_meter, 1
 k_rmsR rms a_meter_right
 chnset k_peakR / 1.0, "__vcs_mixer_meter_15fa97b5a488542761982797_peakR"
 chnset k_rmsR / 1.0, "__vcs_mixer_meter_15fa97b5a488542761982797_rmsR"
 outleta "pre_p_360f84035942243c6a36537a", a_p_360f84035942243c6a36537a
 outleta "post_p_360f84035942243c6a36537a", a_p_360f84035942243c6a36537a_post
 outleta "pre_p_27042f4e6eca7d0b2a7ee402", a_p_27042f4e6eca7d0b2a7ee402
 outleta "post_p_27042f4e6eca7d0b2a7ee402", a_p_27042f4e6eca7d0b2a7ee402_post
endin

; mixer stage route:clouds-to-master-left
; audio route:clouds-to-master-left kind:main
; from: EBM DW — Dark PWM Pad [clouds] port:left stage:strip -> Master [$master] port:left stage:input
; tap: post-fader; initial route gain: 0 dB; source mute and mixer solo gate this route.
instr vcs_mix_b99cad66f5a693384ddaaa91
 k_post chnget "__vcs_mixer_route_5c765a9573cccf11ec260943_post"
 a_post vcs_mixer_ramp k_post, 1
 k_pan chnget "__vcs_mixer_route_5c765a9573cccf11ec260943_pan"
 a_pan vcs_mixer_ramp k_pan, 1
 a_pre inleta "pre"
 a_post_signal inleta "post"
 a_signal = a_pre * (1 - a_post) + a_post_signal * a_post * a_pan
 k_send chnget "__vcs_mixer_route_5c765a9573cccf11ec260943_gain"
 a_send vcs_mixer_ramp k_send, 1
 a_route_output = a_signal * a_send
 outleta "out", a_route_output
endin

; mixer stage route:clouds-to-master-right
; audio route:clouds-to-master-right kind:main
; from: EBM DW — Dark PWM Pad [clouds] port:right stage:strip -> Master [$master] port:right stage:input
; tap: post-fader; initial route gain: 0 dB; source mute and mixer solo gate this route.
instr vcs_mix_bf6f81fb9ed80577ae278764
 k_post chnget "__vcs_mixer_route_aca770adf6d5aa1d37b31081_post"
 a_post vcs_mixer_ramp k_post, 1
 k_pan chnget "__vcs_mixer_route_aca770adf6d5aa1d37b31081_pan"
 a_pan vcs_mixer_ramp k_pan, 1
 a_pre inleta "pre"
 a_post_signal inleta "post"
 a_signal = a_pre * (1 - a_post) + a_post_signal * a_post * a_pan
 k_send chnget "__vcs_mixer_route_aca770adf6d5aa1d37b31081_gain"
 a_send vcs_mixer_ramp k_send, 1
 a_route_output = a_signal * a_send
 outleta "out", a_route_output
endin

; mixer stage strip:drums
; mixer strip: Analog Drumkit [drums]
; initial gain: -11 dB; balance/pan: 0; mute: false; solo: false
; Voices and insert returns sum before the strip; pre taps precede balance/fader, post taps follow them.
instr vcs_mix_233b9a10d13cb7345fe0ac51
 k_meter metro 15
 k_gain chnget "__vcs_mixer_strip_7cc44eb19abccf91739a7239_gain"
 a_gain vcs_mixer_ramp k_gain, 0.28183829312644537
 k_left chnget "__vcs_mixer_strip_7cc44eb19abccf91739a7239_left"
 a_left vcs_mixer_ramp k_left, 1
 k_right chnget "__vcs_mixer_strip_7cc44eb19abccf91739a7239_right"
 a_right vcs_mixer_ramp k_right, 1
 k_mute chnget "__vcs_mixer_strip_7cc44eb19abccf91739a7239_mute"
 a_mute vcs_mixer_ramp k_mute, 1
 a_p_360f84035942243c6a36537a inleta "p_360f84035942243c6a36537a"
 a_p_360f84035942243c6a36537a_post = a_p_360f84035942243c6a36537a * a_gain * a_left
 a_p_27042f4e6eca7d0b2a7ee402 inleta "p_27042f4e6eca7d0b2a7ee402"
 a_p_27042f4e6eca7d0b2a7ee402_post = a_p_27042f4e6eca7d0b2a7ee402 * a_gain * a_right
 a_meter_left = a_p_360f84035942243c6a36537a_post * a_mute
 a_meter_right = a_p_27042f4e6eca7d0b2a7ee402_post * a_mute
 k_peakL max_k a_meter_left, k_meter, 1
 k_rmsL rms a_meter_left
 chnset k_peakL / 1.0, "__vcs_mixer_meter_7cc44eb19abccf91739a7239_peakL"
 chnset k_rmsL / 1.0, "__vcs_mixer_meter_7cc44eb19abccf91739a7239_rmsL"
 k_peakR max_k a_meter_right, k_meter, 1
 k_rmsR rms a_meter_right
 chnset k_peakR / 1.0, "__vcs_mixer_meter_7cc44eb19abccf91739a7239_peakR"
 chnset k_rmsR / 1.0, "__vcs_mixer_meter_7cc44eb19abccf91739a7239_rmsR"
 outleta "pre_p_360f84035942243c6a36537a", a_p_360f84035942243c6a36537a
 outleta "post_p_360f84035942243c6a36537a", a_p_360f84035942243c6a36537a_post
 outleta "pre_p_27042f4e6eca7d0b2a7ee402", a_p_27042f4e6eca7d0b2a7ee402
 outleta "post_p_27042f4e6eca7d0b2a7ee402", a_p_27042f4e6eca7d0b2a7ee402_post
endin

; mixer stage route:drums-to-master-left
; audio route:drums-to-master-left kind:main
; from: Analog Drumkit [drums] port:left stage:strip -> Master [$master] port:left stage:input
; tap: post-fader; initial route gain: 0 dB; source mute and mixer solo gate this route.
instr vcs_mix_776a9ca62745889b1ae2494d
 k_post chnget "__vcs_mixer_route_83b8456f5a6ccf61bd09771f_post"
 a_post vcs_mixer_ramp k_post, 1
 k_pan chnget "__vcs_mixer_route_83b8456f5a6ccf61bd09771f_pan"
 a_pan vcs_mixer_ramp k_pan, 1
 a_pre inleta "pre"
 a_post_signal inleta "post"
 a_signal = a_pre * (1 - a_post) + a_post_signal * a_post * a_pan
 k_send chnget "__vcs_mixer_route_83b8456f5a6ccf61bd09771f_gain"
 a_send vcs_mixer_ramp k_send, 1
 a_route_output = a_signal * a_send
 outleta "out", a_route_output
endin

; mixer stage route:drums-to-master-right
; audio route:drums-to-master-right kind:main
; from: Analog Drumkit [drums] port:right stage:strip -> Master [$master] port:right stage:input
; tap: post-fader; initial route gain: 0 dB; source mute and mixer solo gate this route.
instr vcs_mix_38e2e3dd71d7c951b8ee623c
 k_post chnget "__vcs_mixer_route_b5f389b4e240e65eb88e717c_post"
 a_post vcs_mixer_ramp k_post, 1
 k_pan chnget "__vcs_mixer_route_b5f389b4e240e65eb88e717c_pan"
 a_pan vcs_mixer_ramp k_pan, 1
 a_pre inleta "pre"
 a_post_signal inleta "post"
 a_signal = a_pre * (1 - a_post) + a_post_signal * a_post * a_pan
 k_send chnget "__vcs_mixer_route_b5f389b4e240e65eb88e717c_gain"
 a_send vcs_mixer_ramp k_send, 1
 a_route_output = a_signal * a_send
 outleta "out", a_route_output
endin

; mixer stage strip:glints
; mixer strip: EBM DW — Glass Bell [glints]
; initial gain: -12 dB; balance/pan: 0.15; mute: false; solo: false
; Voices and insert returns sum before the strip; pre taps precede balance/fader, post taps follow them.
instr vcs_mix_3fb9b3909cb149df8c692155
 k_meter metro 15
 k_gain chnget "__vcs_mixer_strip_5187e59d9b00ec8dfc6ace45_gain"
 a_gain vcs_mixer_ramp k_gain, 0.25118864315095801
 k_left chnget "__vcs_mixer_strip_5187e59d9b00ec8dfc6ace45_left"
 a_left vcs_mixer_ramp k_left, 0.84999999999999998
 k_right chnget "__vcs_mixer_strip_5187e59d9b00ec8dfc6ace45_right"
 a_right vcs_mixer_ramp k_right, 1
 k_mute chnget "__vcs_mixer_strip_5187e59d9b00ec8dfc6ace45_mute"
 a_mute vcs_mixer_ramp k_mute, 1
 a_p_360f84035942243c6a36537a inleta "p_360f84035942243c6a36537a"
 a_p_360f84035942243c6a36537a_post = a_p_360f84035942243c6a36537a * a_gain * a_left
 a_p_27042f4e6eca7d0b2a7ee402 inleta "p_27042f4e6eca7d0b2a7ee402"
 a_p_27042f4e6eca7d0b2a7ee402_post = a_p_27042f4e6eca7d0b2a7ee402 * a_gain * a_right
 a_meter_left = a_p_360f84035942243c6a36537a_post * a_mute
 a_meter_right = a_p_27042f4e6eca7d0b2a7ee402_post * a_mute
 k_peakL max_k a_meter_left, k_meter, 1
 k_rmsL rms a_meter_left
 chnset k_peakL / 1.0, "__vcs_mixer_meter_5187e59d9b00ec8dfc6ace45_peakL"
 chnset k_rmsL / 1.0, "__vcs_mixer_meter_5187e59d9b00ec8dfc6ace45_rmsL"
 k_peakR max_k a_meter_right, k_meter, 1
 k_rmsR rms a_meter_right
 chnset k_peakR / 1.0, "__vcs_mixer_meter_5187e59d9b00ec8dfc6ace45_peakR"
 chnset k_rmsR / 1.0, "__vcs_mixer_meter_5187e59d9b00ec8dfc6ace45_rmsR"
 outleta "pre_p_360f84035942243c6a36537a", a_p_360f84035942243c6a36537a
 outleta "post_p_360f84035942243c6a36537a", a_p_360f84035942243c6a36537a_post
 outleta "pre_p_27042f4e6eca7d0b2a7ee402", a_p_27042f4e6eca7d0b2a7ee402
 outleta "post_p_27042f4e6eca7d0b2a7ee402", a_p_27042f4e6eca7d0b2a7ee402_post
endin

; mixer stage route:glints-to-master-left
; audio route:glints-to-master-left kind:main
; from: EBM DW — Glass Bell [glints] port:left stage:strip -> Master [$master] port:left stage:input
; tap: post-fader; initial route gain: 0 dB; source mute and mixer solo gate this route.
instr vcs_mix_7a9040b07366a0daa7dc6894
 k_post chnget "__vcs_mixer_route_7d9706dbf4b80041a7bac944_post"
 a_post vcs_mixer_ramp k_post, 1
 k_pan chnget "__vcs_mixer_route_7d9706dbf4b80041a7bac944_pan"
 a_pan vcs_mixer_ramp k_pan, 1
 a_pre inleta "pre"
 a_post_signal inleta "post"
 a_signal = a_pre * (1 - a_post) + a_post_signal * a_post * a_pan
 k_send chnget "__vcs_mixer_route_7d9706dbf4b80041a7bac944_gain"
 a_send vcs_mixer_ramp k_send, 1
 a_route_output = a_signal * a_send
 outleta "out", a_route_output
endin

; mixer stage route:glints-to-master-right
; audio route:glints-to-master-right kind:main
; from: EBM DW — Glass Bell [glints] port:right stage:strip -> Master [$master] port:right stage:input
; tap: post-fader; initial route gain: 0 dB; source mute and mixer solo gate this route.
instr vcs_mix_898dca64f18bed88c536cb6b
 k_post chnget "__vcs_mixer_route_5471588a628d780162691603_post"
 a_post vcs_mixer_ramp k_post, 1
 k_pan chnget "__vcs_mixer_route_5471588a628d780162691603_pan"
 a_pan vcs_mixer_ramp k_pan, 1
 a_pre inleta "pre"
 a_post_signal inleta "post"
 a_signal = a_pre * (1 - a_post) + a_post_signal * a_post * a_pan
 k_send chnget "__vcs_mixer_route_5471588a628d780162691603_gain"
 a_send vcs_mixer_ramp k_send, 1
 a_route_output = a_signal * a_send
 outleta "out", a_route_output
endin

; mixer stage strip:strikes
; mixer strip: EBM DW — Industrial Stab [strikes]
; initial gain: -14 dB; balance/pan: -0.12; mute: false; solo: false
; Voices and insert returns sum before the strip; pre taps precede balance/fader, post taps follow them.
instr vcs_mix_d128d928004c9323f776f93a
 k_meter metro 15
 k_gain chnget "__vcs_mixer_strip_69a5a5c217c582a0ca581019_gain"
 a_gain vcs_mixer_ramp k_gain, 0.19952623149688797
 k_left chnget "__vcs_mixer_strip_69a5a5c217c582a0ca581019_left"
 a_left vcs_mixer_ramp k_left, 1
 k_right chnget "__vcs_mixer_strip_69a5a5c217c582a0ca581019_right"
 a_right vcs_mixer_ramp k_right, 0.88
 k_mute chnget "__vcs_mixer_strip_69a5a5c217c582a0ca581019_mute"
 a_mute vcs_mixer_ramp k_mute, 1
 a_p_360f84035942243c6a36537a inleta "p_360f84035942243c6a36537a"
 a_p_360f84035942243c6a36537a_post = a_p_360f84035942243c6a36537a * a_gain * a_left
 a_p_27042f4e6eca7d0b2a7ee402 inleta "p_27042f4e6eca7d0b2a7ee402"
 a_p_27042f4e6eca7d0b2a7ee402_post = a_p_27042f4e6eca7d0b2a7ee402 * a_gain * a_right
 a_meter_left = a_p_360f84035942243c6a36537a_post * a_mute
 a_meter_right = a_p_27042f4e6eca7d0b2a7ee402_post * a_mute
 k_peakL max_k a_meter_left, k_meter, 1
 k_rmsL rms a_meter_left
 chnset k_peakL / 1.0, "__vcs_mixer_meter_69a5a5c217c582a0ca581019_peakL"
 chnset k_rmsL / 1.0, "__vcs_mixer_meter_69a5a5c217c582a0ca581019_rmsL"
 k_peakR max_k a_meter_right, k_meter, 1
 k_rmsR rms a_meter_right
 chnset k_peakR / 1.0, "__vcs_mixer_meter_69a5a5c217c582a0ca581019_peakR"
 chnset k_rmsR / 1.0, "__vcs_mixer_meter_69a5a5c217c582a0ca581019_rmsR"
 outleta "pre_p_360f84035942243c6a36537a", a_p_360f84035942243c6a36537a
 outleta "post_p_360f84035942243c6a36537a", a_p_360f84035942243c6a36537a_post
 outleta "pre_p_27042f4e6eca7d0b2a7ee402", a_p_27042f4e6eca7d0b2a7ee402
 outleta "post_p_27042f4e6eca7d0b2a7ee402", a_p_27042f4e6eca7d0b2a7ee402_post
endin

; mixer stage route:strikes-to-master-left
; audio route:strikes-to-master-left kind:main
; from: EBM DW — Industrial Stab [strikes] port:left stage:strip -> Master [$master] port:left stage:input
; tap: post-fader; initial route gain: 0 dB; source mute and mixer solo gate this route.
instr vcs_mix_725f6223d9072d1bb2e23c76
 k_post chnget "__vcs_mixer_route_1d60c1873f7c84bee9eada4e_post"
 a_post vcs_mixer_ramp k_post, 1
 k_pan chnget "__vcs_mixer_route_1d60c1873f7c84bee9eada4e_pan"
 a_pan vcs_mixer_ramp k_pan, 1
 a_pre inleta "pre"
 a_post_signal inleta "post"
 a_signal = a_pre * (1 - a_post) + a_post_signal * a_post * a_pan
 k_send chnget "__vcs_mixer_route_1d60c1873f7c84bee9eada4e_gain"
 a_send vcs_mixer_ramp k_send, 1
 a_route_output = a_signal * a_send
 outleta "out", a_route_output
endin

; mixer stage route:strikes-to-master-right
; audio route:strikes-to-master-right kind:main
; from: EBM DW — Industrial Stab [strikes] port:right stage:strip -> Master [$master] port:right stage:input
; tap: post-fader; initial route gain: 0 dB; source mute and mixer solo gate this route.
instr vcs_mix_d04fd17777bbf3b8af8783a5
 k_post chnget "__vcs_mixer_route_51517161fc68e6e3eeac9206_post"
 a_post vcs_mixer_ramp k_post, 1
 k_pan chnget "__vcs_mixer_route_51517161fc68e6e3eeac9206_pan"
 a_pan vcs_mixer_ramp k_pan, 1
 a_pre inleta "pre"
 a_post_signal inleta "post"
 a_signal = a_pre * (1 - a_post) + a_post_signal * a_post * a_pan
 k_send chnget "__vcs_mixer_route_51517161fc68e6e3eeac9206_gain"
 a_send vcs_mixer_ramp k_send, 1
 a_route_output = a_signal * a_send
 outleta "out", a_route_output
endin

; mixer stage strip:sunlight
; mixer strip: EBM DW — String Ensemble [sunlight]
; initial gain: -1 dB; balance/pan: 0; mute: false; solo: false
; Voices and insert returns sum before the strip; pre taps precede balance/fader, post taps follow them.
instr vcs_mix_ac92f39f17c2687b02e604f4
 k_meter metro 15
 k_gain chnget "__vcs_mixer_strip_921a95e8b614f668981d9eee_gain"
 a_gain vcs_mixer_ramp k_gain, 0.89125093813374556
 k_left chnget "__vcs_mixer_strip_921a95e8b614f668981d9eee_left"
 a_left vcs_mixer_ramp k_left, 1
 k_right chnget "__vcs_mixer_strip_921a95e8b614f668981d9eee_right"
 a_right vcs_mixer_ramp k_right, 1
 k_mute chnget "__vcs_mixer_strip_921a95e8b614f668981d9eee_mute"
 a_mute vcs_mixer_ramp k_mute, 1
 a_p_360f84035942243c6a36537a inleta "p_360f84035942243c6a36537a"
 a_p_360f84035942243c6a36537a_post = a_p_360f84035942243c6a36537a * a_gain * a_left
 a_p_27042f4e6eca7d0b2a7ee402 inleta "p_27042f4e6eca7d0b2a7ee402"
 a_p_27042f4e6eca7d0b2a7ee402_post = a_p_27042f4e6eca7d0b2a7ee402 * a_gain * a_right
 a_meter_left = a_p_360f84035942243c6a36537a_post * a_mute
 a_meter_right = a_p_27042f4e6eca7d0b2a7ee402_post * a_mute
 k_peakL max_k a_meter_left, k_meter, 1
 k_rmsL rms a_meter_left
 chnset k_peakL / 1.0, "__vcs_mixer_meter_921a95e8b614f668981d9eee_peakL"
 chnset k_rmsL / 1.0, "__vcs_mixer_meter_921a95e8b614f668981d9eee_rmsL"
 k_peakR max_k a_meter_right, k_meter, 1
 k_rmsR rms a_meter_right
 chnset k_peakR / 1.0, "__vcs_mixer_meter_921a95e8b614f668981d9eee_peakR"
 chnset k_rmsR / 1.0, "__vcs_mixer_meter_921a95e8b614f668981d9eee_rmsR"
 outleta "pre_p_360f84035942243c6a36537a", a_p_360f84035942243c6a36537a
 outleta "post_p_360f84035942243c6a36537a", a_p_360f84035942243c6a36537a_post
 outleta "pre_p_27042f4e6eca7d0b2a7ee402", a_p_27042f4e6eca7d0b2a7ee402
 outleta "post_p_27042f4e6eca7d0b2a7ee402", a_p_27042f4e6eca7d0b2a7ee402_post
endin

; mixer stage route:sunlight-to-master-left
; audio route:sunlight-to-master-left kind:main
; from: EBM DW — String Ensemble [sunlight] port:left stage:strip -> Master [$master] port:left stage:input
; tap: post-fader; initial route gain: 0 dB; source mute and mixer solo gate this route.
instr vcs_mix_9f8ea62d9094b1ee06064c74
 k_post chnget "__vcs_mixer_route_c01b8e240438f78a8824cfd3_post"
 a_post vcs_mixer_ramp k_post, 1
 k_pan chnget "__vcs_mixer_route_c01b8e240438f78a8824cfd3_pan"
 a_pan vcs_mixer_ramp k_pan, 1
 a_pre inleta "pre"
 a_post_signal inleta "post"
 a_signal = a_pre * (1 - a_post) + a_post_signal * a_post * a_pan
 k_send chnget "__vcs_mixer_route_c01b8e240438f78a8824cfd3_gain"
 a_send vcs_mixer_ramp k_send, 1
 a_route_output = a_signal * a_send
 outleta "out", a_route_output
endin

; mixer stage route:sunlight-to-master-right
; audio route:sunlight-to-master-right kind:main
; from: EBM DW — String Ensemble [sunlight] port:right stage:strip -> Master [$master] port:right stage:input
; tap: post-fader; initial route gain: 0 dB; source mute and mixer solo gate this route.
instr vcs_mix_ab29dbdb974d3cf3720ccde1
 k_post chnget "__vcs_mixer_route_1a360e0bf12680fcccccf68a_post"
 a_post vcs_mixer_ramp k_post, 1
 k_pan chnget "__vcs_mixer_route_1a360e0bf12680fcccccf68a_pan"
 a_pan vcs_mixer_ramp k_pan, 1
 a_pre inleta "pre"
 a_post_signal inleta "post"
 a_signal = a_pre * (1 - a_post) + a_post_signal * a_post * a_pan
 k_send chnget "__vcs_mixer_route_1a360e0bf12680fcccccf68a_gain"
 a_send vcs_mixer_ramp k_send, 1
 a_route_output = a_signal * a_send
 outleta "out", a_route_output
endin

; mixer stage strip:sunrays
; mixer strip: EBM DW — Analog Brass [sunrays]
; initial gain: 0 dB; balance/pan: 0.13; mute: false; solo: false
; Voices and insert returns sum before the strip; pre taps precede balance/fader, post taps follow them.
instr vcs_mix_c5cc5b5de6f0d6ab45b331f7
 k_meter metro 15
 k_gain chnget "__vcs_mixer_strip_4357ddb2013f8c1bae14ef67_gain"
 a_gain vcs_mixer_ramp k_gain, 1
 k_left chnget "__vcs_mixer_strip_4357ddb2013f8c1bae14ef67_left"
 a_left vcs_mixer_ramp k_left, 0.87
 k_right chnget "__vcs_mixer_strip_4357ddb2013f8c1bae14ef67_right"
 a_right vcs_mixer_ramp k_right, 1
 k_mute chnget "__vcs_mixer_strip_4357ddb2013f8c1bae14ef67_mute"
 a_mute vcs_mixer_ramp k_mute, 1
 a_p_360f84035942243c6a36537a inleta "p_360f84035942243c6a36537a"
 a_p_360f84035942243c6a36537a_post = a_p_360f84035942243c6a36537a * a_gain * a_left
 a_p_27042f4e6eca7d0b2a7ee402 inleta "p_27042f4e6eca7d0b2a7ee402"
 a_p_27042f4e6eca7d0b2a7ee402_post = a_p_27042f4e6eca7d0b2a7ee402 * a_gain * a_right
 a_meter_left = a_p_360f84035942243c6a36537a_post * a_mute
 a_meter_right = a_p_27042f4e6eca7d0b2a7ee402_post * a_mute
 k_peakL max_k a_meter_left, k_meter, 1
 k_rmsL rms a_meter_left
 chnset k_peakL / 1.0, "__vcs_mixer_meter_4357ddb2013f8c1bae14ef67_peakL"
 chnset k_rmsL / 1.0, "__vcs_mixer_meter_4357ddb2013f8c1bae14ef67_rmsL"
 k_peakR max_k a_meter_right, k_meter, 1
 k_rmsR rms a_meter_right
 chnset k_peakR / 1.0, "__vcs_mixer_meter_4357ddb2013f8c1bae14ef67_peakR"
 chnset k_rmsR / 1.0, "__vcs_mixer_meter_4357ddb2013f8c1bae14ef67_rmsR"
 outleta "pre_p_360f84035942243c6a36537a", a_p_360f84035942243c6a36537a
 outleta "post_p_360f84035942243c6a36537a", a_p_360f84035942243c6a36537a_post
 outleta "pre_p_27042f4e6eca7d0b2a7ee402", a_p_27042f4e6eca7d0b2a7ee402
 outleta "post_p_27042f4e6eca7d0b2a7ee402", a_p_27042f4e6eca7d0b2a7ee402_post
endin

; mixer stage route:sunrays-to-master-left
; audio route:sunrays-to-master-left kind:main
; from: EBM DW — Analog Brass [sunrays] port:left stage:strip -> Master [$master] port:left stage:input
; tap: post-fader; initial route gain: 0 dB; source mute and mixer solo gate this route.
instr vcs_mix_a0bf5a6e682d1681b8c6dcab
 k_post chnget "__vcs_mixer_route_3bf52259f3a75a40898bd370_post"
 a_post vcs_mixer_ramp k_post, 1
 k_pan chnget "__vcs_mixer_route_3bf52259f3a75a40898bd370_pan"
 a_pan vcs_mixer_ramp k_pan, 1
 a_pre inleta "pre"
 a_post_signal inleta "post"
 a_signal = a_pre * (1 - a_post) + a_post_signal * a_post * a_pan
 k_send chnget "__vcs_mixer_route_3bf52259f3a75a40898bd370_gain"
 a_send vcs_mixer_ramp k_send, 1
 a_route_output = a_signal * a_send
 outleta "out", a_route_output
endin

; mixer stage route:sunrays-to-master-right
; audio route:sunrays-to-master-right kind:main
; from: EBM DW — Analog Brass [sunrays] port:right stage:strip -> Master [$master] port:right stage:input
; tap: post-fader; initial route gain: 0 dB; source mute and mixer solo gate this route.
instr vcs_mix_5e006bf5e9b69c39e6038e0c
 k_post chnget "__vcs_mixer_route_95085945e8b7aaf31960266c_post"
 a_post vcs_mixer_ramp k_post, 1
 k_pan chnget "__vcs_mixer_route_95085945e8b7aaf31960266c_pan"
 a_pan vcs_mixer_ramp k_pan, 1
 a_pre inleta "pre"
 a_post_signal inleta "post"
 a_signal = a_pre * (1 - a_post) + a_post_signal * a_post * a_pan
 k_send chnget "__vcs_mixer_route_95085945e8b7aaf31960266c_gain"
 a_send vcs_mixer_ramp k_send, 1
 a_route_output = a_signal * a_send
 outleta "out", a_route_output
endin

; mixer stage strip:theme
; mixer strip: EBM DW — Dark Saw Lead [theme]
; initial gain: 0 dB; balance/pan: -0.08; mute: false; solo: false
; Voices and insert returns sum before the strip; pre taps precede balance/fader, post taps follow them.
instr vcs_mix_8a252033ed35df6ff80fdae8
 k_meter metro 15
 k_gain chnget "__vcs_mixer_strip_3cb8201e7ff1e7777446032e_gain"
 a_gain vcs_mixer_ramp k_gain, 1
 k_left chnget "__vcs_mixer_strip_3cb8201e7ff1e7777446032e_left"
 a_left vcs_mixer_ramp k_left, 1
 k_right chnget "__vcs_mixer_strip_3cb8201e7ff1e7777446032e_right"
 a_right vcs_mixer_ramp k_right, 0.92000000000000004
 k_mute chnget "__vcs_mixer_strip_3cb8201e7ff1e7777446032e_mute"
 a_mute vcs_mixer_ramp k_mute, 1
 a_p_360f84035942243c6a36537a inleta "p_360f84035942243c6a36537a"
 a_p_360f84035942243c6a36537a_post = a_p_360f84035942243c6a36537a * a_gain * a_left
 a_p_27042f4e6eca7d0b2a7ee402 inleta "p_27042f4e6eca7d0b2a7ee402"
 a_p_27042f4e6eca7d0b2a7ee402_post = a_p_27042f4e6eca7d0b2a7ee402 * a_gain * a_right
 a_meter_left = a_p_360f84035942243c6a36537a_post * a_mute
 a_meter_right = a_p_27042f4e6eca7d0b2a7ee402_post * a_mute
 k_peakL max_k a_meter_left, k_meter, 1
 k_rmsL rms a_meter_left
 chnset k_peakL / 1.0, "__vcs_mixer_meter_3cb8201e7ff1e7777446032e_peakL"
 chnset k_rmsL / 1.0, "__vcs_mixer_meter_3cb8201e7ff1e7777446032e_rmsL"
 k_peakR max_k a_meter_right, k_meter, 1
 k_rmsR rms a_meter_right
 chnset k_peakR / 1.0, "__vcs_mixer_meter_3cb8201e7ff1e7777446032e_peakR"
 chnset k_rmsR / 1.0, "__vcs_mixer_meter_3cb8201e7ff1e7777446032e_rmsR"
 outleta "pre_p_360f84035942243c6a36537a", a_p_360f84035942243c6a36537a
 outleta "post_p_360f84035942243c6a36537a", a_p_360f84035942243c6a36537a_post
 outleta "pre_p_27042f4e6eca7d0b2a7ee402", a_p_27042f4e6eca7d0b2a7ee402
 outleta "post_p_27042f4e6eca7d0b2a7ee402", a_p_27042f4e6eca7d0b2a7ee402_post
endin

; mixer stage route:theme-to-master-left
; audio route:theme-to-master-left kind:main
; from: EBM DW — Dark Saw Lead [theme] port:left stage:strip -> Master [$master] port:left stage:input
; tap: post-fader; initial route gain: 0 dB; source mute and mixer solo gate this route.
instr vcs_mix_72eedbbbd4d867877d198844
 k_post chnget "__vcs_mixer_route_6ef9be26494bffae34fdfd29_post"
 a_post vcs_mixer_ramp k_post, 1
 k_pan chnget "__vcs_mixer_route_6ef9be26494bffae34fdfd29_pan"
 a_pan vcs_mixer_ramp k_pan, 1
 a_pre inleta "pre"
 a_post_signal inleta "post"
 a_signal = a_pre * (1 - a_post) + a_post_signal * a_post * a_pan
 k_send chnget "__vcs_mixer_route_6ef9be26494bffae34fdfd29_gain"
 a_send vcs_mixer_ramp k_send, 1
 a_route_output = a_signal * a_send
 outleta "out", a_route_output
endin

; mixer stage route:theme-to-master-right
; audio route:theme-to-master-right kind:main
; from: EBM DW — Dark Saw Lead [theme] port:right stage:strip -> Master [$master] port:right stage:input
; tap: post-fader; initial route gain: 0 dB; source mute and mixer solo gate this route.
instr vcs_mix_bf26ce664958883e5fa5077a
 k_post chnget "__vcs_mixer_route_43f837ee6d4c255b17854c22_post"
 a_post vcs_mixer_ramp k_post, 1
 k_pan chnget "__vcs_mixer_route_43f837ee6d4c255b17854c22_pan"
 a_pan vcs_mixer_ramp k_pan, 1
 a_pre inleta "pre"
 a_post_signal inleta "post"
 a_signal = a_pre * (1 - a_post) + a_post_signal * a_post * a_pan
 k_send chnget "__vcs_mixer_route_43f837ee6d4c255b17854c22_gain"
 a_send vcs_mixer_ramp k_send, 1
 a_route_output = a_signal * a_send
 outleta "out", a_route_output
endin

; mixer stage strip:weather
; mixer strip: EBM DW — Noise Metal FX [weather]
; initial gain: -16 dB; balance/pan: 0; mute: false; solo: false
; Voices and insert returns sum before the strip; pre taps precede balance/fader, post taps follow them.
instr vcs_mix_e1d7e481eb08ca2b9fc71c78
 k_meter metro 15
 k_gain chnget "__vcs_mixer_strip_e5e72beb4e3c6926d3dc9e3e_gain"
 a_gain vcs_mixer_ramp k_gain, 0.15848931924611134
 k_left chnget "__vcs_mixer_strip_e5e72beb4e3c6926d3dc9e3e_left"
 a_left vcs_mixer_ramp k_left, 1
 k_right chnget "__vcs_mixer_strip_e5e72beb4e3c6926d3dc9e3e_right"
 a_right vcs_mixer_ramp k_right, 1
 k_mute chnget "__vcs_mixer_strip_e5e72beb4e3c6926d3dc9e3e_mute"
 a_mute vcs_mixer_ramp k_mute, 1
 a_p_360f84035942243c6a36537a inleta "p_360f84035942243c6a36537a"
 a_p_360f84035942243c6a36537a_post = a_p_360f84035942243c6a36537a * a_gain * a_left
 a_p_27042f4e6eca7d0b2a7ee402 inleta "p_27042f4e6eca7d0b2a7ee402"
 a_p_27042f4e6eca7d0b2a7ee402_post = a_p_27042f4e6eca7d0b2a7ee402 * a_gain * a_right
 a_meter_left = a_p_360f84035942243c6a36537a_post * a_mute
 a_meter_right = a_p_27042f4e6eca7d0b2a7ee402_post * a_mute
 k_peakL max_k a_meter_left, k_meter, 1
 k_rmsL rms a_meter_left
 chnset k_peakL / 1.0, "__vcs_mixer_meter_e5e72beb4e3c6926d3dc9e3e_peakL"
 chnset k_rmsL / 1.0, "__vcs_mixer_meter_e5e72beb4e3c6926d3dc9e3e_rmsL"
 k_peakR max_k a_meter_right, k_meter, 1
 k_rmsR rms a_meter_right
 chnset k_peakR / 1.0, "__vcs_mixer_meter_e5e72beb4e3c6926d3dc9e3e_peakR"
 chnset k_rmsR / 1.0, "__vcs_mixer_meter_e5e72beb4e3c6926d3dc9e3e_rmsR"
 outleta "pre_p_360f84035942243c6a36537a", a_p_360f84035942243c6a36537a
 outleta "post_p_360f84035942243c6a36537a", a_p_360f84035942243c6a36537a_post
 outleta "pre_p_27042f4e6eca7d0b2a7ee402", a_p_27042f4e6eca7d0b2a7ee402
 outleta "post_p_27042f4e6eca7d0b2a7ee402", a_p_27042f4e6eca7d0b2a7ee402_post
endin

; mixer stage route:weather-to-master-left
; audio route:weather-to-master-left kind:main
; from: EBM DW — Noise Metal FX [weather] port:left stage:strip -> Master [$master] port:left stage:input
; tap: post-fader; initial route gain: 0 dB; source mute and mixer solo gate this route.
instr vcs_mix_e07cbf7b561e14be9651d6d0
 k_post chnget "__vcs_mixer_route_215dfad6ea4278df9c5b5929_post"
 a_post vcs_mixer_ramp k_post, 1
 k_pan chnget "__vcs_mixer_route_215dfad6ea4278df9c5b5929_pan"
 a_pan vcs_mixer_ramp k_pan, 1
 a_pre inleta "pre"
 a_post_signal inleta "post"
 a_signal = a_pre * (1 - a_post) + a_post_signal * a_post * a_pan
 k_send chnget "__vcs_mixer_route_215dfad6ea4278df9c5b5929_gain"
 a_send vcs_mixer_ramp k_send, 1
 a_route_output = a_signal * a_send
 outleta "out", a_route_output
endin

; mixer stage route:weather-to-master-right
; audio route:weather-to-master-right kind:main
; from: EBM DW — Noise Metal FX [weather] port:right stage:strip -> Master [$master] port:right stage:input
; tap: post-fader; initial route gain: 0 dB; source mute and mixer solo gate this route.
instr vcs_mix_9fa67706cd4495d936a25713
 k_post chnget "__vcs_mixer_route_7ccdeae3e4931ae57c24ee42_post"
 a_post vcs_mixer_ramp k_post, 1
 k_pan chnget "__vcs_mixer_route_7ccdeae3e4931ae57c24ee42_pan"
 a_pan vcs_mixer_ramp k_pan, 1
 a_pre inleta "pre"
 a_post_signal inleta "post"
 a_signal = a_pre * (1 - a_post) + a_post_signal * a_post * a_pan
 k_send chnget "__vcs_mixer_route_7ccdeae3e4931ae57c24ee42_gain"
 a_send vcs_mixer_ramp k_send, 1
 a_route_output = a_signal * a_send
 outleta "out", a_route_output
endin

; mixer stage patch:$master
; patch:$master name:Master channel:0 always_on:true
; instance:$master csound:vcs_mix_63254fa67083d5eed1f09ece
; trigger: continuous (alwayson); score instrument number: 37
; role: Master processor; only audio explicitly routed here passes through Master.
instr vcs_mix_63254fa67083d5eed1f09ece
 a_left inleta "left"
 a_right inleta "right"
 outleta "__vcs_direct_e0ee8bb50685e05fa0f47ed0_left", a_left
 outleta "__vcs_direct_e0ee8bb50685e05fa0f47ed0_right", a_right
endin

; mixer stage strip:$master
; mixer strip: Master [$master]
; initial gain: -4 dB; balance/pan: 0; mute: false; solo: false
; Voices and insert returns sum before the strip; pre taps precede balance/fader, post taps follow them.
instr vcs_mix_0644eeee2942927583ef32ed
 k_meter metro 15
 k_gain chnget "__vcs_mixer_strip_b5c7638620f2f38a657a5790_gain"
 a_gain vcs_mixer_ramp k_gain, 0.63095734448019325
 k_left chnget "__vcs_mixer_strip_b5c7638620f2f38a657a5790_left"
 a_left vcs_mixer_ramp k_left, 1
 k_right chnget "__vcs_mixer_strip_b5c7638620f2f38a657a5790_right"
 a_right vcs_mixer_ramp k_right, 1
 k_mute chnget "__vcs_mixer_strip_b5c7638620f2f38a657a5790_mute"
 a_mute vcs_mixer_ramp k_mute, 1
 a_p_2336acbd28828ab05deafe52 inleta "p_2336acbd28828ab05deafe52"
 a_p_2336acbd28828ab05deafe52_post = a_p_2336acbd28828ab05deafe52 * a_gain * a_left
 a_p_2a250433534f9aea9d512171 inleta "p_2a250433534f9aea9d512171"
 a_p_2a250433534f9aea9d512171_post = a_p_2a250433534f9aea9d512171 * a_gain * a_right
 a_meter_left = a_p_2336acbd28828ab05deafe52_post * a_mute
 a_meter_right = a_p_2a250433534f9aea9d512171_post * a_mute
 k_peakL max_k a_meter_left, k_meter, 1
 k_rmsL rms a_meter_left
 chnset k_peakL / 1.0, "__vcs_mixer_meter_b5c7638620f2f38a657a5790_peakL"
 chnset k_rmsL / 1.0, "__vcs_mixer_meter_b5c7638620f2f38a657a5790_rmsL"
 k_peakR max_k a_meter_right, k_meter, 1
 k_rmsR rms a_meter_right
 chnset k_peakR / 1.0, "__vcs_mixer_meter_b5c7638620f2f38a657a5790_peakR"
 chnset k_rmsR / 1.0, "__vcs_mixer_meter_b5c7638620f2f38a657a5790_rmsR"
 outleta "pre_p_2336acbd28828ab05deafe52", a_p_2336acbd28828ab05deafe52
 outleta "post_p_2336acbd28828ab05deafe52", a_p_2336acbd28828ab05deafe52_post
 outleta "pre_p_2a250433534f9aea9d512171", a_p_2a250433534f9aea9d512171
 outleta "post_p_2a250433534f9aea9d512171", a_p_2a250433534f9aea9d512171_post
endin

; mixer stage route:direct_663d9de6aaa09d717ad1da85
; audio route:direct_663d9de6aaa09d717ad1da85 kind:main
; from: Master [$master] port:$direct.left stage:strip -> Audio Output port:left stage:input
; tap: post-fader; initial route gain: 0 dB; source mute and mixer solo gate this route.
instr vcs_mix_ec8b1641891924a3e102560a
 k_post chnget "__vcs_mixer_route_ebe4d00ca1570557781dee01_post"
 a_post vcs_mixer_ramp k_post, 1
 k_pan chnget "__vcs_mixer_route_ebe4d00ca1570557781dee01_pan"
 a_pan vcs_mixer_ramp k_pan, 1
 a_pre inleta "pre"
 a_post_signal inleta "post"
 a_signal = a_pre * (1 - a_post) + a_post_signal * a_post * a_pan
 k_send chnget "__vcs_mixer_route_ebe4d00ca1570557781dee01_gain"
 a_send vcs_mixer_ramp k_send, 1
 a_route_output = a_signal * a_send
 outleta "out", a_route_output
endin

; mixer stage route:direct_86c9f89b472612e7d2cddb1f
; audio route:direct_86c9f89b472612e7d2cddb1f kind:main
; from: Master [$master] port:$direct.right stage:strip -> Audio Output port:right stage:input
; tap: post-fader; initial route gain: 0 dB; source mute and mixer solo gate this route.
instr vcs_mix_5f16b779ade2ce91f307ff35
 k_post chnget "__vcs_mixer_route_208ab40923d5bf707587f01b_post"
 a_post vcs_mixer_ramp k_post, 1
 k_pan chnget "__vcs_mixer_route_208ab40923d5bf707587f01b_pan"
 a_pan vcs_mixer_ramp k_pan, 1
 a_pre inleta "pre"
 a_post_signal inleta "post"
 a_signal = a_pre * (1 - a_post) + a_post_signal * a_post * a_pan
 k_send chnget "__vcs_mixer_route_208ab40923d5bf707587f01b_gain"
 a_send vcs_mixer_ramp k_send, 1
 a_route_output = a_signal * a_send
 outleta "out", a_route_output
endin

; mixer stage $output
; Final Audio Output: sums all routed paths, including direct paths that bypass Master.
instr vcs_mix_9cea1be1f8255375a6cf7b93
 a_left inleta "left"
 a_right inleta "right"
 outs a_left, a_right
 k_meter metro 15
 k_peakL max_k a_left, k_meter, 1
 k_rmsL rms a_left
 chnset k_peakL / 1.0, "__vcs_mixer_meter_9cea1be1f8255375a6cf7b93_peakL"
 chnset k_rmsL / 1.0, "__vcs_mixer_meter_9cea1be1f8255375a6cf7b93_rmsL"
 k_peakR max_k a_right, k_meter, 1
 k_rmsR rms a_right
 chnset k_peakR / 1.0, "__vcs_mixer_meter_9cea1be1f8255375a6cf7b93_peakR"
 chnset k_rmsR / 1.0, "__vcs_mixer_meter_9cea1be1f8255375a6cf7b93_rmsR"
endin

</CsInstruments>
<CsScore>
f 1 0 16384 10 1
f 0 362
</CsScore>
</CsoundSynthesizer>