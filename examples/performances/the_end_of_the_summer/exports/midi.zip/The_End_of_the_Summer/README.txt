Orchestron offline render export

Contents:
- The_End_of_the_Summer.csd: compiled offline-render Csound document
- The_End_of_the_Summer.mid: multitrack arranger playback from beginning to arrangement end
- assets/: referenced sample audio and SoundFont files bundled for the CSD

Render steps:
1. Extract the ZIP and change into the bundled 'The_End_of_the_Summer/' directory.
2. Render with Csound using the bundled MIDI file.

Exact command line:
csound -d -W -f -o The_End_of_the_Summer.wav -F The_End_of_the_Summer.mid The_End_of_the_Summer.csd

Equivalent short form (uses the embedded CsOptions in the CSD):
csound The_End_of_the_Summer.csd

The WAV is written as 32-bit float to preserve the same headroom as live browser-clock audio.
Enabled MIDI Controller lane values are written at time 0 on their selected MIDI channels (all 16 by default).

If you need a longer release tail, increase the final 'f 0 ...' duration line in the CSD.
